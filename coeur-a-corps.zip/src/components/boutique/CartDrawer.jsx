import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { useCart } from "./CartContext";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";

export default function CartDrawer({ isOpen, onClose }) {
  const { cart, updateQuantity, removeFromCart, totalPrice, totalItems } = useCart();

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
          />
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed right-0 top-0 h-full w-full sm:w-96 bg-cac-black border-l border-cac-gray-dark z-50 flex flex-col"
          >
            {/* Header */}
            <div className="p-6 border-b border-cac-gray-dark flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingBag size={20} className="text-cac-gold" />
                <h2 className="font-heading text-xl text-cac-ivory">Panier</h2>
                {totalItems > 0 && (
                  <span className="bg-cac-gold text-cac-black text-xs w-5 h-5 rounded-full flex items-center justify-center font-medium">
                    {totalItems}
                  </span>
                )}
              </div>
              <button onClick={onClose} className="text-cac-gray hover:text-cac-ivory transition-colors">
                <X size={20} />
              </button>
            </div>

            {/* Cart items */}
            <div className="flex-1 overflow-y-auto p-6">
              {cart.length === 0 ? (
                <div className="text-center py-12">
                  <ShoppingBag size={48} className="text-cac-gray mx-auto mb-4 opacity-30" />
                  <p className="text-sm text-cac-gray">Votre panier est vide</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {cart.map((item, i) => (
                    <div key={i} className="bg-cac-black-light rounded-xl p-4 border border-cac-gray-dark/50">
                      <div className="flex gap-3">
                        <img
                          src={item.image}
                          alt={item.title}
                          className="w-16 h-16 object-cover rounded-lg"
                        />
                        <div className="flex-1">
                          <h3 className="text-sm text-cac-ivory font-medium">{item.title}</h3>
                          {item.variant && (
                            <p className="text-xs text-cac-gray">{item.variant}</p>
                          )}
                          <p className="text-sm text-cac-gold mt-1">{typeof item.price === 'number' ? `${item.price}€` : item.price}</p>
                        </div>
                        <button
                          onClick={() => removeFromCart(item)}
                          className="text-cac-gray hover:text-red-400 transition-colors"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                      <div className="flex items-center justify-between mt-3 pt-3 border-t border-cac-gray-dark/30">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateQuantity(item, item.quantity - 1)}
                            className="w-7 h-7 rounded-full bg-cac-gray-dark/30 hover:bg-cac-gold hover:text-cac-black transition-colors flex items-center justify-center text-cac-gray"
                          >
                            <Minus size={12} />
                          </button>
                          <span className="text-sm text-cac-ivory w-6 text-center">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item, item.quantity + 1)}
                            className="w-7 h-7 rounded-full bg-cac-gray-dark/30 hover:bg-cac-gold hover:text-cac-black transition-colors flex items-center justify-center text-cac-gray"
                          >
                            <Plus size={12} />
                          </button>
                        </div>
                        <p className="text-sm text-cac-gold font-medium">
                          {((typeof item.price === 'number' ? item.price : parseFloat(item.price.replace("€", ""))) * item.quantity).toFixed(2)}€
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            {cart.length > 0 && (
              <div className="p-6 border-t border-cac-gray-dark bg-cac-black-light">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm text-cac-gray">Total</span>
                  <span className="font-heading text-2xl text-cac-gold">{totalPrice.toFixed(2)}€</span>
                </div>
                <div className="w-full py-3 rounded-full text-sm uppercase tracking-[0.15em] text-center bg-cac-gray-dark/40 border border-cac-gray-dark text-cac-gray cursor-not-allowed">
                  Rupture de stock temporaire
                </div>
                <p className="text-xs text-cac-gray text-center mt-3">
                  Contactez-nous au 06 50 54 36 13 pour passer commande
                </p>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}