import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { X, Plus } from "lucide-react";

export default function ProductModal({ product, isOpen, onClose, onAddToCart }) {
  const [selectedVariant, setSelectedVariant] = useState(product?.variants?.[0] || null);

  if (!product) return null;

  const handleAdd = () => {
    if (selectedVariant) {
      onAddToCart({
        title: product.title,
        description: product.description,
        price: selectedVariant.price,
        variant: selectedVariant.name,
        image: product.image
      });
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-cac-black border border-cac-gold/30 text-cac-ivory max-w-lg max-h-[90vh] flex flex-col overflow-hidden">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="font-heading text-2xl text-cac-ivory pr-8">{product.title}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 overflow-y-auto flex-1 pr-1">
          <div className="aspect-video rounded-xl overflow-hidden">
            <img src={product.image} alt={product.title} className="w-full h-full object-cover" />
          </div>

          <p className="text-sm text-cac-gray leading-relaxed">{product.long_description}</p>

          {product.variants && product.variants.length > 0 && (
            <div className="space-y-3">
              <Label className="text-xs uppercase tracking-wider text-cac-gold">Choisissez votre variante</Label>
              <RadioGroup value={selectedVariant?.name} onValueChange={(value) => {
                const variant = product.variants.find(v => v.name === value);
                setSelectedVariant(variant);
              }}>
                {product.variants.map(variant => (
                  <div key={variant.name} className="flex items-center justify-between p-3 bg-cac-black-light border border-cac-gray-dark/50 rounded-lg hover:border-cac-gold/30 transition-all">
                    <div className="flex items-center space-x-3">
                      <RadioGroupItem value={variant.name} id={variant.name} className="border-cac-gold text-cac-gold" />
                      <Label htmlFor={variant.name} className="text-cac-ivory cursor-pointer">{variant.name}</Label>
                    </div>
                    <span className="text-cac-gold font-medium">{variant.price}€</span>
                  </div>
                ))}
              </RadioGroup>
            </div>
          )}

          <Button
            onClick={handleAdd}
            disabled={!selectedVariant}
            className="w-full btn-gold rounded-full py-6 text-sm uppercase tracking-[0.15em] flex items-center justify-center gap-2"
          >
            <Plus size={16} />
            Ajouter au panier - {selectedVariant?.price}€
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}