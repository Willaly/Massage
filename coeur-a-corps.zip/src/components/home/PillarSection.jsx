import React from "react";
import { motion } from "framer-motion";
import SectionHeading from "../shared/SectionHeading";
import { Heart, Shield, Sparkles } from "lucide-react";

const pillars = [
  {
    icon: Heart,
    title: "Une présence rare",
    description: "Marine accueille chaque personne avec une écoute attentive, chaleureuse, ancrée. Jamais dans la performance, toujours dans la justesse."
  },
  {
    icon: Shield,
    title: "Un espace sûr",
    description: "Confidentialité, respect du rythme, écoute des limites. Un lieu où vous pouvez vraiment lâcher prise en toute confiance."
  },
  {
    icon: Sparkles,
    title: "Un soin qui résonne",
    description: "Les clients parlent d'une parenthèse sacrée, d'un recentrage, d'un toucher qui va au-delà du geste. Un effet qui dure longtemps après."
  }
];

export default function PillarSection() {
  return (
    <section className="py-20 md:py-28 px-6 bg-cac-black-light">
      <div className="max-w-5xl mx-auto">
        <SectionHeading
          subtitle="Notre engagement"
          title="Pourquoi choisir Cœur à Corps"
        />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pillars.map((pillar, i) => {
            const Icon = pillar.icon;
            return (
              <motion.div
                key={pillar.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.15 }}
                className="text-center p-8 rounded-2xl border border-cac-gray-dark/50 hover:border-cac-gold/20 transition-all duration-500 group"
              >
                <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-cac-gold/10 flex items-center justify-center group-hover:bg-cac-gold/20 transition-colors">
                  <Icon size={28} className="text-cac-gold" strokeWidth={1.5} />
                </div>
                <h3 className="font-heading text-xl text-cac-ivory mb-3">{pillar.title}</h3>
                <p className="text-sm text-cac-gray leading-relaxed">{pillar.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}