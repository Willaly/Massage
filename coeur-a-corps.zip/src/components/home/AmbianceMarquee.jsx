import React from "react";

const images = [
"https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/a53fa01e6_ambiance_candles_60.jpg",
"https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/9cfb93e4f_ambiance_spa_dark_57.jpg",
"https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/c33742862_ambiance_towels_56.jpg",
"https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/db422480f_ambiance_oils_59.jpg",
"https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/eebbc7fc4_ambiance_wood_58.jpg",
"https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/b8f2d18eb_stones_53.jpg"];


export default function AmbianceMarquee() {
  const allImages = [...images, ...images];

  return (
    <section className="py-16 md:py-20 overflow-hidden">
      <div className="text-center mb-10">
        

        
      </div>
      <div className="overflow-hidden">
        <div className="marquee-track">
          {allImages.map((src, i) =>
          <div
            key={i}
            className="flex-shrink-0 w-64 md:w-80 h-48 md:h-56 mx-3 rounded-xl overflow-hidden">
            
              <img
              src={src}
              alt="Ambiance Cœur à Corps"
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-700" />
            
            </div>
          )}
        </div>
      </div>
    </section>);

}