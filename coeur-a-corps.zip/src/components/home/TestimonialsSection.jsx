import React from "react";
import SectionHeading from "../shared/SectionHeading";
import TestimonialCard from "../shared/TestimonialCard";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";

const testimonials = [
  {
    name: "Sophie L.",
    text: "Marine a une présence rare. On sent qu'elle est vraiment là, à l'écoute. Son massage m'a permis de lâcher prise comme jamais. Une parenthèse sacrée.",
    rating: 5
  },
  {
    name: "Thomas M.",
    text: "Le massage Harmonie a dépassé mes attentes. Un toucher profond mais jamais agressif, qui va chercher les tensions sans forcer. Mon corps respire enfin.",
    rating: 5
  },
  {
    name: "Claire D.",
    text: "Un moment suspendu. J'ai senti mon corps se détendre en profondeur, et même des émotions remonter. Marine accompagne tout ça avec une douceur incroyable.",
    rating: 5
  }
];

export default function TestimonialsSection() {
  return (
    <section className="py-20 md:py-28 px-6 bg-cac-black-light">
      <div className="max-w-5xl mx-auto">
        <SectionHeading
          subtitle="Ils nous font confiance"
          title="Avis de nos clients"
        />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <TestimonialCard key={t.name} {...t} index={i} />
          ))}
        </div>
        <div className="text-center mt-10">
          <Link
            to={createPageUrl("Temoignages")}
            className="border-2 border-cac-gold text-cac-gold px-8 py-3 rounded-full text-xs uppercase tracking-[0.15em] font-medium transition-all duration-300 hover:bg-cac-gold hover:text-cac-black hover:shadow-lg hover:shadow-cac-gold/40 hover:-translate-y-0.5 inline-block"
          >
            Tous les témoignages
          </Link>
        </div>
      </div>
    </section>
  );
}