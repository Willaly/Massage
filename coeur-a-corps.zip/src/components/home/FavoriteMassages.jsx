import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";
import SectionHeading from "../shared/SectionHeading";
import MassageCard from "../shared/MassageCard";

const massages = [
  {
    title: "Massage Harmonie",
    description: "Un soin signature enveloppant, fluide et profond, pour rétablir l'équilibre du corps et apaiser le mental.",
    durations: ["60 min", "90 min"],
    prices: ["70€", "100€"],
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/2f518af7e_massage_harmonie_27.jpg",
    badge: "Signature",
    slug: "harmonie"
  },
  {
    title: "Modelage des 5 Continents",
    description: "Un voyage énergétique inspiré des meilleures traditions de massage du monde.",
    durations: ["60 min", "90 min"],
    prices: ["95€", "130€"],
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/316e2a325_massage_lomi_26.jpg",
    slug: "5-continents"
  },
  {
    title: "Madérothérapie",
    description: "Une technique sculptante utilisant des instruments en bois pour redessiner les contours du corps.",
    durations: ["60 min", "90 min"],
    prices: ["85€", "120€"],
    cure: "6 séances : 450€",
    image: "https://images.unsplash.com/photo-1596178060671-7a80dc8059ea?w=600&q=80",
    slug: "maderotherapie"
  }
];

export default function FavoriteMassages() {
  return (
    <section className="py-20 md:py-28 px-6 bg-cac-black-light">
      <div className="max-w-6xl mx-auto">
        <SectionHeading
          subtitle="Nos soins"
          title="Les massages favoris"
          description="Découvrez nos soins les plus plébiscités, alliant expertise et sensorialité."
        />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {massages.map((massage, i) => (
            <MassageCard key={massage.title} {...massage} index={i} />
          ))}
        </div>
        <div className="text-center mt-10">
          <Link
            to={createPageUrl("QuestionnaireChoix")}
            className="btn-gold px-10 py-4 rounded-full text-sm uppercase tracking-[0.15em] inline-flex items-center gap-2 shadow-lg shadow-cac-gold/20 hover:shadow-cac-gold/40"
          >
            ✨ Besoin d'aide pour choisir ?
          </Link>
        </div>
      </div>
    </section>
  );
}