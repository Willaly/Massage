import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";
import { GraduationCap, Gift, ArrowRight } from "lucide-react";

export default function AutresPrestations() {
  return (
    <section className="py-20 md:py-28 px-6 bg-cac-black-light">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <p className="text-xs uppercase tracking-[0.25em] text-cac-gold mb-4 font-body font-medium">
            Découvrir aussi
          </p>
          <h2 className="font-heading text-3xl md:text-4xl text-cac-ivory">Autres prestations</h2>
          <div className="gold-divider mx-auto mt-6" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="group relative overflow-hidden rounded-2xl bg-cac-black border border-cac-gray-dark/50 hover:border-cac-gold/30 transition-all"
          >
            <div className="aspect-[16/10] overflow-hidden">
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/ffe769fa3_formation_initiation_17.jpg"
                alt="Formations"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-cac-black via-cac-black/40 to-transparent" />
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <div className="w-14 h-14 rounded-full bg-cac-gold/20 flex items-center justify-center mb-4">
                <GraduationCap size={28} className="text-cac-gold" />
              </div>
              <h3 className="font-heading text-2xl text-cac-ivory mb-2">Formations</h3>
              <p className="text-sm text-cac-ivory/70 mb-4">Apprenez l'art du massage avec nos formations professionnelles.</p>
              <Link
                to={createPageUrl("Formations")}
                className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.15em] font-medium text-cac-gold hover:text-cac-gold-light transition-all duration-300 hover:shadow-lg hover:shadow-cac-gold/30 hover:-translate-y-0.5"
              >
                En savoir plus
                <ArrowRight size={14} />
              </Link>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="group relative overflow-hidden rounded-2xl bg-cac-black border border-cac-gray-dark/50 hover:border-cac-gold/30 transition-all"
          >
            <div className="aspect-[16/10] overflow-hidden">
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/30a8d38de_giftcard_3_49.jpg"
                alt="Cartes cadeaux"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-cac-black via-cac-black/40 to-transparent" />
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <div className="w-14 h-14 rounded-full bg-cac-gold/20 flex items-center justify-center mb-4">
                <Gift size={28} className="text-cac-gold" />
              </div>
              <h3 className="font-heading text-2xl text-cac-ivory mb-2">Cartes cadeaux</h3>
              <p className="text-sm text-cac-ivory/70 mb-4">Offrez une parenthèse de bien-être personnalisable et élégante.</p>
              <Link
                to={createPageUrl("Offrir")}
                className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.15em] font-medium text-cac-gold hover:text-cac-gold-light transition-all duration-300 hover:shadow-lg hover:shadow-cac-gold/30 hover:-translate-y-0.5"
              >
                Créer une carte
                <ArrowRight size={14} />
              </Link>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}