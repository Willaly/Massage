import React from "react";
import { motion } from "framer-motion";
import SectionHeading from "../shared/SectionHeading";

export default function PratricienneSection() {
  return (
    <section className="py-20 md:py-28 px-6">
      <div className="max-w-5xl mx-auto">
        <SectionHeading
          subtitle="Votre praticienne"
          title="Un toucher guidé par le cœur"
        />
        <div className="flex flex-col md:flex-row items-center gap-12 mt-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="flex-shrink-0"
          >
            <div className="w-56 h-56 md:w-72 md:h-72 rounded-full overflow-hidden border-2 border-cac-gold/30 p-1">
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/6c62a123f_praticienne_32.jpg"
                alt="Marine - Praticienne Cœur à Corps"
                className="w-full h-full object-cover rounded-full"
              />
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="text-center md:text-left"
          >
            <h3 className="font-heading text-2xl text-cac-ivory mb-2">Marine</h3>
            <p className="text-xs uppercase tracking-[0.2em] text-cac-gold mb-6">Praticienne Bien-Être & Fondatrice</p>
            <p className="text-sm text-cac-gray leading-relaxed mb-4">
              Marine est la fondatrice et l'essence de Cœur à Corps. Formée à plusieurs techniques — massage intuitif, Lomi-Lomi, drainage lymphatique, massage prénatal, deep tissue doux — elle a développé une approche singulière : un toucher lent, profond, enveloppant, qui accompagne autant le corps que l'émotion.
            </p>
            <p className="text-sm text-cac-gray leading-relaxed mb-4">
              Pour elle, chaque massage est un langage. Un espace où l'on laisse tomber les tensions, mais aussi les attentes, la charge mentale, le bruit intérieur. Marine accueille chaque personne avec une présence rare : attentive, chaleureuse, ancrée, jamais dans la performance.
            </p>
            <p className="text-sm text-cac-gray leading-relaxed mb-4">
              Ses clients parlent d'une "parenthèse sacrée", d'un sentiment de recentrage, d'un toucher qui va "au-delà du geste". Un soin qui résonne encore longtemps après.
            </p>
            <p className="text-sm text-cac-ivory/90 italic leading-relaxed">
              "Je ne transforme pas les corps. Je leur redonne le droit de respirer." — Marine
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}