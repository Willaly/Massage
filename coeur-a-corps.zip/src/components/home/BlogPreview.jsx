import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import SectionHeading from "../shared/SectionHeading";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";
import { base44 } from "@/api/base44Client";
import { Clock, ArrowRight } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function BlogPreview() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = async () => {
    try {
      const data = await base44.entities.BlogPost.filter({ active: true }, '-published_date', 3);
      setPosts(data);
    } catch (error) {
      console.error('Erreur chargement articles:', error);
    }
  };

  if (posts.length === 0) return null;

  return (
    <section className="py-20 md:py-28 px-6">
      <div className="max-w-6xl mx-auto">
        <SectionHeading
          subtitle="Notre blog"
          title="Derniers articles"
          description="Conseils, inspirations et réflexions autour du bien-être."
        />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {posts.map((post, i) => (
            <motion.article
              key={post.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl overflow-hidden group hover:border-cac-gold/20 transition-all"
            >
              {post.image_url && (
                <div className="aspect-[16/10] overflow-hidden">
                  <img
                    src={post.image_url}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
              )}
              <div className="p-6">
                <div className="flex items-center gap-2 mb-3 text-xs text-cac-gray">
                  {post.reading_time && (
                    <span className="flex items-center gap-1">
                      <Clock size={12} /> {post.reading_time} min
                    </span>
                  )}
                </div>
                <h3 className="font-heading text-lg text-cac-ivory mb-2 line-clamp-2">{post.title}</h3>
                <p className="text-sm text-cac-gray leading-relaxed line-clamp-2 mb-4">{post.excerpt}</p>
                <Link
                  to={createPageUrl(`BlogArticle?slug=${post.slug}`)}
                  className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.15em] text-cac-gold hover:text-cac-gold-light transition-colors"
                >
                  Lire
                  <ArrowRight size={14} />
                </Link>
              </div>
            </motion.article>
          ))}
        </div>
        <div className="text-center mt-10">
          <Link
            to={createPageUrl("Blog")}
            className="btn-outline-gold px-8 py-3 rounded-full text-xs uppercase tracking-[0.15em] inline-block"
          >
            Tous les articles
          </Link>
        </div>
      </div>
    </section>
  );
}