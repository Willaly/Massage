import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";
import { ArrowRight } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/8ac30569e_hero_main_61.jpg"
          alt="Massage bien-être"
          className="w-full h-full object-cover"
        />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-black/60" />
        {/* Golden halo */}
        <div className="absolute inset-0 bg-gradient-radial from-amber-900/20 via-transparent to-transparent" 
             style={{ background: 'radial-gradient(ellipse at center, rgba(201,169,110,0.12) 0%, transparent 60%)' }} />
      </div>

      <div className="relative z-10 text-center px-6 max-w-3xl mx-auto">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-xs uppercase tracking-[0.3em] text-cac-gold mb-6 font-body"
        >
          Massages & Bien-être
        </motion.p>
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="font-heading text-4xl md:text-6xl lg:text-7xl text-cac-ivory leading-[1.1] mb-6"
        >
          Cœur à Corps
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="text-cac-ivory/70 text-base md:text-lg font-light leading-relaxed mb-10 max-w-xl mx-auto"
        >
          Libérez vos tensions, reconnectez-vous à votre corps. 
          Massages sur mesure et formations bien-être haut de gamme.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.9 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Link
            to={createPageUrl("RDV")}
            className="bg-cac-gold text-cac-black px-8 py-3.5 rounded-full text-sm uppercase tracking-[0.15em] font-medium inline-flex items-center gap-2 transition-all duration-300 hover:bg-cac-gold-light hover:shadow-lg hover:shadow-cac-gold/30 hover:-translate-y-1"
          >
            Prendre rendez-vous
            <ArrowRight size={16} />
          </Link>
          <Link
            to={createPageUrl("Massages")}
            className="border-2 border-cac-gold text-cac-gold px-8 py-3.5 rounded-full text-sm uppercase tracking-[0.15em] font-medium transition-all duration-300 hover:bg-cac-gold hover:text-cac-black hover:shadow-lg hover:shadow-cac-gold/30 hover:-translate-y-1"
          >
            Nos massages
          </Link>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.1 }}
          className="mt-4"
        >
          <Link
            to={createPageUrl("QuestionnaireChoix")}
            className="border border-cac-gold/50 text-cac-gold/70 px-6 py-3 rounded-full text-xs uppercase tracking-[0.15em] font-medium transition-all duration-300 hover:border-cac-gold hover:text-cac-gold hover:bg-cac-gold/5 hover:shadow-lg hover:shadow-cac-gold/20 hover:-translate-y-1 inline-block"
          >
            ✨ Aide au choix du massage
          </Link>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="w-5 h-8 border border-cac-ivory/30 rounded-full flex justify-center pt-1.5"
        >
          <div className="w-1 h-2 bg-cac-gold rounded-full" />
        </motion.div>
      </motion.div>
    </section>
  );
}