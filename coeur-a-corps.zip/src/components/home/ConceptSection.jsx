import React from "react";
import { motion } from "framer-motion";
import SectionHeading from "../shared/SectionHeading";

export default function ConceptSection() {
  return (
    <section className="py-20 md:py-28 px-6">
      <div className="max-w-5xl mx-auto">
        <SectionHeading
          subtitle="Notre philosophie"
          title="Le massage, un langage du corps"
          description="Un toucher lent, profond, enveloppant. Une approche qui accompagne autant le corps que l'émotion. Pas de performance, juste un espace où respirer."
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mt-12">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="relative rounded-2xl overflow-hidden aspect-[4/5]"
          >
            <img
              src="https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&q=80"
              alt="Concept Cœur à Corps"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-cac-black/50 to-transparent" />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="flex flex-col justify-center"
          >
            <div className="space-y-6">
              <div className="space-y-3">
                <h3 className="font-heading text-xl text-cac-gold">Un toucher qui écoute</h3>
                <p className="text-sm text-cac-gray leading-relaxed">
                  Chaque geste s'adapte à votre corps, à vos tensions, à votre rythme. Rien de mécanique. Tout part de l'écoute.
                </p>
              </div>
              <div className="gold-divider" />
              <div className="space-y-3">
                <h3 className="font-heading text-xl text-cac-gold">Lenteur & profondeur</h3>
                <p className="text-sm text-cac-gray leading-relaxed">
                  Un massage lent ne signifie pas superficiel. C'est la lenteur qui permet au corps de lâcher, aux tensions de se dénouer vraiment.
                </p>
              </div>
              <div className="gold-divider" />
              <div className="space-y-3">
                <h3 className="font-heading text-xl text-cac-gold">Au-delà du soin</h3>
                <p className="text-sm text-cac-gray leading-relaxed">
                  Un moment où vous avez le droit de ne rien faire, de ne rien attendre. Juste être, respirer, vous laisser porter.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}