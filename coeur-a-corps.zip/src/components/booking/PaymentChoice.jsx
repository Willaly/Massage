import React from "react";
import { motion } from "framer-motion";
import { Smartphone } from "lucide-react";

export default function PaymentChoice({ service, onChoice, onBack }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Bouton retour en haut */}
      <button
        onClick={onBack}
        className="text-xs uppercase tracking-wider text-cac-gold hover:text-cac-gold-light transition-colors flex items-center gap-2"
      >
        ← Changer de soin
      </button>

      {/* Récap service */}
      <div className="flex items-center gap-3 p-4 bg-cac-gold/5 border border-cac-gold/30 rounded-xl">
        <div className="w-2 h-2 rounded-full bg-cac-gold flex-shrink-0" />
        <div>
          <p className="text-xs uppercase tracking-wider text-cac-gold mb-0.5">Soin sélectionné</p>
          <p className="text-sm text-cac-ivory font-medium">{service.name}</p>
          <p className="text-xs text-cac-gray">{service.duration_minutes} min — {service.price}€</p>
        </div>
      </div>

      <div>
        <p className="text-center text-sm text-cac-gray mb-4">Comment souhaitez-vous procéder ?</p>
        <div className="flex flex-col gap-3">
          {/* Option 1 : En ligne -5% */}
          <button
            type="button"
            onClick={() => onChoice('online')}
            className="border border-cac-gold px-4 py-4 rounded-xl text-sm flex items-center gap-4 hover:border-cac-gold hover:bg-cac-gold/5 transition-all"
          >
            <span className="text-2xl flex-shrink-0">💳</span>
            <div className="text-left flex-1">
              <p className="font-medium uppercase tracking-wider text-xs text-cac-gold">Choisir le créneau & payer en ligne</p>
              <p className="text-xs text-cac-gray mt-0.5">Règlement sécurisé en ligne</p>
            </div>
            <div className="text-right flex-shrink-0">
              <span className="block text-cac-gold font-heading text-lg">{Math.round(service.price * 0.95)}€</span>
              <span className="bg-cac-gold text-cac-black text-[10px] px-2 py-0.5 rounded-full font-bold">-5%</span>
            </div>
          </button>

          {/* Option 2 : Sur place */}
          <button
            type="button"
            onClick={() => onChoice('onsite')}
            className="border border-cac-gold px-4 py-4 rounded-xl text-sm flex items-center gap-4 hover:border-cac-gold hover:bg-cac-gold/5 transition-all"
          >
            <span className="text-2xl flex-shrink-0">🏠</span>
            <div className="text-left flex-1">
              <p className="font-medium uppercase tracking-wider text-xs text-cac-gold">Choisir le créneau & payer sur place</p>
              <p className="text-xs text-cac-gray mt-0.5">Règlement le jour du soin</p>
            </div>
            <span className="text-cac-gold font-heading text-lg flex-shrink-0">{service.price}€</span>
          </button>

          {/* Option 3 : Planity */}
           <button
             type="button"
             onClick={() => onChoice('planity')}
             className="border border-cac-gold px-4 py-4 rounded-xl text-sm flex items-center gap-4 hover:border-cac-gold hover:bg-cac-gold/5 transition-all"
           >
             <span className="text-2xl flex-shrink-0">📅</span>
             <div className="text-left flex-1">
               <p className="font-medium uppercase tracking-wider text-xs text-cac-gold">Réserver via Planity</p>
               <p className="text-xs text-cac-gray mt-0.5">Questionnaire santé puis redirection</p>
             </div>
             <span className="text-cac-gold font-heading text-xl flex-shrink-0">→</span>
           </button>

           {/* Option 4 : Appel ou WhatsApp */}
           <button
             type="button"
             onClick={() => onChoice('phone')}
             className="border border-cac-gold px-4 py-4 rounded-xl text-sm flex items-center gap-4 hover:border-cac-gold hover:bg-cac-gold/5 transition-all"
           >
             <Smartphone size={24} className="text-cac-gold flex-shrink-0" />
             <div className="text-left flex-1">
               <p className="font-medium uppercase tracking-wider text-xs text-cac-gold">Réserver par appel ou WhatsApp</p>
               <p className="text-xs text-cac-gray mt-0.5">Contactez-nous pour convenir d'un créneau</p>
             </div>
             <span className="text-cac-gold font-heading text-xl flex-shrink-0">→</span>
           </button>
        </div>
      </div>


    </motion.div>
  );
}