import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { base44 } from "@/api/base44Client";
import { Loader2, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function BookingForm({ service, date, time, paymentMode = 'onsite', healthData, onSuccess }) {
  const [form, setForm] = useState({
    client_name: "",
    client_email: "",
    client_phone: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);

    try {
      const bookingData = {
        service_id: service.id,
        service_name: service.name,
        booking_date: format(date, 'yyyy-MM-dd'),
        booking_time: time,
        duration_minutes: service.duration_minutes,
        paymentMode,
        healthData: healthData || {},
        ...form
      };

      const response = await base44.functions.invoke('createBooking', bookingData);

      if (!response.data.success) {
        setError(response.data.error || 'Erreur lors de la réservation');
        return;
      }

      const booking = response.data.booking;

      // Si paiement en ligne → redirection Stripe
      if (paymentMode === 'online') {
        const stripeResponse = await base44.functions.invoke('createStripeSession', {
          service,
          date: format(date, 'yyyy-MM-dd'),
          time,
          paymentMode,
          clientInfo: form,
          bookingId: booking.id,
        });

        if (!stripeResponse.data.success) {
          setError('Erreur lors de la création de la session de paiement');
          return;
        }

        window.location.href = stripeResponse.data.url;
        return;
      }

      onSuccess(booking);
    } catch (err) {
      setError(err.message || 'Une erreur est survenue');
    } finally {
      setSubmitting(false);
    }
  };

  const dateFormatted = format(date, 'EEEE d MMMM yyyy', { locale: fr });
  const displayPrice = paymentMode === 'online'
    ? `${Math.round(service.price * 0.95)}€ (-5% en ligne)`
    : `${service.price}€`;

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      {/* Récapitulatif */}
      <div className="bg-cac-gold/5 border border-cac-gold/20 rounded-xl p-4">
        <h3 className="font-heading text-lg text-cac-ivory mb-2">Récapitulatif</h3>
        <div className="space-y-1 text-sm text-cac-gray">
          <p>📅 {dateFormatted}</p>
          <p>🕐 {time}</p>
          <p>💆 {service.name} ({service.duration_minutes} min)</p>
          <p>💰 {displayPrice}</p>
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-sm text-red-400">
          <AlertCircle size={16} />
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label className="text-xs uppercase tracking-wider text-cac-gray">Nom complet *</Label>
          <Input value={form.client_name} onChange={(e) => handleChange("client_name", e.target.value)}
            required className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold" />
        </div>
        <div className="space-y-2">
          <Label className="text-xs uppercase tracking-wider text-cac-gray">Email *</Label>
          <Input type="email" value={form.client_email} onChange={(e) => handleChange("client_email", e.target.value)}
            required className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold" />
        </div>
        <div className="space-y-2">
          <Label className="text-xs uppercase tracking-wider text-cac-gray">Téléphone *</Label>
          <Input type="tel" value={form.client_phone} onChange={(e) => handleChange("client_phone", e.target.value)}
            required className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold" />
        </div>

        <Button type="submit" disabled={submitting} className="w-full btn-gold rounded-full py-3 text-sm uppercase tracking-[0.15em]">
          {submitting ? (
            <span className="flex items-center justify-center gap-2">
              <Loader2 className="animate-spin" size={16} />
              Réservation en cours...
            </span>
          ) : paymentMode === 'online' ? (
            `Confirmer & payer ${Math.round(service.price * 0.95)}€`
          ) : (
            'Confirmer la réservation'
          )}
        </Button>
      </form>
    </motion.div>
  );
}