import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export default function HealthQuestionnaire({ onBack, onComplete }) {
  const [form, setForm] = useState({
    pregnant: "non",
    allergies: "",
    conditions: "",
    areas: "",
    expectations: ""
  });

  const handleChange = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    onComplete(form);
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <button
        onClick={onBack}
        className="text-xs uppercase tracking-wider text-cac-gold hover:text-cac-gold-light transition-colors"
      >
        ← Modifier date/heure
      </button>

      <div>
        <p className="text-xs uppercase tracking-[0.15em] text-cac-gold mb-1">Questionnaire santé</p>
        <p className="text-sm text-cac-gray">Ce questionnaire confidentiel nous permet de personnaliser votre soin et d'assurer votre sécurité.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="space-y-3">
          <Label className="text-xs uppercase tracking-wider text-cac-gray">Êtes-vous enceinte ?</Label>
          <RadioGroup value={form.pregnant} onValueChange={(v) => handleChange("pregnant", v)} className="flex gap-6">
            <div className="flex items-center gap-2">
              <RadioGroupItem value="oui" id="preg-oui" className="border-cac-gold text-cac-gold" />
              <Label htmlFor="preg-oui" className="text-sm text-cac-ivory cursor-pointer">Oui</Label>
            </div>
            <div className="flex items-center gap-2">
              <RadioGroupItem value="non" id="preg-non" className="border-cac-gold text-cac-gold" />
              <Label htmlFor="preg-non" className="text-sm text-cac-ivory cursor-pointer">Non</Label>
            </div>
          </RadioGroup>
        </div>

        <div className="space-y-2">
          <Label className="text-xs uppercase tracking-wider text-cac-gray">Allergies connues</Label>
          <Input
            value={form.allergies}
            onChange={(e) => handleChange("allergies", e.target.value)}
            placeholder="Huiles essentielles, noix, etc."
            className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold placeholder:text-cac-gray/50"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-xs uppercase tracking-wider text-cac-gray">Conditions médicales</Label>
          <Textarea
            value={form.conditions}
            onChange={(e) => handleChange("conditions", e.target.value)}
            placeholder="Problèmes de dos, hypertension, etc."
            className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold placeholder:text-cac-gray/50 min-h-[80px]"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-xs uppercase tracking-wider text-cac-gray">Zones à éviter ou à privilégier</Label>
          <Input
            value={form.areas}
            onChange={(e) => handleChange("areas", e.target.value)}
            className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-xs uppercase tracking-wider text-cac-gray">Vos attentes pour cette séance</Label>
          <Textarea
            value={form.expectations}
            onChange={(e) => handleChange("expectations", e.target.value)}
            className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold min-h-[80px]"
          />
        </div>

        <Button type="submit" className="w-full btn-gold rounded-full py-3 text-sm uppercase tracking-[0.15em]">
          Continuer →
        </Button>
      </form>
    </motion.div>
  );
}