import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { base44 } from "@/api/base44Client";
// Flow Planity : demande les coordonnées puis redirige directement vers Planity
export default function PlanityQuestionnaire({ service, onBack }) {
  const [clientInfo, setClientInfo] = useState({ name: "", email: "" });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await base44.integrations.Core.SendEmail({
        to: "marineproservices83@gmail.com",
        subject: `Réservation Planity – ${clientInfo.name}`,
        body: `Redirection vers Planity pour une réservation.\n\nClient : ${clientInfo.name} (${clientInfo.email})\nSoin souhaité : ${service.name}`
      });
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
      window.open("https://www.planity.com/coeur-a-corps-83140-six-fours-les-plages", "_blank");
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <button
        onClick={onBack}
        className="text-xs uppercase tracking-wider text-cac-gold hover:text-cac-gold-light transition-colors flex items-center gap-2"
      >
        ← Modifier le mode de paiement
      </button>

      <div className="flex items-center gap-3 p-4 bg-cac-gold/5 border border-cac-gold/30 rounded-xl">
        <div className="w-2 h-2 rounded-full bg-cac-gold flex-shrink-0" />
        <div>
          <p className="text-xs uppercase tracking-wider text-cac-gold mb-0.5">Réservation via Planity</p>
          <p className="text-sm text-cac-ivory font-medium">{service.name}</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <p className="text-sm text-cac-gray">Entrez vos coordonnées avant d'être redirigé vers Planity.</p>
        <div className="space-y-2">
          <Label className="text-xs uppercase tracking-wider text-cac-gray">Nom complet *</Label>
          <Input
            value={clientInfo.name}
            onChange={(e) => setClientInfo(p => ({ ...p, name: e.target.value }))}
            required
            className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold"
          />
        </div>
        <div className="space-y-2">
          <Label className="text-xs uppercase tracking-wider text-cac-gray">Email *</Label>
          <Input
            type="email"
            value={clientInfo.email}
            onChange={(e) => setClientInfo(p => ({ ...p, email: e.target.value }))}
            required
            className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold"
          />
        </div>
        <Button type="submit" disabled={submitting} className="w-full btn-gold rounded-full py-3 text-sm uppercase tracking-[0.15em]">
          {submitting ? "Redirection..." : "Aller sur Planity →"}
        </Button>
      </form>
    </motion.div>
  );
}