import React, { useState } from "react";
import { motion } from "framer-motion";
import { Clock, Euro, Check, HelpCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";

// Regroupe les services par nom
function groupServices(services) {
  const groups = {};
  services.forEach(s => {
    if (!groups[s.name]) {
      groups[s.name] = { name: s.name, description: s.description, options: [] };
    }
    groups[s.name].options.push({ id: s.id, duration_minutes: s.duration_minutes, price: s.price, _raw: s });
  });
  // Trie les options par durée
  Object.values(groups).forEach(g => g.options.sort((a, b) => a.duration_minutes - b.duration_minutes));
  return Object.values(groups);
}

export default function ServiceSelector({ services, selectedService, onSelect }) {
  const groups = groupServices(services);

  // Pour chaque groupe, garde la durée sélectionnée (par défaut la première)
  const [selectedOptions, setSelectedOptions] = useState(() => {
    const init = {};
    groupServices(services).forEach(g => { init[g.name] = 0; });
    return init;
  });

  const handleOptionSelect = (groupName, optionIndex) => {
    setSelectedOptions(prev => ({ ...prev, [groupName]: optionIndex }));
  };

  const handleGroupSelect = (group) => {
    const optIdx = selectedOptions[group.name] ?? 0;
    const option = group.options[optIdx];
    onSelect(option._raw);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <h3 className="font-heading text-xl text-cac-ivory">Choisissez votre soin</h3>
        <Link
          to={createPageUrl("QuestionnaireChoix")}
          className="inline-flex items-center gap-2 text-xs text-cac-gold border border-cac-gold/40 hover:bg-cac-gold/10 px-4 py-2 rounded-full transition-all"
        >
          <HelpCircle size={14} />
          Besoin d'aide pour choisir ?
        </Link>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {groups.map((group, i) => {
          const optIdx = selectedOptions[group.name] ?? 0;
          const currentOption = group.options[optIdx];
          const isSelected = selectedService && group.options.some(o => o.id === selectedService.id);

          return (
            <motion.div
              key={group.name}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className={`p-4 rounded-xl border transition-all ${
                isSelected
                  ? 'border-cac-gold bg-cac-gold/5'
                  : 'border-cac-gray-dark/50 bg-cac-black-light hover:border-cac-gold/30'
              }`}
            >
              {/* Nom + description */}
              <div className="flex items-start justify-between gap-4 mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-heading text-lg text-cac-ivory">{group.name}</h4>
                    {isSelected && <Check size={18} className="text-cac-gold" />}
                  </div>
                  {group.description && (
                    <p className="text-xs text-cac-gray line-clamp-2">{group.description}</p>
                  )}
                </div>
              </div>

              {/* Options de durée (si plusieurs) */}
              {group.options.length > 1 && (
                <div className="flex flex-wrap gap-2 mb-3">
                  {group.options.map((opt, idx) => (
                    <button
                      key={opt.id}
                      onClick={() => handleOptionSelect(group.name, idx)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs border transition-all ${
                        optIdx === idx
                          ? 'bg-cac-gold/20 border-cac-gold text-cac-gold'
                          : 'border-cac-gray-dark/60 text-cac-gray hover:border-cac-gold/40 hover:text-cac-ivory'
                      }`}
                    >
                      <Clock size={11} />
                      {opt.duration_minutes} min — {opt.price}€
                    </button>
                  ))}
                </div>
              )}

              {/* Infos durée/prix pour option unique + bouton sélectionner */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 text-xs text-cac-gray">
                  {group.options.length === 1 && (
                    <>
                      <span className="inline-flex items-center gap-1.5">
                        <Clock size={12} className="text-cac-gold" />
                        {currentOption.duration_minutes} min
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <Euro size={12} className="text-cac-gold" />
                        {currentOption.price}€
                      </span>
                    </>
                  )}
                  {group.options.length > 1 && (
                    <span className="text-xs text-cac-gray/60">
                      Option sélectionnée : {currentOption.duration_minutes} min — {currentOption.price}€
                    </span>
                  )}
                </div>
                <button
                  onClick={() => handleGroupSelect(group)}
                  className="btn-gold px-4 py-1.5 rounded-full text-xs uppercase tracking-wider"
                >
                  Choisir
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}