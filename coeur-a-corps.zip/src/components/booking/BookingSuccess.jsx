import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { CheckCircle2, Calendar, Mail, Home, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { base44 } from "@/api/base44Client";

export default function BookingSuccess({ booking }) {
  const [fullBooking, setFullBooking] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Si on revient de Stripe, on n'a que l'id → on fetch le booking complet
    // Et on confirme le statut en "confirmed"
    if (booking.paidOnline && booking.id && !booking.booking_date) {
      setLoading(true);
      base44.entities.Booking.filter({ id: booking.id })
        .then(async (results) => {
          if (results && results.length > 0) {
            const b = results[0];
            // Mettre à jour le statut en confirmed
            await base44.entities.Booking.update(b.id, { status: 'confirmed' });
            setFullBooking({ ...b, status: 'confirmed' });
          }
        })
        .catch(console.error)
        .finally(() => setLoading(false));
    } else {
      setFullBooking(booking);
    }
  }, [booking]);

  if (loading || !fullBooking) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="animate-spin text-cac-gold" size={32} />
      </div>
    );
  }

  const dateFormatted = fullBooking.booking_date
    ? format(new Date(fullBooking.booking_date), 'EEEE d MMMM yyyy', { locale: fr })
    : '';

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="text-center max-w-lg mx-auto py-8"
    >
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.2, type: "spring" }}
        className="w-20 h-20 mx-auto mb-6 rounded-full bg-cac-gold/10 flex items-center justify-center"
      >
        <CheckCircle2 size={48} className="text-cac-gold" />
      </motion.div>

      <h2 className="font-heading text-3xl text-cac-ivory mb-4">
        {booking.paidOnline ? 'Paiement & réservation confirmés !' : 'Réservation confirmée !'}
      </h2>

      <p className="text-sm text-cac-gray mb-8">
        Votre rendez-vous est bien enregistré. Un email de confirmation a été envoyé à{' '}
        <span className="text-cac-gold">{fullBooking.client_email}</span>
      </p>

      <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6 mb-8 text-left">
        <div className="space-y-3 text-sm">
          {dateFormatted && (
            <div className="flex items-center gap-3">
              <Calendar size={18} className="text-cac-gold" />
              <span className="text-cac-ivory">{dateFormatted} à {fullBooking.booking_time}</span>
            </div>
          )}
          <div className="flex items-center gap-3">
            <span className="text-cac-gold">💆</span>
            <span className="text-cac-ivory">{fullBooking.service_name}</span>
          </div>
          {fullBooking.duration_minutes && (
            <div className="flex items-center gap-3">
              <span className="text-cac-gold">⏱️</span>
              <span className="text-cac-ivory">{fullBooking.duration_minutes} minutes</span>
            </div>
          )}
        </div>
      </div>

      <div className="space-y-4 text-xs text-cac-gray">
        <p className="flex items-center justify-center gap-2">
          <Mail size={14} className="text-cac-gold" />
          Un email de confirmation a été envoyé
        </p>
        <p className="text-cac-ivory/60 italic">
          En cas d'empêchement, merci de nous prévenir au moins 24h à l'avance.
        </p>
      </div>

      <Link
        to={createPageUrl("Home")}
        className="mt-8 btn-outline-gold px-8 py-3 rounded-full text-xs uppercase tracking-[0.15em] inline-flex items-center gap-2"
      >
        <Home size={14} />
        Retour à l'accueil
      </Link>
    </motion.div>
  );
}