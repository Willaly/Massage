import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Calendar } from "@/components/ui/calendar";
import { base44 } from "@/api/base44Client";
import { Clock, Loader2 } from "lucide-react";
import { format, addDays, isBefore, startOfDay } from "date-fns";
import { fr } from "date-fns/locale";

export default function DateTimePicker({ service, selectedDate, selectedTime, onDateChange, onTimeChange }) {
  const [availableSlots, setAvailableSlots] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (selectedDate && service) {
      fetchAvailableSlots();
    }
  }, [selectedDate, service]);

  const fetchAvailableSlots = async () => {
    setLoading(true);
    try {
      const dateStr = format(selectedDate, 'yyyy-MM-dd');
      const response = await base44.functions.invoke('getAvailableSlots', {
        date: dateStr,
        duration_minutes: service.duration_minutes
      });
      setAvailableSlots(response.data.slots || []);
    } catch (error) {
      console.error('Erreur chargement créneaux:', error);
      setAvailableSlots([]);
    } finally {
      setLoading(false);
    }
  };

  const today = startOfDay(new Date());
  const maxDate = addDays(today, 60);

  return (
    <div className="space-y-6">
      <div>
         <div className="flex items-center justify-between mb-4">
           <h3 className="font-heading text-xl text-cac-ivory">Choisissez une date</h3>
           {selectedDate && (
             <span className="text-sm text-cac-gold font-medium">
               {format(selectedDate, 'EEEE d MMMM yyyy', { locale: fr })}
             </span>
           )}
         </div>
        <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-xl p-4 flex justify-center">
           <Calendar
             mode="single"
             selected={selectedDate}
             onSelect={onDateChange}
             disabled={(date) => isBefore(date, today) || date > maxDate}
             locale={fr}
             className="text-cac-ivory"

           />
         </div>
      </div>

      {selectedDate && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h3 className="font-heading text-xl text-cac-ivory mb-4">Choisissez un horaire</h3>
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="animate-spin text-cac-gold" size={24} />
            </div>
          ) : availableSlots.length > 0 ? (
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {availableSlots.map((slot) => (
                <button
                  key={slot.start_time}
                  onClick={() => slot.available && onTimeChange(slot.start_time)}
                  disabled={!slot.available}
                  className={`py-3 px-4 rounded-lg text-sm font-medium transition-all flex flex-col items-center justify-center gap-0.5 ${
                    !slot.available
                      ? 'bg-cac-black-light border border-cac-gray-dark/30 text-cac-gray/40 cursor-not-allowed opacity-50'
                      : selectedTime === slot.start_time
                        ? 'bg-cac-gold text-cac-black'
                        : 'bg-cac-black-light border border-cac-gray-dark/50 text-cac-ivory hover:border-cac-gold/50'
                  }`}
                >
                  <span className="flex items-center gap-1">
                    <Clock size={13} className="inline-block" />
                    {slot.start_time}
                  </span>
                  {!slot.available && (
                    <span className="text-[10px] uppercase tracking-wide text-cac-gray/50">Indisponible</span>
                  )}
                </button>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 bg-cac-black-light border border-cac-gray-dark/50 rounded-xl">
              <p className="text-sm text-cac-gray">Aucun créneau disponible ce jour.</p>
              <p className="text-xs text-cac-gray mt-2">Essayez une autre date.</p>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
}