import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Heart, Users, Briefcase, ArrowRight } from "lucide-react";

const massageOptions = [
  { id: "harmonie60", name: "Massage Harmonie", duration: "60 min", price: 70 },
  { id: "harmonie90", name: "Massage Harmonie", duration: "90 min", price: 100 },
  { id: "palper-rouler", name: "Palper-Rouler Manuel", duration: "60 min", price: 80 },
  { id: "maderotherapie", name: "Madérothérapie", duration: "60 min", price: 85 },
  { id: "drainage", name: "Drainage Lymphatique", duration: "60 min", price: 90 },
  { id: "5-continents", name: "Modelage des 5 Continents", duration: "60 min", price: 95 },
  { id: "expanse", name: "Expanse Therapy", duration: "60 min", price: 90 },
  { id: "libre", name: "Montant libre", duration: "", price: 0 },
];

const styleOptions = [
  { id: "romantique", name: "Romantique", icon: Heart, desc: "Pour couple ou amour" },
  { id: "famille_amis", name: "Famille & Amis", icon: Users, desc: "Pour proches" },
  { id: "collegues", name: "Professionnel", icon: Briefcase, desc: "Pour collègues" },
];

export default function GiftCardForm({ formData, setFormData, onSubmit, loading }) {
  const [errors, setErrors] = useState({});

  const selectedMassage = massageOptions.find(m => m.id === formData.massageType);
  const totalAmount = selectedMassage?.id === "libre" ? parseInt(formData.amount) || 0 : selectedMassage?.price || 0;

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors(prev => ({ ...prev, [field]: null }));
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.massageType) newErrors.massageType = "Veuillez choisir un massage";
    if (formData.massageType === "libre" && (!formData.amount || formData.amount < 30)) {
      newErrors.amount = "Montant minimum 30€";
    }
    if (!formData.recipientName) newErrors.recipientName = "Nom du destinataire requis";
    if (!formData.style) newErrors.style = "Veuillez choisir un style";
    if (!formData.buyerEmail) newErrors.buyerEmail = "Email requis";
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      onSubmit({ ...formData, amount: totalAmount });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Massage selection */}
      <div className="space-y-4">
        <Label className="text-sm uppercase tracking-wider text-cac-gold">Étape 1 • Choisissez le soin</Label>
        <RadioGroup value={formData.massageType} onValueChange={(v) => handleChange("massageType", v)}>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {massageOptions.map(option => (
              <label
                key={option.id}
                className={`relative flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                  formData.massageType === option.id
                    ? "border-cac-gold bg-cac-gold/5"
                    : "border-cac-gray-dark hover:border-cac-gold/30"
                }`}
              >
                <RadioGroupItem value={option.id} id={option.id} className="mt-1" />
                <div className="flex-1">
                  <p className="text-sm text-cac-ivory font-medium">{option.name}</p>
                  <p className="text-xs text-cac-gray">{option.duration}</p>
                  <p className="text-sm text-cac-gold mt-1">{option.price > 0 ? `${option.price}€` : "À définir"}</p>
                </div>
              </label>
            ))}
          </div>
        </RadioGroup>
        {errors.massageType && <p className="text-xs text-red-400">{errors.massageType}</p>}
      </div>

      {/* Custom amount for "libre" */}
      {formData.massageType === "libre" && (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="space-y-2">
          <Label className="text-xs uppercase tracking-wider text-cac-gray">Montant (minimum 30€)</Label>
          <Input
            type="number"
            min="30"
            value={formData.amount}
            onChange={(e) => handleChange("amount", e.target.value)}
            placeholder="Entrez le montant"
            className="bg-transparent border-cac-gray-dark text-cac-ivory"
          />
          {errors.amount && <p className="text-xs text-red-400">{errors.amount}</p>}
        </motion.div>
      )}

      {/* Message section - step 2 */}
      <div className="space-y-4">
        <Label className="text-sm uppercase tracking-wider text-cac-gold">Étape 2 • Personnalisez votre message</Label>
        <div>
          <Label className="text-xs uppercase tracking-wider text-cac-gray">Pour (destinataire) *</Label>
          <Input
            value={formData.recipientName}
            onChange={(e) => handleChange("recipientName", e.target.value)}
            placeholder="ex: Sophie Martin"
            className="bg-transparent border-cac-gray-dark text-cac-ivory mt-2"
          />
          {errors.recipientName && <p className="text-xs text-red-400 mt-1">{errors.recipientName}</p>}
        </div>

        <div>
          <Label className="text-xs uppercase tracking-wider text-cac-gray">De la part de</Label>
          <Input
            value={formData.senderName}
            onChange={(e) => handleChange("senderName", e.target.value)}
            placeholder="Votre nom"
            className="bg-transparent border-cac-gray-dark text-cac-ivory mt-2"
          />
        </div>

        <div>
          <Label className="text-xs uppercase tracking-wider text-cac-gray">Message personnalisé (optionnel)</Label>
          <Textarea
            value={formData.message}
            onChange={(e) => handleChange("message", e.target.value)}
            placeholder="Ajoutez un message sur la carte..."
            className="bg-transparent border-cac-gray-dark text-cac-ivory mt-2 min-h-[80px]"
            maxLength={200}
          />
          <p className="text-xs text-cac-gray mt-1">{formData.message?.length || 0}/200 caractères</p>
        </div>
      </div>

      {/* Style selection - step 3 */}
      <div className="space-y-4">
        <Label className="text-sm uppercase tracking-wider text-cac-gold">Étape 3 • Choisissez le style de la carte</Label>
        <div className="grid grid-cols-3 gap-3">
          {styleOptions.map(style => {
            const Icon = style.icon;
            return (
              <button
                key={style.id}
                type="button"
                onClick={() => handleChange("style", style.id)}
                className={`p-4 rounded-xl border text-center transition-all ${
                  formData.style === style.id
                    ? "border-cac-gold bg-cac-gold/5"
                    : "border-cac-gray-dark hover:border-cac-gold/30"
                }`}
              >
                <Icon size={20} className={`mx-auto mb-2 ${formData.style === style.id ? "text-cac-gold" : "text-cac-gray"}`} />
                <p className="text-xs text-cac-ivory font-medium">{style.name}</p>
                <p className="text-[10px] text-cac-gray mt-1">{style.desc}</p>
              </button>
            );
          })}
        </div>
        {errors.style && <p className="text-xs text-red-400">{errors.style}</p>}
      </div>

      {/* Buyer info - step 4 */}
      <div className="space-y-4">
        <Label className="text-sm uppercase tracking-wider text-cac-gold">Étape 4 • Vos coordonnées</Label>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <Label className="text-xs uppercase tracking-wider text-cac-gray">Email *</Label>
            <Input
              type="email"
              value={formData.buyerEmail}
              onChange={(e) => handleChange("buyerEmail", e.target.value)}
              placeholder="votre@email.com"
              className="bg-transparent border-cac-gray-dark text-cac-ivory mt-2"
            />
            {errors.buyerEmail && <p className="text-xs text-red-400 mt-1">{errors.buyerEmail}</p>}
          </div>
          <div>
            <Label className="text-xs uppercase tracking-wider text-cac-gray">Téléphone</Label>
            <Input
              type="tel"
              value={formData.buyerPhone}
              onChange={(e) => handleChange("buyerPhone", e.target.value)}
              placeholder="06 XX XX XX XX"
              className="bg-transparent border-cac-gray-dark text-cac-ivory mt-2"
            />
          </div>
        </div>
      </div>

      {/* Total and submit */}
      <div className="pt-6 border-t border-cac-gray-dark/50">
        <div className="flex items-center justify-between mb-6">
          <p className="text-sm text-cac-gray">Total à payer</p>
          <p className="font-heading text-3xl text-cac-gold">{totalAmount}€</p>
        </div>
        <Button
          type="submit"
          disabled={loading || totalAmount === 0}
          className="w-full btn-gold rounded-full py-6 text-sm uppercase tracking-[0.15em] disabled:opacity-50"
        >
          {loading ? "Traitement..." : "Procéder au paiement"}
          {!loading && <ArrowRight size={16} className="ml-2" />}
        </Button>
        <p className="text-xs text-cac-gray text-center mt-4">
          Vous recevrez la carte cadeau par email au format PDF après paiement
        </p>
      </div>
    </form>
  );
}