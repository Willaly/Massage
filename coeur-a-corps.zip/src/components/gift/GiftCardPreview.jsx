import React from "react";
import { motion } from "framer-motion";
import { Gift, Heart, Users, Briefcase, Sparkles } from "lucide-react";

const massageOptions = [
  { id: "decouverte", name: "Massage Découverte", duration: "60 min" },
  { id: "harmonie", name: "Massage Harmonie", duration: "90 min" },
  { id: "pierres", name: "Massage Pierres Chaudes", duration: "75 min" },
  { id: "duo", name: "Massage Duo", duration: "60 min × 2" },
  { id: "libre", name: "Montant libre", duration: "" },
];

// Logo de coeurs entrelaçés simple SVG
const HeartLogo = ({ color, size = 40 }) => (
  <svg width={size} height={size} viewBox="0 0 50 50" fill="none">
    <path d="M25 42L8 25C4 21 4 14 8 10C12 6 19 6 23 10L25 12L27 10C31 6 38 6 42 10C46 14 46 21 42 25L25 42Z" 
      fill={color} opacity="0.3" />
    <path d="M25 42L35 32C39 28 39 21 35 17C31 13 24 13 20 17L25 22L30 17C32 15 36 15 38 17C40 19 40 23 38 25L25 38V42Z"
      fill={color} opacity="0.5" />
  </svg>
);

export default function GiftCardPreview({ data, style, orderNumber }) {
  const currentMassage = massageOptions.find(m => m.id === data.massageType);

  // STYLE ROMANTIQUE - Police script, layout fleuri, fond avec motifs
  if (style === "romantique") {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative w-full max-w-2xl mx-auto aspect-[1.6/1] rounded-3xl overflow-hidden shadow-2xl"
        style={{
          background: "linear-gradient(135deg, #FFE8E8 0%, #FFD9E5 25%, #FFEEF0 50%, #FFE5D9 75%, #FFF0E8 100%)"
        }}
      >
        {/* Fond avec motifs floraux */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-24 h-24 rounded-full bg-pink-300 blur-3xl" />
          <div className="absolute bottom-10 right-10 w-32 h-32 rounded-full bg-rose-300 blur-3xl" />
          <div className="absolute top-1/2 left-1/4 w-20 h-20 rounded-full bg-salmon-300 blur-2xl" />
        </div>

        {/* Coeurs décoratifs */}
        {[...Array(8)].map((_, i) => (
          <Heart 
            key={i}
            size={12 + Math.random() * 12}
            className="absolute fill-current opacity-10"
            style={{
              color: ["#E06B7D", "#FF9AA2", "#FFB3BA"][Math.floor(Math.random() * 3)],
              top: `${10 + Math.random() * 80}%`,
              left: `${5 + Math.random() * 90}%`,
              transform: `rotate(${Math.random() * 360}deg)`
            }}
          />
        ))}

        {/* Contenu */}
        <div className="relative h-full flex flex-col items-center justify-center p-4 sm:p-6 pb-14 sm:pb-16">
          <div className="mb-2">
            <HeartLogo color="#E06B7D" size={36} />
          </div>
          
          <h3 style={{ 
            fontFamily: "'Dancing Script', cursive",
            fontSize: "clamp(1.25rem, 3.5vw, 2rem)",
            color: "#8B4049",
            marginBottom: "0.25rem",
            textShadow: "0 1px 2px rgba(0,0,0,0.05)"
          }}>
            Carte Cadeau
          </h3>

          {currentMassage && currentMassage.id !== "libre" && (
            <p style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(0.875rem, 2.5vw, 1.25rem)",
              color: "#C17178",
              fontStyle: "italic",
              marginBottom: "0.5rem"
            }}>
              {currentMassage.name}
            </p>
          )}
          
          {data.amount > 0 && (
            <p style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(1.75rem, 5vw, 3rem)",
              color: "#E06B7D",
              fontWeight: "600",
              marginBottom: "0.75rem"
            }}>
              {data.amount}€
            </p>
          )}

          {data.message && (
            <div className="max-w-xs mb-3 px-3">
              <p style={{
                fontFamily: "'Dancing Script', cursive",
                fontSize: "clamp(0.75rem, 1.75vw, 0.9375rem)",
                color: "#A85963",
                lineHeight: "1.5",
                textAlign: "center"
              }}>
                "{data.message}"
              </p>
            </div>
          )}

          {data.recipientName && (
            <div className="mt-2 text-center">
              <p className="text-[10px] uppercase tracking-widest text-pink-400 mb-0.5">Pour</p>
              <p style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "clamp(0.875rem, 2.25vw, 1.125rem)",
                color: "#8B4049",
                fontWeight: "500"
              }}>
                {data.recipientName}
              </p>
            </div>
          )}

          {data.senderName && (
            <p style={{
              fontFamily: "'Dancing Script', cursive",
              fontSize: "clamp(0.6875rem, 1.75vw, 0.875rem)",
              color: "#C17178",
              marginTop: "0.5rem"
            }}>
              De la part de {data.senderName}
            </p>
          )}

          {/* Branding en bas */}
          <div className="absolute bottom-3 sm:bottom-4 left-0 right-0 text-center px-4">
            <p style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(0.625rem, 1.5vw, 0.75rem)",
              letterSpacing: "0.15em",
              color: "#E06B7D"
            }}>
              CŒUR À CORPS
            </p>
            <p className="text-[8px] text-pink-300 mt-0.5">Massages & Bien-être</p>
          </div>

          {orderNumber && (
            <div className="absolute bottom-0.5 right-1.5">
              <p className="text-[6px] text-pink-200 opacity-40">N° {orderNumber}</p>
            </div>
          )}
        </div>
      </motion.div>
    );
  }

  // STYLE FAMILLE & AMIS - Layout photo/scrapbook, police chaleureuse, fond coloré
  if (style === "famille_amis") {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative w-full max-w-2xl mx-auto aspect-[1.6/1] rounded-3xl overflow-hidden shadow-2xl"
        style={{
          background: "linear-gradient(135deg, #E8F4F8 0%, #FFF4E0 50%, #FFE8F0 100%)"
        }}
      >
        {/* Fond avec formes ludiques */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-40 h-40 rounded-full bg-cyan-200 opacity-20 blur-3xl" />
          <div className="absolute bottom-0 right-0 w-48 h-48 rounded-full bg-amber-200 opacity-20 blur-3xl" />
          <div className="absolute top-1/3 right-1/4 w-32 h-32 rounded-full bg-pink-200 opacity-15 blur-2xl" />
        </div>

        {/* Étoiles et confetti décoratifs */}
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute"
            style={{
              top: `${10 + Math.random() * 80}%`,
              left: `${5 + Math.random() * 90}%`,
            }}
          >
            {i % 2 === 0 ? (
              <Sparkles size={10 + Math.random() * 8} className="text-cyan-400 opacity-30" />
            ) : (
              <div 
                className="w-2 h-2 rounded-full opacity-30"
                style={{ background: ["#5B9AAF", "#F4A261", "#E76F51"][Math.floor(Math.random() * 3)] }}
              />
            )}
          </div>
        ))}

        {/* Bordure style scrapbook */}
        <div className="absolute inset-4 border-4 border-dashed border-white/40 rounded-2xl pointer-events-none" />

        {/* Contenu */}
        <div className="relative h-full flex flex-col items-center justify-center p-4 sm:p-6 pb-12">
          <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-4 sm:p-6 shadow-lg border border-white/60 max-w-md w-full">
            <div className="flex items-center justify-center gap-2 mb-3">
              <Users size={24} className="text-cyan-600" />
              <h3 style={{
                fontFamily: "'Comic Sans MS', 'Marker Felt', cursive",
                fontSize: "clamp(1.25rem, 3.5vw, 1.75rem)",
                color: "#2C5C6F",
                fontWeight: "bold"
              }}>
                Carte Cadeau
              </h3>
            </div>

            {currentMassage && currentMassage.id !== "libre" && (
              <p style={{
                fontFamily: "'Quicksand', sans-serif",
                fontSize: "clamp(0.875rem, 2.5vw, 1.125rem)",
                color: "#5B9AAF",
                fontWeight: "600",
                textAlign: "center",
                marginBottom: "0.5rem"
              }}>
                {currentMassage.name}
              </p>
            )}
            
            {data.amount > 0 && (
              <p style={{
                fontFamily: "'Fredoka One', cursive",
                fontSize: "clamp(1.75rem, 5vw, 2.5rem)",
                color: "#F4A261",
                textAlign: "center",
                marginBottom: "0.75rem"
              }}>
                {data.amount}€
              </p>
            )}

            {data.message && (
              <div className="bg-white/60 rounded-xl p-3 mb-3">
                <p style={{
                  fontFamily: "'Patrick Hand', cursive",
                  fontSize: "clamp(0.75rem, 1.75vw, 0.9375rem)",
                  color: "#2C5C6F",
                  lineHeight: "1.6",
                  textAlign: "center"
                }}>
                  "{data.message}"
                </p>
              </div>
            )}

            <div className="text-center space-y-1.5">
              {data.recipientName && (
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-cyan-500 font-bold">Offert à</p>
                  <p style={{
                    fontFamily: "'Quicksand', sans-serif",
                    fontSize: "clamp(0.875rem, 2.25vw, 1.125rem)",
                    color: "#2C5C6F",
                    fontWeight: "700"
                  }}>
                    {data.recipientName}
                  </p>
                </div>
              )}

              {data.senderName && (
                <p style={{
                  fontFamily: "'Patrick Hand', cursive",
                  fontSize: "clamp(0.75rem, 1.75vw, 0.875rem)",
                  color: "#5B9AAF"
                }}>
                  De: {data.senderName}
                </p>
              )}
            </div>
          </div>

          {/* Branding */}
          <div className="absolute bottom-2 sm:bottom-3 left-0 right-0 text-center">
            <p style={{
              fontFamily: "'Quicksand', sans-serif",
              fontSize: "clamp(0.625rem, 1.5vw, 0.75rem)",
              fontWeight: "700",
              letterSpacing: "0.1em",
              color: "#5B9AAF"
            }}>
              CŒUR À CORPS
            </p>
          </div>

          {orderNumber && (
            <div className="absolute bottom-0.5 right-1.5">
              <p className="text-[6px] text-cyan-400 opacity-40">N° {orderNumber}</p>
            </div>
          )}
        </div>
      </motion.div>
    );
  }

  // STYLE PROFESSIONNEL - Layout épuré, police moderne, fond minimaliste
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="relative w-full max-w-2xl mx-auto aspect-[1.6/1] rounded-3xl overflow-hidden shadow-2xl"
      style={{
        background: "linear-gradient(135deg, #F8F8F5 0%, #FAFAF8 50%, #F5F5F0 100%)"
      }}
    >
      {/* Motif géométrique subtil */}
      <div className="absolute inset-0 opacity-5">
        <svg width="100%" height="100%">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#8B7355" strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      {/* Bordure élégante */}
      <div className="absolute inset-6 border border-neutral-300 rounded-xl" />
      <div className="absolute inset-8 border border-neutral-200" />

      {/* Contenu */}
      <div className="relative h-full flex flex-col items-center justify-center p-4 sm:p-8 pb-14 sm:pb-16">
        <div className="flex items-center gap-2 mb-4">
          <HeartLogo color="#8B7355" size={28} />
          <div className="h-10 w-px bg-neutral-300" />
          <Briefcase size={22} className="text-neutral-600" strokeWidth={1.5} />
        </div>

        <h3 style={{
          fontFamily: "'Montserrat', sans-serif",
          fontSize: "clamp(1rem, 2.5vw, 1.5rem)",
          color: "#4A3F2F",
          fontWeight: "300",
          letterSpacing: "0.2em",
          textTransform: "uppercase",
          marginBottom: "0.75rem"
        }}>
          Carte Cadeau
        </h3>

        <div className="w-20 h-px bg-neutral-400 mb-4" />

        {currentMassage && currentMassage.id !== "libre" && (
          <p style={{
            fontFamily: "'Lora', serif",
            fontSize: "clamp(0.9375rem, 2.5vw, 1.25rem)",
            color: "#8B7355",
            fontWeight: "400",
            marginBottom: "0.5rem",
            textAlign: "center"
          }}>
            {currentMassage.name}
          </p>
        )}
        
        {data.amount > 0 && (
          <p style={{
            fontFamily: "'Montserrat', sans-serif",
            fontSize: "clamp(2rem, 5vw, 3.25rem)",
            color: "#4A3F2F",
            fontWeight: "200",
            marginBottom: "1rem"
          }}>
            {data.amount}€
          </p>
        )}

        {data.message && (
          <div className="max-w-sm mb-4 px-4">
            <p style={{
              fontFamily: "'Lora', serif",
              fontSize: "clamp(0.75rem, 1.75vw, 0.9375rem)",
              color: "#6B6B6B",
              lineHeight: "1.7",
              textAlign: "center",
              fontStyle: "italic"
            }}>
              "{data.message}"
            </p>
          </div>
        )}

        <div className="text-center space-y-3">
          {data.recipientName && (
            <div>
              <p style={{
                fontFamily: "'Montserrat', sans-serif",
                fontSize: "0.5625rem",
                letterSpacing: "0.2em",
                color: "#A68968",
                textTransform: "uppercase",
                marginBottom: "0.25rem"
              }}>
                Destinataire
              </p>
              <p style={{
                fontFamily: "'Lora', serif",
                fontSize: "clamp(0.875rem, 2.25vw, 1.125rem)",
                color: "#4A3F2F",
                fontWeight: "500"
              }}>
                {data.recipientName}
              </p>
            </div>
          )}

          {data.senderName && (
            <p style={{
              fontFamily: "'Lora', serif",
              fontSize: "clamp(0.75rem, 1.75vw, 0.875rem)",
              color: "#8B7355",
              fontStyle: "italic"
            }}>
              De la part de {data.senderName}
            </p>
          )}
        </div>

        {/* Branding */}
        <div className="absolute bottom-3 sm:bottom-4 left-0 right-0 text-center">
          <p style={{
            fontFamily: "'Montserrat', sans-serif",
            fontSize: "clamp(0.625rem, 1.5vw, 0.75rem)",
            fontWeight: "400",
            letterSpacing: "0.25em",
            color: "#8B7355"
          }}>
            CŒUR À CORPS
          </p>
          <p className="text-[8px] text-neutral-400 mt-0.5 tracking-widest">MASSAGES & BIEN-ÊTRE</p>
        </div>

        {orderNumber && (
          <div className="absolute bottom-0.5 right-1.5">
            <p className="text-[6px] text-neutral-300 opacity-60">N° {orderNumber}</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}