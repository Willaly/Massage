import React from "react";
import { motion } from "framer-motion";
import { Star } from "lucide-react";

export default function TestimonialCard({ name, text, rating = 5, index = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6 md:p-8"
    >
      <div className="flex gap-1 mb-4">
        {Array.from({ length: rating }).map((_, i) => (
          <Star key={i} size={14} className="fill-cac-gold text-cac-gold" />
        ))}
      </div>
      <p className="text-sm text-cac-ivory/80 leading-relaxed italic mb-6">"{text}"</p>
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-cac-gold/20 flex items-center justify-center">
          <span className="font-heading text-cac-gold text-sm">{name.charAt(0)}</span>
        </div>
        <span className="text-sm font-medium text-cac-ivory">{name}</span>
      </div>
    </motion.div>
  );
}