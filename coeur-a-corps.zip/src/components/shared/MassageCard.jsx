import React, { useState } from "react";
import { motion } from "framer-motion";
import { Clock, Euro, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "../../utils";

export default function MassageCard({ title, description, durations, prices, duration, price, cure, image, badge, slug, index = 0 }) {
  const [selectedDuration, setSelectedDuration] = useState(0);
  
  // Support old API (single duration/price) and new API (multiple durations/prices)
  const displayDurations = durations || (duration ? [duration] : []);
  const displayPrices = prices || (price ? [price] : []);
  const hasCure = !!cure;
  const hasMultipleDurations = displayDurations.length > 1;

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="group relative overflow-hidden rounded-2xl bg-cac-black-light border border-cac-gray-dark/50 hover:border-cac-gold/30 transition-all duration-500 cursor-pointer"
    >
      <Link
        to={slug ? createPageUrl(`MassageDetail?id=${slug}`) : createPageUrl("Massages")}
        className="absolute inset-0 z-20"
      />
      {badge && (
        <div className="absolute top-4 right-4 z-10 bg-cac-gold text-cac-black px-3 py-1 rounded-full text-xs font-medium uppercase tracking-wider">
          {badge}
        </div>
      )}
      <div className="aspect-[4/3] overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-cac-black via-cac-black/20 to-transparent" />
      </div>
      <div className="p-6 relative">
        {hasMultipleDurations && (
          <div className="mb-4 flex gap-2">
            {displayDurations.map((dur, i) => (
              <button
                key={i}
                onClick={() => setSelectedDuration(i)}
                className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                  selectedDuration === i
                    ? 'bg-cac-gold text-cac-black'
                    : 'bg-cac-black border border-cac-gray-dark/50 text-cac-gray hover:border-cac-gold/30'
                }`}
              >
                {dur}
              </button>
            ))}
          </div>
        )}
        <div className="flex items-center gap-3 mb-3">
          <Clock size={14} className="text-cac-gold" />
          <span className="text-xs text-cac-gray">{displayDurations[selectedDuration] || duration}</span>
          {displayPrices[selectedDuration] && (
            <>
              <span className="text-cac-gray-dark">•</span>
              <span className="text-xs text-cac-gold font-medium">{displayPrices[selectedDuration]}</span>
            </>
          )}
        </div>
        {hasCure && (
          <p className="text-[11px] text-cac-gold/80 mb-3">{cure}</p>
        )}
        <h3 className="font-heading text-xl text-cac-ivory mb-2">{title}</h3>
        <p className="text-sm text-cac-gray leading-relaxed line-clamp-2">{description}</p>
        <div className="inline-flex items-center gap-2 mt-4 text-xs uppercase tracking-[0.15em] text-cac-gold hover:text-cac-gold-light transition-colors relative z-30">
          Découvrir
          <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
        </div>
      </div>
    </motion.div>
  );
}