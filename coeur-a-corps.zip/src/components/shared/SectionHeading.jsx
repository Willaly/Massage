import React from "react";
import { motion } from "framer-motion";

export default function SectionHeading({ subtitle, title, description, light = false, centered = true }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.7 }}
      className={`${centered ? 'text-center' : ''} mb-12 md:mb-16`}
    >
      {subtitle && (
        <p className="text-sm uppercase tracking-[0.2em] text-cac-gold mb-4 font-body font-medium">
          {subtitle}
        </p>
      )}
      <h2 className={`font-heading text-3xl md:text-4xl lg:text-5xl font-medium leading-tight ${light ? 'text-cac-black' : 'text-cac-ivory'}`}>
        {title}
      </h2>
      {description && (
        <p className={`mt-4 max-w-2xl ${centered ? 'mx-auto' : ''} text-sm md:text-base leading-relaxed ${light ? 'text-gray-600' : 'text-cac-gray'}`}>
          {description}
        </p>
      )}
      <div className="gold-divider mx-auto mt-6" />
    </motion.div>
  );
}