import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "./utils";
import { Menu, X, Home, Heart, GraduationCap, Phone, Calendar, Gift, ShoppingBag, Star, Info, FileText, MessageSquare, ChevronUp } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { CartProvider } from "./components/boutique/CartContext";

const navLinks = [
  { name: "Accueil", page: "Home", icon: Home },
  { name: "Quel massage ?", page: "QuestionnaireChoix", icon: Heart },
  { 
    name: "Prestations", 
    icon: GraduationCap,
    submenu: [
      { name: "Massages", page: "Massages" },
      { name: "Formations", page: "Formations" },
      { name: "Offrir", page: "Offrir" }
    ]
  },
  { name: "Boutique", page: "Boutique", icon: ShoppingBag },
  { name: "Tarifs", page: "Tarifs", icon: FileText },
  { name: "Blog", page: "Blog", icon: FileText },
  { name: "À propos", page: "APropos", icon: Info },
  { name: "Témoignages", page: "Temoignages", icon: Star },
  { name: "Contact", page: "Contact", icon: Phone },
];

const mobileBottomNav = [
  { name: "Accueil", page: "Home", icon: Home },
  { name: "Massages", page: "Massages", icon: Heart },
  { name: "Offrir", page: "Offrir", icon: Gift },
  { name: "RDV", page: "RDV", icon: Calendar },
  { name: "Boutique", page: "Boutique", icon: ShoppingBag },
];

export default function Layout({ children, currentPageName }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <CartProvider>
    <div className="min-h-screen bg-cac-black text-cac-ivory font-body overflow-x-hidden">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600&family=Inter:wght@300;400;500;600&display=swap');

        :root {
          --cac-black: #0A0A0A;
          --cac-black-light: #141414;
          --cac-ivory: #FFFBF0;
          --cac-ivory-muted: #F5EFDF;
          --cac-gold: #C9A96E;
          --cac-gold-light: #D4BA85;
          --cac-gold-dark: #A8894E;
          --cac-gray: #aaa;
          --cac-gray-dark: #333;
        }

        .font-heading { font-family: 'Playfair Display', Georgia, serif; }
        .font-body { font-family: 'Inter', system-ui, sans-serif; }

        .bg-cac-black { background-color: var(--cac-black); }
        .bg-cac-black-light { background-color: var(--cac-black-light); }
        .bg-cac-ivory { background-color: var(--cac-ivory); }
        .bg-cac-gold { background-color: var(--cac-gold); }
        .text-cac-black { color: var(--cac-black); }
        .text-cac-ivory { color: var(--cac-ivory); }
        .text-cac-ivory-muted { color: var(--cac-ivory-muted); }
        .text-cac-gold { color: var(--cac-gold); }
        .text-cac-gold-light { color: var(--cac-gold-light); }
        .text-cac-gray { color: var(--cac-gray); }
        .border-cac-gold { border-color: var(--cac-gold); }
        .border-cac-gray-dark { border-color: var(--cac-gray-dark); }

        .btn-gold {
          background-color: var(--cac-gold);
          color: var(--cac-black);
          font-family: 'Inter', sans-serif;
          font-weight: 500;
          letter-spacing: 0.05em;
          transition: all 0.3s ease;
        }
        .btn-gold:hover {
          background-color: var(--cac-gold-light);
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(201,169,110,0.4);
        }
        .btn-outline-gold {
          border: 2px solid var(--cac-gold);
          color: var(--cac-gold);
          font-family: 'Inter', sans-serif;
          font-weight: 500;
          letter-spacing: 0.05em;
          transition: all 0.3s ease;
        }
        .btn-outline-gold:hover {
          border-color: var(--cac-gold);
          background-color: var(--cac-gold);
          color: var(--cac-black);
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(201,169,110,0.4);
        }

        .gold-divider {
          width: 60px;
          height: 1px;
          background: linear-gradient(90deg, transparent, var(--cac-gold), transparent);
        }

        .marquee-track {
          display: flex;
          animation: marquee 30s linear infinite;
        }
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }

        * { scrollbar-width: thin; scrollbar-color: var(--cac-gold) var(--cac-black); }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: var(--cac-black); }
        ::-webkit-scrollbar-thumb { background: var(--cac-gold); border-radius: 3px; }
      `}</style>

      {/* HEADER DESKTOP */}
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'bg-cac-black/95 backdrop-blur-md shadow-lg shadow-black/20' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="flex items-center justify-between h-20">
            <Link to={createPageUrl("Home")} className="flex items-center gap-3 group">
              <span className="font-heading text-2xl tracking-wide text-cac-ivory group-hover:text-cac-gold transition-colors">
                Cœur à Corps
              </span>
            </Link>

            {/* Desktop nav */}
            <nav className="hidden lg:flex items-center gap-3">
              {navLinks.map(link => link.submenu ? (
                <div key={link.name} className="relative group">
                  <button className="text-xs uppercase tracking-[0.05em] font-medium text-cac-ivory/70 hover:text-cac-gold transition-colors flex items-center gap-1">
                    {link.name}
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                  <div className="absolute top-full left-0 mt-2 w-48 bg-cac-black/95 backdrop-blur-md border border-cac-gray-dark/50 rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 shadow-xl">
                    {link.submenu.map(sub => (
                      <Link
                        key={sub.page}
                        to={createPageUrl(sub.page)}
                        className="block px-4 py-3 text-xs uppercase tracking-wider text-cac-ivory/70 hover:text-cac-gold hover:bg-cac-gold/5 transition-colors first:rounded-t-lg last:rounded-b-lg"
                      >
                        {sub.name}
                      </Link>
                    ))}
                  </div>
                </div>
              ) : link.page ? (
                <Link
                  key={link.page}
                  to={createPageUrl(link.page)}
                  className={`text-xs uppercase tracking-[0.05em] font-medium transition-colors duration-300 ${
                    currentPageName === link.page ? 'text-cac-gold' : 'text-cac-ivory/70 hover:text-cac-gold'
                  }`}
                >
                  {link.name}
                </Link>
              ) : null)}
            </nav>

            <div className="hidden lg:flex items-center gap-3">
              <a
                href="https://wa.me/33650543613"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-outline-gold px-4 py-2 rounded-full text-xs uppercase tracking-[0.15em] flex items-center gap-2"
              >
                <MessageSquare size={14} />
                WhatsApp
              </a>
              <Link
                to={createPageUrl("RDV")}
                className="btn-gold px-6 py-2.5 rounded-full text-xs uppercase tracking-[0.15em]"
              >
                Prendre RDV
              </Link>
            </div>

            {/* Mobile hamburger */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="lg:hidden p-2 text-cac-ivory"
            >
              {menuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </header>

      {/* MOBILE FULLSCREEN MENU */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40 bg-cac-black/98 backdrop-blur-lg flex flex-col items-center justify-center overflow-y-auto py-20"
          >
            <nav className="flex flex-col items-center gap-3">
              {navLinks.flatMap((link, i) => link.submenu ? 
                link.submenu.map((sub, si) => (
                  <motion.div
                    key={sub.page}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: (i + si * 0.3) * 0.05 }}
                  >
                    <Link
                      to={createPageUrl(sub.page)}
                      className={`font-heading text-xl tracking-wide transition-colors ${
                        currentPageName === sub.page ? 'text-cac-gold' : 'text-cac-ivory/80 hover:text-cac-gold'
                      }`}
                    >
                      {sub.name}
                    </Link>
                  </motion.div>
                ))
              : link.page ? (
                <motion.div
                  key={link.page}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <Link
                    to={createPageUrl(link.page)}
                    className={`font-heading text-xl tracking-wide transition-colors ${
                      currentPageName === link.page ? 'text-cac-gold' : 'text-cac-ivory/80 hover:text-cac-gold'
                    }`}
                  >
                    {link.name}
                  </Link>
                </motion.div>
              ) : null
              )}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: navLinks.length * 0.05 }}
                className="mt-4"
              >
                <Link
                  to={createPageUrl("RDV")}
                  className="btn-gold px-8 py-3 rounded-full text-sm uppercase tracking-[0.15em]"
                >
                  Prendre RDV
                </Link>
              </motion.div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MAIN CONTENT */}
      <main>{children}</main>

      {/* FOOTER */}
      <footer className="bg-cac-black-light border-t border-cac-gray-dark">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 py-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
            <div>
              <h3 className="font-heading text-2xl text-cac-ivory mb-4">Cœur à Corps</h3>
              <p className="text-cac-gray text-sm leading-relaxed">
                Massages sur mesure & formations bien-être haut de gamme. 
                Une parenthèse de douceur pour reconnecter le corps et l'esprit.
              </p>
            </div>
            <div>
              <h4 className="text-xs uppercase tracking-[0.2em] text-cac-gold mb-5">Navigation</h4>
              <nav className="flex flex-col gap-3">
                {navLinks.slice(0, 6).map(link => link.page ? (
                  <Link
                    key={link.page}
                    to={createPageUrl(link.page)}
                    className="text-sm text-cac-gray hover:text-cac-gold transition-colors"
                  >
                    {link.name}
                  </Link>
                ) : null)}
              </nav>
            </div>
            <div>
              <h4 className="text-xs uppercase tracking-[0.2em] text-cac-gold mb-5">Contact</h4>
              <div className="flex flex-col gap-3 text-sm text-cac-gray">
                <a
                  href="https://www.google.com/maps/dir/?api=1&destination=342+Promenade+General+Charles+de+Gaulle+Six-Fours-les-Plages"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-cac-gold transition-colors"
                >
                  📍 Salon Mastroianni, 342 Prom. Général Charles de Gaulle, 83140 Six-Fours-les-Plages
                </a>
                <a href="tel:+33650543613" className="hover:text-cac-gold transition-colors">📞 06 50 54 36 13</a>
                <a href="mailto:contact@coeuracorps.fr" className="hover:text-cac-gold transition-colors">✉️ marineproservices83@gmail.com</a>
                <a
                  href="https://wa.me/33650543613"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 mt-2 text-cac-gold hover:text-cac-gold-light transition-colors"
                >
                  <MessageSquare size={16} />
                  WhatsApp
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-cac-gray-dark pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-xs text-cac-gray">
              © {new Date().getFullYear()} Cœur à Corps — Tous droits réservés
            </p>
            <div className="flex items-center gap-6">
              <Link to="/MentionsLegales" className="text-xs text-cac-gray hover:text-cac-gold transition-colors">Mentions légales</Link>
            </div>
          </div>
        </div>
      </footer>

      {/* MOBILE BOTTOM NAV */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-cac-black/95 backdrop-blur-md border-t border-cac-gray-dark">
        <nav className="flex items-center justify-around h-16 px-2">
          {mobileBottomNav.map(link => {
            const Icon = link.icon;
            const isActive = currentPageName === link.page;
            return (
              <Link
                key={link.page}
                to={createPageUrl(link.page)}
                className={`flex flex-col items-center gap-1 py-1 px-3 transition-colors ${
                  isActive ? 'text-cac-gold' : 'text-cac-gray'
                }`}
              >
                <Icon size={18} strokeWidth={isActive ? 2 : 1.5} />
                <span className="text-[10px] uppercase tracking-wider">{link.name}</span>
              </Link>
            );
          })}
        </nav>
      </div>

      {/* WhatsApp floating CTA */}
      <a
        href="https://wa.me/33650543613"
        target="_blank"
        rel="noopener noreferrer"
        className="hidden lg:flex fixed bottom-8 right-8 z-40 bg-green-600 hover:bg-green-500 text-white w-14 h-14 rounded-full items-center justify-center shadow-2xl transition-all hover:scale-110"
      >
        <MessageSquare size={24} />
      </a>

      {/* Bottom spacer for mobile nav */}
      <div className="md:hidden h-16" />
    </div>
    </CartProvider>
  );
}