import React from "react";
import { motion } from "framer-motion";
import SectionHeading from "../components/shared/SectionHeading";
import { Heart, Award, Leaf } from "lucide-react";

const values = [
  { icon: Heart, title: "Écoute vraie", text: "Chaque séance commence par un temps d'échange. On prend le temps de comprendre votre état du jour, vos besoins, vos limites." },
  { icon: Award, title: "Savoir-faire", text: "Des techniques maîtrisées (Lomi-Lomi, drainage, deep tissue) au service d'un toucher personnalisé et respectueux." },
  { icon: Leaf, title: "Authenticité", text: "Pas de marketing, pas de promesses miracles. Juste un soin honnête, ancré, qui fait du bien." },
];

export default function APropos() {
  return (
    <div className="pt-28 pb-20">
      <div className="px-6 max-w-5xl mx-auto">
        <SectionHeading
          subtitle="Notre histoire"
          title="À propos de Cœur à Corps"
          description="Massages sur mesure et formations bien-être. Un espace où le corps retrouve le droit de respirer."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-20">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative rounded-2xl overflow-hidden aspect-[4/5]"
          >
            <img
              src="https://images.unsplash.com/photo-1600334129128-685c5582fd35?w=800&q=80"
              alt="Cœur à Corps"
              className="w-full h-full object-cover"
            />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex flex-col justify-center space-y-6"
          >
            <h3 className="font-heading text-2xl text-cac-ivory">Marine, fondatrice</h3>
            <p className="text-sm text-cac-gray leading-relaxed">
              Marine a créé Cœur à Corps après plusieurs années de formation et de pratique. Formée au massage intuitif, 
              Lomi-Lomi, drainage lymphatique, massage prénatal et deep tissue doux, elle a développé une approche unique : 
              un toucher lent, profond, enveloppant, qui accompagne autant le corps que l'émotion.
            </p>
            <p className="text-sm text-cac-gray leading-relaxed">
              Pour elle, chaque massage est un langage. Un espace où l'on laisse tomber les tensions, mais aussi les attentes, 
              la charge mentale, le bruit intérieur. Marine accueille chaque personne avec une présence rare : attentive, 
              chaleureuse, ancrée, jamais dans la performance.
            </p>
            <p className="text-sm text-cac-gray leading-relaxed">
              Au-delà des massages, Cœur à Corps propose des formations pour transmettre cet art du toucher. 
              Chaque formation allie théorie, pratique et développement personnel.
            </p>
          </motion.div>
        </div>

        <SectionHeading subtitle="Ce qui nous guide" title="Nos valeurs" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {values.map((v, i) => {
            const Icon = v.icon;
            return (
              <motion.div
                key={v.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center p-8 bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl"
              >
                <div className="w-14 h-14 mx-auto mb-5 rounded-full bg-cac-gold/10 flex items-center justify-center">
                  <Icon size={24} className="text-cac-gold" strokeWidth={1.5} />
                </div>
                <h3 className="font-heading text-xl text-cac-ivory mb-3">{v.title}</h3>
                <p className="text-sm text-cac-gray leading-relaxed">{v.text}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}