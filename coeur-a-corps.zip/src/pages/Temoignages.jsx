import React from "react";
import SectionHeading from "../components/shared/SectionHeading";
import TestimonialCard from "../components/shared/TestimonialCard";

const allTestimonials = [
  { name: "Sophie L.", text: "Marine a une présence rare. On sent qu'elle est vraiment là, à l'écoute. Son massage m'a permis de lâcher prise comme jamais. Une parenthèse sacrée.", rating: 5 },
  { name: "Thomas M.", text: "Le massage Harmonie a dépassé mes attentes. Un toucher profond mais jamais agressif, qui va chercher les tensions sans forcer. Mon corps respire enfin.", rating: 5 },
  { name: "Claire D.", text: "Un moment suspendu. J'ai senti mon corps se détendre en profondeur, et même des émotions remonter. Marine accompagne tout ça avec une douceur incroyable.", rating: 5 },
  { name: "Julie R.", text: "J'ai offert une carte cadeau à ma sœur. Elle m'a dit que c'était le plus beau présent qu'elle ait reçu. Le massage l'a vraiment reconnectée à elle-même.", rating: 5 },
  { name: "Marc B.", text: "En tant que sportif, je cherchais un massage profond. Le Deep Tissue de Marine est parfait : efficace sans être brutal. Je reviens régulièrement.", rating: 5 },
  { name: "Émilie S.", text: "Enceinte de 7 mois, j'avais le dos en compote. Le massage prénatal m'a soulagée immédiatement. Un vrai cocon de douceur pour futures mamans.", rating: 5 },
  { name: "Antoine L.", text: "Les pierres chaudes, c'était une première. L'effet est bluffant : une chaleur qui détend en profondeur. Je me suis senti apaisé pendant des jours.", rating: 5 },
  { name: "Léa P.", text: "J'ai suivi la formation Initiation. Marine est pédagogue, bienveillante. Je masse maintenant mes proches avec confiance. Merci pour cette transmission !", rating: 5 },
  { name: "Nathalie V.", text: "Cœur à Corps est devenu mon rendez-vous mensuel indispensable. Un lieu où je peux vraiment me poser, respirer, lâcher le mental.", rating: 5 },
];

export default function Temoignages() {
  return (
    <div className="pt-28 pb-20">
      <div className="px-6 max-w-5xl mx-auto">
        <SectionHeading
          subtitle="Vos retours"
          title="Témoignages"
          description="La satisfaction de nos clients est notre plus belle récompense. Découvrez leurs expériences."
        />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {allTestimonials.map((t, i) => (
            <TestimonialCard key={t.name} {...t} index={i} />
          ))}
        </div>
      </div>
    </div>
  );
}