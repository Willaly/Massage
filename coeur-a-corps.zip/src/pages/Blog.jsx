import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import SectionHeading from "../components/shared/SectionHeading";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { base44 } from "@/api/base44Client";
import { Clock, ArrowRight, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const categories = [
  { id: "all", name: "Tous" },
  { id: "effets_massage", name: "Effets du massage" },
  { id: "choisir_preparer", name: "Choisir & préparer" },
  { id: "art_toucher", name: "Art du toucher" },
  { id: "ambiance_sensoriel", name: "Ambiance & sensoriel" },
  { id: "confiance_local", name: "Confiance & local" }
];

export default function Blog() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState("all");

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = async () => {
    try {
      const data = await base44.entities.BlogPost.filter({ active: true }, '-published_date');
      setPosts(data);
    } catch (error) {
      console.error('Erreur chargement articles:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredPosts = selectedCategory === "all" 
    ? posts 
    : posts.filter(p => p.category === selectedCategory);

  return (
    <div className="pt-28 pb-20">
      <div className="px-6 max-w-6xl mx-auto">
        <SectionHeading
          subtitle="Notre blog"
          title="Bien-être & Massage"
          description="Conseils, techniques et réflexions autour de l'art du toucher et du bien-être."
        />

        {/* Categories */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-12">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-5 py-2 rounded-full text-xs uppercase tracking-wider transition-all ${
                selectedCategory === cat.id
                  ? 'bg-cac-gold text-cac-black'
                  : 'bg-cac-black-light border border-cac-gray-dark/50 text-cac-gray hover:border-cac-gold/30'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="animate-spin text-cac-gold" size={32} />
          </div>
        ) : filteredPosts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map((post, i) => (
              <motion.article
                key={post.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Link
                  to={createPageUrl(`BlogArticle?slug=${post.slug}`)}
                  className="block bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl overflow-hidden group hover:border-cac-gold/20 transition-all cursor-pointer"
                >
                  {post.image_url && (
                    <div className="aspect-[16/10] overflow-hidden">
                      <img
                        src={post.image_url}
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      />
                    </div>
                  )}
                  <div className="p-6">
                    <div className="flex items-center gap-3 mb-3 text-xs text-cac-gray">
                      <span>{format(new Date(post.published_date || post.created_date), 'd MMM yyyy', { locale: fr })}</span>
                      {post.reading_time && (
                        <>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Clock size={12} /> {post.reading_time} min
                          </span>
                        </>
                      )}
                    </div>
                    <h3 className="font-heading text-xl text-cac-ivory mb-3 line-clamp-2">{post.title}</h3>
                    <p className="text-sm text-cac-gray leading-relaxed line-clamp-3 mb-4">{post.excerpt}</p>
                    <span className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.15em] text-cac-gold group-hover:text-cac-gold-light transition-colors">
                      Lire l'article
                      <ArrowRight size={14} />
                    </span>
                  </div>
                </Link>
              </motion.article>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <p className="text-cac-gray">Aucun article dans cette catégorie pour le moment.</p>
          </div>
        )}
      </div>
    </div>
  );
}