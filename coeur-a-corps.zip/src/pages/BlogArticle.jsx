import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Loader2, Clock, ArrowLeft, Send } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import ReactMarkdown from "react-markdown";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

export default function BlogArticle() {
  const [post, setPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [commentForm, setCommentForm] = useState({ author_name: "", author_email: "", content: "" });
  const [submittingComment, setSubmittingComment] = useState(false);

  const urlParams = new URLSearchParams(window.location.search);
  const slug = urlParams.get('slug');

  useEffect(() => {
    if (slug) loadPost();
  }, [slug]);

  const loadPost = async () => {
    try {
      const posts = await base44.entities.BlogPost.filter({ slug, active: true });
      if (posts.length > 0) {
        setPost(posts[0]);
        loadComments(posts[0].id);
      }
    } catch (error) {
      console.error('Erreur chargement article:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadComments = async (postId) => {
    try {
      const data = await base44.entities.Comment.filter({ blog_post_id: postId, status: "approved" }, '-created_date');
      setComments(data);
    } catch (error) {
      console.error('Erreur chargement commentaires:', error);
    }
  };

  const handleCommentSubmit = async (e) => {
    e.preventDefault();
    setSubmittingComment(true);
    try {
      await base44.entities.Comment.create({
        blog_post_id: post.id,
        ...commentForm
      });
      setCommentForm({ author_name: "", author_email: "", content: "" });
      alert("Merci ! Votre commentaire sera publié après modération.");
    } catch (error) {
      console.error('Erreur envoi commentaire:', error);
    } finally {
      setSubmittingComment(false);
    }
  };

  if (loading) {
    return (
      <div className="pt-28 pb-20 flex items-center justify-center min-h-screen">
        <Loader2 className="animate-spin text-cac-gold" size={32} />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="pt-28 pb-20 px-6 text-center">
        <h1 className="font-heading text-2xl text-cac-ivory mb-4">Article non trouvé</h1>
        <Link to={createPageUrl("Blog")} className="text-cac-gold hover:text-cac-gold-light">← Retour au blog</Link>
      </div>
    );
  }

  return (
    <div className="pt-28 pb-20">
      <article className="px-6 max-w-4xl mx-auto">
        <Link to={createPageUrl("Blog")} className="inline-flex items-center gap-2 text-xs uppercase tracking-wider text-cac-gold hover:text-cac-gold-light transition-colors mb-8">
          <ArrowLeft size={14} />
          Retour au blog
        </Link>

        {post.image_url && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="aspect-[21/9] rounded-2xl overflow-hidden mb-8"
          >
            <img src={post.image_url} alt={post.title} className="w-full h-full object-cover" />
          </motion.div>
        )}

        <motion.header
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4 text-xs text-cac-gray">
            <span>{format(new Date(post.published_date || post.created_date), 'd MMMM yyyy', { locale: fr })}</span>
            {post.reading_time && (
              <>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Clock size={12} /> {post.reading_time} min de lecture
                </span>
              </>
            )}
          </div>
          <h1 className="font-heading text-3xl md:text-5xl text-cac-ivory leading-tight">{post.title}</h1>
          <div className="gold-divider mt-6" />
        </motion.header>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="max-w-none mb-16"
        >
          <ReactMarkdown
            components={{
              h1: () => null,
              h2: ({ children }) => (
                <h2 className="font-heading text-2xl md:text-3xl text-cac-ivory font-bold mt-10 mb-5 leading-tight border-l-2 border-cac-gold pl-4">{children}</h2>
              ),
              h3: ({ children }) => (
                <h3 className="font-heading text-xl md:text-2xl text-cac-gold font-semibold mt-8 mb-4">{children}</h3>
              ),
              h4: ({ children }) => (
                <h4 className="font-body text-base text-cac-ivory font-semibold uppercase tracking-wider mt-6 mb-3">{children}</h4>
              ),
              p: ({ children }) => (
                <p className="text-cac-gray leading-relaxed text-base md:text-lg mb-6">{children}</p>
              ),
              strong: ({ children }) => (
                <strong className="text-cac-ivory font-semibold">{children}</strong>
              ),
              em: ({ children }) => (
                <em className="text-cac-ivory/80 italic">{children}</em>
              ),
              ul: ({ children }) => (
                <ul className="space-y-2 mb-6 ml-2">{children}</ul>
              ),
              ol: ({ children }) => (
                <ol className="space-y-2 mb-6 ml-2 list-decimal list-inside">{children}</ol>
              ),
              li: ({ children }) => (
                <li className="text-cac-gray text-base md:text-lg leading-relaxed flex gap-3 items-start">
                  <span className="text-cac-gold mt-1.5 flex-shrink-0">•</span>
                  <span>{children}</span>
                </li>
              ),
              blockquote: ({ children }) => (
                <blockquote className="border-l-4 border-cac-gold bg-cac-gold/5 pl-6 pr-4 py-4 my-8 rounded-r-lg">
                  <div className="text-cac-ivory/90 italic font-heading text-lg leading-relaxed">{children}</div>
                </blockquote>
              ),
              hr: () => (
                <div className="gold-divider mx-auto my-10" />
              ),
              a: ({ children, href }) => (
                <a href={href} className="text-cac-gold hover:text-cac-gold-light underline underline-offset-2 transition-colors">{children}</a>
              ),
              code: ({ children }) => (
                <code className="bg-cac-black-light border border-cac-gray-dark text-cac-gold px-2 py-0.5 rounded text-sm font-mono">{children}</code>
              ),
            }}
          >
            {post.content}
          </ReactMarkdown>
        </motion.div>

        {/* Comments */}
        <div className="border-t border-cac-gray-dark/50 pt-12">
          <h3 className="font-heading text-2xl text-cac-ivory mb-8">Commentaires ({comments.length})</h3>
          
          {comments.length > 0 && (
            <div className="space-y-6 mb-12">
              {comments.map(comment => (
                <div key={comment.id} className="bg-cac-black-light border border-cac-gray-dark/50 rounded-xl p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-full bg-cac-gold/20 flex items-center justify-center">
                      <span className="font-heading text-cac-gold">{comment.author_name.charAt(0)}</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-cac-ivory">{comment.author_name}</p>
                      <p className="text-xs text-cac-gray">{format(new Date(comment.created_date), 'd MMM yyyy', { locale: fr })}</p>
                    </div>
                  </div>
                  <p className="text-sm text-cac-gray leading-relaxed">{comment.content}</p>
                </div>
              ))}
            </div>
          )}

          <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6 md:p-8">
            <h4 className="font-heading text-xl text-cac-ivory mb-6">Laisser un commentaire</h4>
            <form onSubmit={handleCommentSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs uppercase tracking-wider text-cac-gray">Nom</Label>
                  <Input
                    value={commentForm.author_name}
                    onChange={(e) => setCommentForm({...commentForm, author_name: e.target.value})}
                    required
                    className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs uppercase tracking-wider text-cac-gray">Email</Label>
                  <Input
                    type="email"
                    value={commentForm.author_email}
                    onChange={(e) => setCommentForm({...commentForm, author_email: e.target.value})}
                    required
                    className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-xs uppercase tracking-wider text-cac-gray">Commentaire</Label>
                <Textarea
                  value={commentForm.content}
                  onChange={(e) => setCommentForm({...commentForm, content: e.target.value})}
                  required
                  className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold min-h-[100px]"
                />
              </div>
              <Button
                type="submit"
                disabled={submittingComment}
                className="btn-gold rounded-full px-6 py-2.5 text-xs uppercase tracking-[0.15em] flex items-center gap-2"
              >
                {submittingComment ? <Loader2 className="animate-spin" size={14} /> : <Send size={14} />}
                Envoyer
              </Button>
            </form>
          </div>
        </div>
      </article>
    </div>
  );
}