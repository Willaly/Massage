import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Settings as SettingsIcon, Calendar, ShoppingBag, Gift, Users, FileText, Clock, Check, X, TrendingUp, Euro, BarChart3 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";

export default function Admin() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const currentUser = await base44.auth.me();
      if (!currentUser || currentUser.role !== 'admin') {
        base44.auth.redirectToLogin(window.location.href);
        return;
      }
      setUser(currentUser);
    } catch (error) {
      base44.auth.redirectToLogin(window.location.href);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin text-cac-gold" size={32} />
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="pt-28 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="font-heading text-3xl md:text-4xl text-cac-ivory mb-2">Administration</h1>
          <p className="text-sm text-cac-gray">Bienvenue, {user.full_name}</p>
        </div>

        <Tabs defaultValue="analytics" className="space-y-6">
          <TabsList className="bg-cac-black-light border border-cac-gray-dark/50 flex-wrap h-auto gap-1 p-1">
            <TabsTrigger value="analytics" className="data-[state=active]:bg-cac-gold data-[state=active]:text-cac-black">
              <TrendingUp className="w-4 h-4 mr-2" />
              Analytique
            </TabsTrigger>
            <TabsTrigger value="bookings" className="data-[state=active]:bg-cac-gold data-[state=active]:text-cac-black">
              <Calendar className="w-4 h-4 mr-2" />
              Réservations
            </TabsTrigger>
            <TabsTrigger value="orders" className="data-[state=active]:bg-cac-gold data-[state=active]:text-cac-black">
              <ShoppingBag className="w-4 h-4 mr-2" />
              Commandes
            </TabsTrigger>
            <TabsTrigger value="giftcards" className="data-[state=active]:bg-cac-gold data-[state=active]:text-cac-black">
              <Gift className="w-4 h-4 mr-2" />
              Cartes cadeaux
            </TabsTrigger>
            <TabsTrigger value="opening_hours" className="data-[state=active]:bg-cac-gold data-[state=active]:text-cac-black">
              <Calendar className="w-4 h-4 mr-2" />
              Horaires
            </TabsTrigger>
            <TabsTrigger value="clients" className="data-[state=active]:bg-cac-gold data-[state=active]:text-cac-black">
              <Users className="w-4 h-4 mr-2" />
              Clients
            </TabsTrigger>
            <TabsTrigger value="content" className="data-[state=active]:bg-cac-gold data-[state=active]:text-cac-black">
              <FileText className="w-4 h-4 mr-2" />
              Contenus
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-cac-gold data-[state=active]:text-cac-black">
              <SettingsIcon className="w-4 h-4 mr-2" />
              Paramètres
            </TabsTrigger>
          </TabsList>

          <TabsContent value="analytics">
            <AdminAnalytics />
          </TabsContent>

          <TabsContent value="bookings">
            <AdminBookings />
          </TabsContent>

          <TabsContent value="orders">
            <AdminOrders />
          </TabsContent>

          <TabsContent value="giftcards">
            <AdminGiftCards />
          </TabsContent>

          <TabsContent value="opening_hours">
            <AdminOpeningHours />
          </TabsContent>

          <TabsContent value="clients">
            <AdminClients />
          </TabsContent>

          <TabsContent value="content">
            <AdminContent />
          </TabsContent>

          <TabsContent value="settings">
            <AdminSettings />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function AdminAnalytics() {
  const [bookings, setBookings] = useState([]);
  const [orders, setOrders] = useState([]);
  const [giftCards, setGiftCards] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.Booking.list('-booking_date', 500),
      base44.entities.Order.list('-created_date', 500),
      base44.entities.GiftCard.list('-created_date', 500),
    ]).then(([b, o, g]) => {
      setBookings(b);
      setOrders(o);
      setGiftCards(g);
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-cac-gold" /></div>;

  // KPIs
  const confirmedBookings = bookings.filter(b => b.status === 'confirmed' || b.status === 'completed');
  const paidOrders = orders.filter(o => o.status === 'paid');
  const paidGiftCards = giftCards.filter(g => g.status === 'paid' || g.status === 'used');

  // CA total estimé (réservations confirmées)
  const services = {};
  confirmedBookings.forEach(b => {
    if (!services[b.service_name]) services[b.service_name] = 0;
    services[b.service_name]++;
  });

  // CA par mois (6 derniers mois)
  const now = new Date();
  const monthlyData = Array.from({ length: 6 }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
    const label = d.toLocaleDateString('fr-FR', { month: 'short', year: '2-digit' });
    const monthBookings = confirmedBookings.filter(b => {
      const bd = new Date(b.booking_date);
      return bd.getMonth() === d.getMonth() && bd.getFullYear() === d.getFullYear();
    });
    const monthOrders = paidOrders.filter(o => {
      const od = new Date(o.created_date);
      return od.getMonth() === d.getMonth() && od.getFullYear() === d.getFullYear();
    });
    const monthGifts = paidGiftCards.filter(g => {
      const gd = new Date(g.created_date);
      return gd.getMonth() === d.getMonth() && gd.getFullYear() === d.getFullYear();
    });
    return {
      label,
      rdv: monthBookings.length,
      commandes: monthOrders.reduce((s, o) => s + (o.total_amount || 0), 0),
      cadeaux: monthGifts.reduce((s, g) => s + (g.amount || 0), 0),
    };
  });

  // Ce mois-ci
  const thisMonth = monthlyData[5];
  const lastMonth = monthlyData[4];

  // Top services
  const topServices = Object.entries(services)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([name, count]) => ({ name: name.length > 20 ? name.slice(0, 20) + '…' : name, count }));

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'RDV confirmés', value: confirmedBookings.length, sub: `${thisMonth.rdv} ce mois`, icon: Calendar },
          { label: 'Commandes payées', value: paidOrders.length, sub: `${paidOrders.reduce((s, o) => s + (o.total_amount || 0), 0)}€ total`, icon: ShoppingBag },
          { label: 'Cartes cadeaux', value: paidGiftCards.length, sub: `${paidGiftCards.reduce((s, g) => s + (g.amount || 0), 0)}€ total`, icon: Gift },
          { label: 'Ce mois (RDV)', value: thisMonth.rdv, sub: `vs ${lastMonth.rdv} le mois dernier`, icon: TrendingUp },
        ].map(({ label, value, sub, icon: Icon }) => (
          <div key={label} className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <Icon size={16} className="text-cac-gold" />
              <p className="text-xs uppercase tracking-wider text-cac-gray">{label}</p>
            </div>
            <p className="font-heading text-3xl text-cac-ivory mb-1">{value}</p>
            <p className="text-xs text-cac-gray">{sub}</p>
          </div>
        ))}
      </div>

      {/* Graphique RDV par mois */}
      <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6">
        <h3 className="font-heading text-lg text-cac-ivory mb-6">Réservations par mois (6 derniers mois)</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={monthlyData}>
            <XAxis dataKey="label" tick={{ fill: '#aaa', fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: '#aaa', fontSize: 12 }} axisLine={false} tickLine={false} allowDecimals={false} />
            <Tooltip contentStyle={{ background: '#141414', border: '1px solid #333', borderRadius: 8, color: '#FFFBF0' }} />
            <Bar dataKey="rdv" name="RDV" fill="#C9A96E" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Top services */}
      {topServices.length > 0 && (
        <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6">
          <h3 className="font-heading text-lg text-cac-ivory mb-6">Services les plus réservés</h3>
          <div className="space-y-3">
            {topServices.map(({ name, count }) => (
              <div key={name} className="flex items-center gap-3">
                <p className="text-sm text-cac-ivory w-48 flex-shrink-0">{name}</p>
                <div className="flex-1 bg-cac-gray-dark/30 rounded-full h-2">
                  <div className="bg-cac-gold h-2 rounded-full" style={{ width: `${(count / topServices[0].count) * 100}%` }} />
                </div>
                <p className="text-sm text-cac-gold font-medium w-8 text-right">{count}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Dernières réservations */}
      <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6">
        <h3 className="font-heading text-lg text-cac-ivory mb-4">Prochains RDV</h3>
        <div className="space-y-2">
          {bookings
            .filter(b => b.status !== 'cancelled' && new Date(b.booking_date) >= new Date(new Date().toDateString()))
            .sort((a, b) => new Date(a.booking_date) - new Date(b.booking_date))
            .slice(0, 8)
            .map(b => (
              <div key={b.id} className="flex items-center justify-between py-2 border-b border-cac-gray-dark/30 last:border-0">
                <div>
                  <p className="text-sm text-cac-ivory">{b.client_name}</p>
                  <p className="text-xs text-cac-gray">{b.service_name}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-cac-gold">{new Date(b.booking_date + 'T12:00:00').toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' })}</p>
                  <p className="text-xs text-cac-gray">{b.booking_time}</p>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}

function AdminBookings() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBookings();
  }, []);

  const loadBookings = async () => {
    try {
      const data = await base44.entities.Booking.list('-created_date', 100);
      setBookings(data);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-cac-gold" /></div>;

  return (
    <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6">
      <h2 className="font-heading text-2xl text-cac-ivory mb-6">Réservations ({bookings.length})</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-cac-gray-dark/50 text-cac-gray">
              <th className="text-left py-3 px-2">Date/Heure</th>
              <th className="text-left py-3 px-2">Client</th>
              <th className="text-left py-3 px-2">Service</th>
              <th className="text-left py-3 px-2">Contact</th>
              <th className="text-left py-3 px-2">Statut</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map(b => (
              <tr key={b.id} className="border-b border-cac-gray-dark/30 hover:bg-cac-black/30">
                <td className="py-3 px-2 text-cac-ivory">{b.booking_date} {b.booking_time}</td>
                <td className="py-3 px-2 text-cac-ivory">{b.client_name}</td>
                <td className="py-3 px-2 text-cac-gold">{b.service_name}</td>
                <td className="py-3 px-2 text-cac-gray text-xs">{b.client_email}<br/>{b.client_phone}</td>
                <td className="py-3 px-2">
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    b.status === 'confirmed' ? 'bg-green-600/20 text-green-400' :
                    b.status === 'pending' ? 'bg-yellow-600/20 text-yellow-400' :
                    b.status === 'cancelled' ? 'bg-red-600/20 text-red-400' :
                    'bg-blue-600/20 text-blue-400'
                  }`}>
                    {b.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    try {
      const data = await base44.entities.Order.list('-created_date', 100);
      setOrders(data);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-cac-gold" /></div>;

  return (
    <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6">
      <h2 className="font-heading text-2xl text-cac-ivory mb-6">Commandes ({orders.length})</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-cac-gray-dark/50 text-cac-gray">
              <th className="text-left py-3 px-2">Date</th>
              <th className="text-left py-3 px-2">Client</th>
              <th className="text-left py-3 px-2">Type</th>
              <th className="text-left py-3 px-2">Montant</th>
              <th className="text-left py-3 px-2">Statut</th>
            </tr>
          </thead>
          <tbody>
            {orders.map(o => (
              <tr key={o.id} className="border-b border-cac-gray-dark/30 hover:bg-cac-black/30">
                <td className="py-3 px-2 text-cac-ivory">{new Date(o.created_date).toLocaleDateString('fr-FR')}</td>
                <td className="py-3 px-2 text-cac-ivory">{o.client_name}<br/><span className="text-xs text-cac-gray">{o.client_email}</span></td>
                <td className="py-3 px-2 text-cac-gold">{o.order_type}</td>
                <td className="py-3 px-2 text-cac-gold font-medium">{o.total_amount}€</td>
                <td className="py-3 px-2">
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    o.status === 'paid' ? 'bg-green-600/20 text-green-400' :
                    o.status === 'pending' ? 'bg-yellow-600/20 text-yellow-400' :
                    'bg-gray-600/20 text-gray-400'
                  }`}>
                    {o.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AdminGiftCards() {
  const [giftCards, setGiftCards] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadGiftCards();
  }, []);

  const loadGiftCards = async () => {
    try {
      const data = await base44.entities.GiftCard.list('-created_date', 100);
      setGiftCards(data);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-cac-gold" /></div>;

  return (
    <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6">
      <h2 className="font-heading text-2xl text-cac-ivory mb-6">Cartes cadeaux ({giftCards.length})</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-cac-gray-dark/50 text-cac-gray">
              <th className="text-left py-3 px-2">Date</th>
              <th className="text-left py-3 px-2">Pour</th>
              <th className="text-left py-3 px-2">Massage</th>
              <th className="text-left py-3 px-2">Montant</th>
              <th className="text-left py-3 px-2">Code</th>
              <th className="text-left py-3 px-2">Statut</th>
            </tr>
          </thead>
          <tbody>
            {giftCards.map(g => (
              <tr key={g.id} className="border-b border-cac-gray-dark/30 hover:bg-cac-black/30">
                <td className="py-3 px-2 text-cac-ivory">{new Date(g.created_date).toLocaleDateString('fr-FR')}</td>
                <td className="py-3 px-2 text-cac-ivory">{g.recipient_name}</td>
                <td className="py-3 px-2 text-cac-gold text-xs">{g.massage_type}</td>
                <td className="py-3 px-2 text-cac-gold font-medium">{g.amount}€</td>
                <td className="py-3 px-2 text-cac-gray text-xs">{g.unique_code}</td>
                <td className="py-3 px-2">
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    g.status === 'paid' ? 'bg-green-600/20 text-green-400' :
                    g.status === 'used' ? 'bg-blue-600/20 text-blue-400' :
                    'bg-yellow-600/20 text-yellow-400'
                  }`}>
                    {g.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const DAY_NAMES = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
const DEFAULT_HOURS = [
  { day_of_week: 1, day_name: 'Lundi',    open: true,  start_time: '09:00', end_time: '18:00' },
  { day_of_week: 2, day_name: 'Mardi',    open: true,  start_time: '09:00', end_time: '18:00' },
  { day_of_week: 3, day_name: 'Mercredi', open: true,  start_time: '12:00', end_time: '18:00' },
  { day_of_week: 4, day_name: 'Jeudi',    open: true,  start_time: '09:00', end_time: '18:00' },
  { day_of_week: 5, day_name: 'Vendredi', open: true,  start_time: '09:00', end_time: '18:00' },
  { day_of_week: 6, day_name: 'Samedi',   open: true,  start_time: '09:00', end_time: '18:00' },
  { day_of_week: 0, day_name: 'Dimanche', open: false, start_time: '09:00', end_time: '18:00' },
];

function AdminOpeningHours() {
  const [hours, setHours] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(null);

  useEffect(() => { loadHours(); }, []);

  const loadHours = async () => {
    try {
      const data = await base44.entities.OpeningHours.list();
      if (data.length === 0) {
        // Initialiser les données par défaut
        const created = await Promise.all(DEFAULT_HOURS.map(d => base44.entities.OpeningHours.create(d)));
        setHours(created.sort((a, b) => (a.day_of_week === 0 ? 7 : a.day_of_week) - (b.day_of_week === 0 ? 7 : b.day_of_week)));
      } else {
        setHours(data.sort((a, b) => (a.day_of_week === 0 ? 7 : a.day_of_week) - (b.day_of_week === 0 ? 7 : b.day_of_week)));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async (id, field, value) => {
    setHours(prev => prev.map(h => h.id === id ? { ...h, [field]: value } : h));
    setSaving(id);
    try {
      await base44.entities.OpeningHours.update(id, { [field]: value });
    } finally {
      setSaving(null);
    }
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-cac-gold" /></div>;

  return (
    <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6">
      <h2 className="font-heading text-2xl text-cac-ivory mb-2">Horaires d'ouverture</h2>
      <p className="text-sm text-cac-gray mb-6">Les modifications sont sauvegardées automatiquement.</p>
      <div className="space-y-3">
        {hours.map(h => (
          <div key={h.id} className={`flex items-center gap-4 p-4 rounded-xl border transition-colors ${h.open ? 'border-cac-gold/20 bg-cac-black' : 'border-cac-gray-dark/30 bg-cac-black/50'}`}>
            <div className="w-28 flex-shrink-0">
              <p className={`text-sm font-medium ${h.open ? 'text-cac-ivory' : 'text-cac-gray'}`}>{h.day_name}</p>
            </div>
            <button
              onClick={() => handleUpdate(h.id, 'open', !h.open)}
              className={`flex-shrink-0 w-10 h-6 rounded-full transition-colors relative ${h.open ? 'bg-cac-gold' : 'bg-cac-gray-dark'}`}
            >
              <span className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${h.open ? 'translate-x-5' : 'translate-x-1'}`} />
            </button>
            {h.open ? (
              <div className="flex items-center gap-2 flex-1">
                <input type="time" value={h.start_time}
                  onChange={(e) => handleUpdate(h.id, 'start_time', e.target.value)}
                  className="bg-cac-black-light border border-cac-gray-dark text-cac-ivory rounded px-2 py-1 text-sm" />
                <span className="text-cac-gray text-xs">→</span>
                <input type="time" value={h.end_time}
                  onChange={(e) => handleUpdate(h.id, 'end_time', e.target.value)}
                  className="bg-cac-black-light border border-cac-gray-dark text-cac-ivory rounded px-2 py-1 text-sm" />
                {saving === h.id && <Loader2 size={14} className="animate-spin text-cac-gold" />}
                {saving !== h.id && <Check size={14} className="text-green-400" />}
              </div>
            ) : (
              <span className="text-xs text-cac-gray italic">Fermé</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminClients() {
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadClients();
  }, []);

  const loadClients = async () => {
    try {
      const data = await base44.entities.Client.list('-created_date', 100);
      setClients(data);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-cac-gold" /></div>;

  return (
    <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6">
      <h2 className="font-heading text-2xl text-cac-ivory mb-6">Base clients ({clients.length})</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-cac-gray-dark/50 text-cac-gray">
              <th className="text-left py-3 px-2">Nom</th>
              <th className="text-left py-3 px-2">Contact</th>
              <th className="text-left py-3 px-2">Total dépensé</th>
              <th className="text-left py-3 px-2">Réservations</th>
            </tr>
          </thead>
          <tbody>
            {clients.map(c => (
              <tr key={c.id} className="border-b border-cac-gray-dark/30 hover:bg-cac-black/30">
                <td className="py-3 px-2 text-cac-ivory">{c.full_name}</td>
                <td className="py-3 px-2 text-cac-gray text-xs">{c.email}<br/>{c.phone}</td>
                <td className="py-3 px-2 text-cac-gold font-medium">{c.total_spent || 0}€</td>
                <td className="py-3 px-2 text-cac-gray">{c.booking_history?.length || 0}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AdminContent() {
  const [tab, setTab] = useState('services');
  return (
    <div className="space-y-4">
      <div className="flex gap-3 mb-6">
        <button onClick={() => setTab('services')} className={`px-4 py-2 rounded-lg text-xs uppercase tracking-wider ${tab === 'services' ? 'bg-cac-gold text-cac-black' : 'bg-cac-black-light text-cac-gray'}`}>
          Services
        </button>
        <button onClick={() => setTab('products')} className={`px-4 py-2 rounded-lg text-xs uppercase tracking-wider ${tab === 'products' ? 'bg-cac-gold text-cac-black' : 'bg-cac-black-light text-cac-gray'}`}>
          Produits
        </button>
        <button onClick={() => setTab('blog')} className={`px-4 py-2 rounded-lg text-xs uppercase tracking-wider ${tab === 'blog' ? 'bg-cac-gold text-cac-black' : 'bg-cac-black-light text-cac-gray'}`}>
          Blog
        </button>
      </div>
      {tab === 'services' && <AdminServices />}
      {tab === 'products' && <AdminProducts />}
      {tab === 'blog' && <AdminBlog />}
    </div>
  );
}

function AdminServices() {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    try {
      const data = await base44.entities.Service.list();
      setServices(data);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-cac-gold" /></div>;

  return (
    <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6">
      <h3 className="font-heading text-xl text-cac-ivory mb-4">Services & Formations ({services.length})</h3>
      <div className="grid gap-3">
        {services.map(s => (
          <div key={s.id} className="bg-cac-black border border-cac-gray-dark/30 rounded-lg p-4 flex justify-between items-center">
            <div>
              <p className="text-cac-ivory font-medium">{s.name}</p>
              <p className="text-xs text-cac-gray">{s.duration_minutes} min - {s.price}€ - {s.type}</p>
            </div>
            <span className={`text-xs px-2 py-1 rounded ${s.active ? 'bg-green-600/20 text-green-400' : 'bg-gray-600/20 text-gray-400'}`}>
              {s.active ? 'Actif' : 'Inactif'}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminProducts() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const data = await base44.entities.Product.list();
      setProducts(data);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-cac-gold" /></div>;

  return (
    <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6">
      <h3 className="font-heading text-xl text-cac-ivory mb-4">Produits boutique ({products.length})</h3>
      <div className="grid gap-3">
        {products.map(p => (
          <div key={p.id} className="bg-cac-black border border-cac-gray-dark/30 rounded-lg p-4">
            <p className="text-cac-ivory font-medium">{p.name}</p>
            <p className="text-xs text-cac-gray mb-2">{p.category}</p>
            <p className="text-xs text-cac-gray">{p.short_description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminBlog() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = async () => {
    try {
      const data = await base44.entities.BlogPost.list('-published_date', 100);
      setPosts(data);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-cac-gold" /></div>;

  return (
    <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6">
      <h3 className="font-heading text-xl text-cac-ivory mb-4">Articles blog ({posts.length})</h3>
      <div className="grid gap-3">
        {posts.map(p => (
          <div key={p.id} className="bg-cac-black border border-cac-gray-dark/30 rounded-lg p-4 flex justify-between items-start">
            <div className="flex-1">
              <p className="text-cac-ivory font-medium mb-1">{p.title}</p>
              <p className="text-xs text-cac-gray">{p.category} - {p.reading_time} min</p>
            </div>
            <span className={`text-xs px-2 py-1 rounded ${p.active ? 'bg-green-600/20 text-green-400' : 'bg-gray-600/20 text-gray-400'}`}>
              {p.active ? 'Actif' : 'Inactif'}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminSettings() {
  const [settings, setSettings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newSetting, setNewSetting] = useState({ key: '', value: '', description: '' });

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const data = await base44.entities.Settings.list();
      setSettings(data);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      await base44.entities.Settings.create(newSetting);
      setNewSetting({ key: '', value: '', description: '' });
      loadSettings();
    } catch (error) {
      console.error('Erreur création:', error);
    }
  };

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="animate-spin text-cac-gold" /></div>;

  return (
    <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6">
      <h2 className="font-heading text-2xl text-cac-ivory mb-6">Paramètres du site</h2>
      
      <form onSubmit={handleCreate} className="bg-cac-black border border-cac-gray-dark/30 rounded-xl p-4 mb-6">
        <p className="text-sm text-cac-ivory mb-4">Ajouter un paramètre</p>
        <div className="grid grid-cols-3 gap-3">
          <input
            type="text"
            placeholder="Clé (ex: admin_email)"
            value={newSetting.key}
            onChange={(e) => setNewSetting({...newSetting, key: e.target.value})}
            className="px-3 py-2 bg-cac-black-light border border-cac-gray-dark text-cac-ivory rounded text-sm"
            required
          />
          <input
            type="text"
            placeholder="Valeur"
            value={newSetting.value}
            onChange={(e) => setNewSetting({...newSetting, value: e.target.value})}
            className="px-3 py-2 bg-cac-black-light border border-cac-gray-dark text-cac-ivory rounded text-sm"
            required
          />
          <input
            type="text"
            placeholder="Description"
            value={newSetting.description}
            onChange={(e) => setNewSetting({...newSetting, description: e.target.value})}
            className="px-3 py-2 bg-cac-black-light border border-cac-gray-dark text-cac-ivory rounded text-sm"
          />
        </div>
        <button type="submit" className="btn-gold px-4 py-2 rounded-lg text-xs uppercase tracking-wider mt-3">
          Ajouter
        </button>
      </form>

      <div className="space-y-3">
        {settings.map(s => (
          <div key={s.id} className="bg-cac-black border border-cac-gray-dark/30 rounded-lg p-4">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-cac-gold">{s.key}</p>
                <p className="text-cac-ivory mt-1">{s.value}</p>
                {s.description && <p className="text-xs text-cac-gray mt-1">{s.description}</p>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}