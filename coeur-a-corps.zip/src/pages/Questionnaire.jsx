import React, { useState } from "react";
import { motion } from "framer-motion";
import SectionHeading from "../components/shared/SectionHeading";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { CheckCircle2 } from "lucide-react";

export default function Questionnaire() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: "", email: "", phone: "",
    pregnant: "non", allergies: "", conditions: "",
    areas: "", expectations: ""
  });

  const handleChange = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="pt-28 pb-20 px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-lg mx-auto text-center"
        >
          <CheckCircle2 size={48} className="text-cac-gold mx-auto mb-6" />
          <h2 className="font-heading text-3xl text-cac-ivory mb-4">Merci !</h2>
          <p className="text-sm text-cac-gray">
            Votre questionnaire a bien été envoyé. Nous reviendrons vers vous rapidement.
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="pt-28 pb-20">
      <div className="px-6 max-w-2xl mx-auto">
        <SectionHeading
          subtitle="Avant votre séance"
          title="Questionnaire Santé"
          description="Ce questionnaire confidentiel nous permet de personnaliser votre soin et d'assurer votre sécurité."
        />
        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleSubmit}
          className="space-y-6 bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6 md:p-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-xs uppercase tracking-wider text-cac-gray">Nom complet</Label>
              <Input value={form.name} onChange={(e) => handleChange("name", e.target.value)} required
                className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold" />
            </div>
            <div className="space-y-2">
              <Label className="text-xs uppercase tracking-wider text-cac-gray">Email</Label>
              <Input type="email" value={form.email} onChange={(e) => handleChange("email", e.target.value)} required
                className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold" />
            </div>
          </div>
          <div className="space-y-2">
            <Label className="text-xs uppercase tracking-wider text-cac-gray">Téléphone</Label>
            <Input value={form.phone} onChange={(e) => handleChange("phone", e.target.value)}
              className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold" />
          </div>

          <div className="space-y-3">
            <Label className="text-xs uppercase tracking-wider text-cac-gray">Êtes-vous enceinte ?</Label>
            <RadioGroup value={form.pregnant} onValueChange={(v) => handleChange("pregnant", v)} className="flex gap-6">
              <div className="flex items-center gap-2">
                <RadioGroupItem value="oui" id="oui" className="border-cac-gold text-cac-gold" />
                <Label htmlFor="oui" className="text-sm text-cac-ivory">Oui</Label>
              </div>
              <div className="flex items-center gap-2">
                <RadioGroupItem value="non" id="non" className="border-cac-gold text-cac-gold" />
                <Label htmlFor="non" className="text-sm text-cac-ivory">Non</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label className="text-xs uppercase tracking-wider text-cac-gray">Allergies connues</Label>
            <Input value={form.allergies} onChange={(e) => handleChange("allergies", e.target.value)}
              placeholder="Huiles essentielles, noix, etc."
              className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold placeholder:text-cac-gray/50" />
          </div>

          <div className="space-y-2">
            <Label className="text-xs uppercase tracking-wider text-cac-gray">Conditions médicales</Label>
            <Textarea value={form.conditions} onChange={(e) => handleChange("conditions", e.target.value)}
              placeholder="Problèmes de dos, hypertension, etc."
              className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold placeholder:text-cac-gray/50 min-h-[80px]" />
          </div>

          <div className="space-y-2">
            <Label className="text-xs uppercase tracking-wider text-cac-gray">Zones à éviter ou à privilégier</Label>
            <Input value={form.areas} onChange={(e) => handleChange("areas", e.target.value)}
              className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold" />
          </div>

          <div className="space-y-2">
            <Label className="text-xs uppercase tracking-wider text-cac-gray">Vos attentes pour cette séance</Label>
            <Textarea value={form.expectations} onChange={(e) => handleChange("expectations", e.target.value)}
              className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold min-h-[80px]" />
          </div>

          <Button type="submit" className="w-full btn-gold rounded-full py-3 text-sm uppercase tracking-[0.15em]">
            Envoyer le questionnaire
          </Button>
        </motion.form>
      </div>
    </div>
  );
}