import React from "react";
import HeroSection from "../components/home/HeroSection";
import ConceptSection from "../components/home/ConceptSection";
import FavoriteMassages from "../components/home/FavoriteMassages";
import AutresPrestations from "../components/home/AutresPrestations";
import PratricienneSection from "../components/home/PratricienneSection";
import PillarSection from "../components/home/PillarSection";
import AmbianceMarquee from "../components/home/AmbianceMarquee";
import TestimonialsSection from "../components/home/TestimonialsSection";
import BlogPreview from "../components/home/BlogPreview";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { motion } from "framer-motion";
import { ShoppingBag, ArrowRight } from "lucide-react";

export default function Home() {
  return (
    <div>
      <HeroSection />
      <ConceptSection />
      <FavoriteMassages />
      <AutresPrestations />
      <AmbianceMarquee />
      <PillarSection />
      <PratricienneSection />
      <TestimonialsSection />
      <BlogPreview />
      
      {/* CTA Boutique */}
      <section className="py-20 md:py-28 px-6 bg-cac-black-light">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <ShoppingBag size={48} className="text-cac-gold mx-auto mb-6" />
            <h2 className="font-heading text-3xl md:text-4xl text-cac-ivory mb-4">Prolongez l'expérience chez vous</h2>
            <p className="text-sm text-cac-gray mb-8 max-w-2xl mx-auto">
              Découvrez notre sélection d'huiles, pierres et accessoires premium pour vos rituels bien-être quotidiens.
            </p>
            <Link
              to={createPageUrl("Boutique")}
              className="bg-cac-gold text-cac-black px-8 py-3.5 rounded-full text-sm uppercase tracking-[0.15em] font-medium inline-flex items-center gap-2 transition-all duration-300 hover:bg-cac-gold-light hover:shadow-lg hover:shadow-cac-gold/40 hover:-translate-y-0.5"
            >
              Découvrir la boutique
              <ArrowRight size={16} />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}