import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import SectionHeading from "../components/shared/SectionHeading";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Calendar, MessageSquare, Phone, ArrowRight, Clock, CheckCircle2, Loader2, Heart, GraduationCap } from "lucide-react";
import { base44 } from "@/api/base44Client";
import ServiceSelector from "../components/booking/ServiceSelector";
import DateTimePicker from "../components/booking/DateTimePicker";
import BookingForm from "../components/booking/BookingForm";
import BookingSuccess from "../components/booking/BookingSuccess";
import PaymentChoice from "../components/booking/PaymentChoice";
import PlanityQuestionnaire from "../components/booking/PlanityQuestionnaire";
import HealthQuestionnaire from "../components/booking/HealthQuestionnaire";

const steps = [
  { icon: MessageSquare, title: "Contactez-nous", text: "Par téléphone, WhatsApp ou via notre formulaire pour convenir d'un créneau." },
  { icon: Calendar, title: "Choisissez votre soin", text: "Sélectionnez le massage qui vous correspond ou laissez-vous guider par nos recommandations." },
  { icon: CheckCircle2, title: "Confirmation", text: "Vous recevrez un email de confirmation avec toutes les informations pratiques." },
];

const slugToServiceName = {
  'harmonie': 'Massage Harmonie',
  'palper-rouler': 'Palper-Rouler Manuel',
  'maderotherapie': 'Madérothérapie',
  'drainage-lymphatique': 'Drainage Lymphatique – Méthode Brésilienne',
  '5-continents': 'Modelage des 5 Continents',
  'expanse-therapy': 'Expanse Therapy',
  'future-maman': 'Massage Future Maman – Parenthèse Douceur',
  'enfant-douceur': 'Rituel Douceur Enfant'
};

const massageOrder = [
  'Massage Harmonie',
  'Modelage des 5 Continents',
  'Massage Future Maman – Parenthèse Douceur',
  'Drainage Lymphatique – Méthode Brésilienne',
  'Madérothérapie',
  'Palper-Rouler Manuel',
  'Rituel Douceur Enfant',
  'Expanse Therapy'
];

const sortMassages = (services) => {
  return [...services].sort((a, b) => {
    const indexA = massageOrder.indexOf(a.name);
    const indexB = massageOrder.indexOf(b.name);
    return indexA - indexB;
  });
};

export default function RDV() {
  const [bookingType, setBookingType] = useState(null); // 'massage' | 'formation'
  const [step, setStep] = useState(1); // 1=service, 2=paymentChoice, 3=datetime, 3.5=health, 4=form, 5=planity, 6=success
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedService, setSelectedService] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [paymentMode, setPaymentMode] = useState(null); // 'online' | 'onsite' | 'planity'
  const [healthData, setHealthData] = useState(null);
  const [completedBooking, setCompletedBooking] = useState(null);

  useEffect(() => {
    loadServices();
    // Gestion retour Stripe
    const urlParams = new URLSearchParams(window.location.search);
    const payment = urlParams.get('payment');
    const bookingId = urlParams.get('booking_id');
    if (payment === 'success' && bookingId) {
      setCompletedBooking({ id: bookingId, paidOnline: true });
      setStep(6);
    } else if (payment === 'cancelled') {
      // On reste sur la page, l'utilisateur peut recommencer
    }
  }, []);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const massageParam = urlParams.get('massage');
    if (massageParam && services.length > 0) {
      const serviceName = decodeURIComponent(massageParam);
      const recommended = services.find(s => s.name === serviceName);
      if (recommended) {
        setBookingType('massage');
        setSelectedService(recommended);
        setPaymentMode(null);
        setSelectedDate(null);
        setSelectedTime(null);
        setStep(2);
      }
    }
  }, [services]);

  const loadServices = async () => {
    try {
      const data = await base44.entities.Service.filter({ active: true });
      setServices(data);
    } catch (error) {
      console.error('Erreur chargement services:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSelect = (service) => {
    setSelectedService(service);
    setPaymentMode(null);
    setSelectedDate(null);
    setSelectedTime(null);
    setStep(2);
  };

  const handlePaymentChoice = (mode) => {
    setPaymentMode(mode);
    if (mode === 'planity') {
      setStep(5); // Planity flow : questionnaire puis redirection
    } else if (mode === 'phone') {
      setStep(7); // Phone flow : contactez-nous
    } else {
      setStep(3); // Online / onsite flow : choix créneau
    }
  };

  const handleDateSelect = (date) => {
    setSelectedDate(date);
    setSelectedTime(null);
  };

  const handleTimeSelect = (time) => {
    setSelectedTime(time);
    // Questionnaire santé uniquement pour paiement en ligne ou sur place
    if (paymentMode === 'online' || paymentMode === 'onsite') {
      setStep(3.5);
    } else {
      setStep(4);
    }
  };

  const handleHealthComplete = (data) => {
    setHealthData(data);
    setStep(4);
  };

  const handleBookingSuccess = (booking) => {
    setCompletedBooking(booking);
    setStep(6);
  };

  if (loading) {
    return (
      <div className="pt-28 pb-20 px-6 flex items-center justify-center min-h-screen">
        <Loader2 className="animate-spin text-cac-gold" size={32} />
      </div>
    );
  }

  if (step === 6 && completedBooking) {
    return (
      <div className="pt-28 pb-20 px-6">
        <BookingSuccess booking={completedBooking} />
      </div>
    );
  }

  const massageServices = sortMassages(services.filter(s => s.type === 'massage'));
  const formationServices = services.filter(s => s.type === 'formation');

  return (
    <div className="pt-28 pb-20">
      <div className="px-6 max-w-4xl mx-auto">
        <SectionHeading
          subtitle="Réservation en ligne"
          title="Prenez rendez-vous"
          description="Choisissez votre type de prestation pour commencer."
        />

        {/* Type filter */}
        <div className="flex items-center justify-center gap-4 mb-10">
          <button
            onClick={() => { setBookingType('massage'); setStep(1); setSelectedService(null); }}
            className={`flex items-center gap-3 px-8 py-4 rounded-2xl border transition-all ${
              bookingType === 'massage'
                ? 'border-cac-gold bg-cac-gold/10 text-cac-ivory'
                : 'border-cac-gray-dark/50 text-cac-gray hover:border-cac-gold/40'
            }`}
          >
            <Heart size={20} className={bookingType === 'massage' ? 'text-cac-gold' : ''} />
            <div className="text-left">
              <p className="text-xs uppercase tracking-[0.15em] font-medium">Massage</p>
              <p className="text-xs text-cac-gray mt-0.5">Réservation en ligne</p>
            </div>
          </button>
          <button
            onClick={() => setBookingType('formation')}
            className={`flex items-center gap-3 px-8 py-4 rounded-2xl border transition-all ${
              bookingType === 'formation'
                ? 'border-cac-gold bg-cac-gold/10 text-cac-ivory'
                : 'border-cac-gray-dark/50 text-cac-gray hover:border-cac-gold/40'
            }`}
          >
            <GraduationCap size={20} className={bookingType === 'formation' ? 'text-cac-gold' : ''} />
            <div className="text-left">
              <p className="text-xs uppercase tracking-[0.15em] font-medium">Formation</p>
              <p className="text-xs text-cac-gray mt-0.5">Inscription & renseignements</p>
            </div>
          </button>
        </div>

        {/* Formation CTA */}
        {bookingType === 'formation' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-cac-black-light border border-cac-gold/30 rounded-2xl p-8 text-center"
          >
            <GraduationCap size={40} className="text-cac-gold mx-auto mb-4" />
            <h3 className="font-heading text-2xl text-cac-ivory mb-3">Nos formations bien-être</h3>
            <p className="text-sm text-cac-gray mb-6 max-w-md mx-auto">
              Les inscriptions aux formations se font par contact direct. Découvrez nos programmes et contactez-nous pour vous inscrire.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to={createPageUrl("Formations")} className="btn-gold px-8 py-3 rounded-full text-xs uppercase tracking-[0.15em] inline-flex items-center gap-2">
                <GraduationCap size={14} />
                Voir les formations
              </Link>
              <a href="https://wa.me/33650543613" target="_blank" rel="noopener noreferrer"
                className="bg-green-600/10 border border-green-600/30 text-green-500 hover:bg-green-600/20 px-6 py-3 rounded-full text-xs uppercase tracking-[0.15em] inline-flex items-center gap-2 transition-colors">
                <MessageSquare size={14} />
                Nous contacter
              </a>
            </div>
          </motion.div>
        )}

        {/* Massage booking flow */}
        {bookingType === 'massage' && (
          <>
            {/* Progress indicator — steps 1,2,3,4 pour les flow online/onsite */}
            {step !== 5 && step !== 7 && (
             <div className="flex items-center justify-center gap-4 mb-8">
               {(paymentMode === 'online' || paymentMode === 'onsite' ? [1, 2, 3, 3.5, 4] : [1, 2, 3, 4]).map((s, i, arr) => (
                  <div key={s} className="flex items-center">
                    <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-medium transition-all ${
                      step >= s ? 'bg-cac-gold text-cac-black' : 'bg-cac-black-light border border-cac-gray-dark text-cac-gray'
                    }`}>
                      {i + 1}
                    </div>
                    {i < arr.length - 1 && <div className={`w-8 h-0.5 mx-1 ${step > s ? 'bg-cac-gold' : 'bg-cac-gray-dark'}`} />}
                  </div>
                ))}
              </div>
            )}

            {/* Step content */}
            <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6 md:p-8">
              {/* Étape 1 : Choix du massage */}
              {step === 1 && (
                <ServiceSelector
                  services={massageServices}
                  selectedService={selectedService}
                  onSelect={handleServiceSelect}
                />
              )}

              {/* Étape 2 : Choix du mode de réservation */}
              {step === 2 && selectedService && (
                <PaymentChoice
                  service={selectedService}
                  onChoice={handlePaymentChoice}
                  onBack={() => { setSelectedService(null); setStep(1); }}
                />
              )}

              {/* Étape 3 : Choix du créneau (flow online / onsite) */}
              {step === 3 && selectedService && (
                <div className="space-y-6">
                  <button onClick={() => setStep(2)} className="text-xs uppercase tracking-wider text-cac-gold hover:text-cac-gold-light transition-colors">
                    ← Modifier le mode de paiement
                  </button>
                  <div className="flex items-center gap-3 p-4 bg-cac-gold/5 border border-cac-gold/30 rounded-xl">
                    <div className="w-2 h-2 rounded-full bg-cac-gold flex-shrink-0" />
                    <div>
                      <p className="text-xs uppercase tracking-wider text-cac-gold mb-0.5">Soin sélectionné</p>
                      <p className="text-sm text-cac-ivory font-medium">{selectedService.name}</p>
                      <p className="text-xs text-cac-gray">{selectedService.duration_minutes} min — {paymentMode === 'online' ? `${Math.round(selectedService.price * 0.95)}€ (-5%)` : `${selectedService.price}€`}</p>
                    </div>
                  </div>
                  <DateTimePicker
                    service={selectedService}
                    selectedDate={selectedDate}
                    selectedTime={selectedTime}
                    onDateChange={handleDateSelect}
                    onTimeChange={handleTimeSelect}
                  />
                </div>
              )}

              {/* Étape 3.5 : Questionnaire santé */}
              {step === 3.5 && selectedService && selectedDate && selectedTime && (
                <HealthQuestionnaire
                  onBack={() => setStep(3)}
                  onComplete={handleHealthComplete}
                />
              )}

              {/* Étape 4 : Infos client + paiement/confirmation */}
              {step === 4 && selectedService && selectedDate && selectedTime && (
                <div className="space-y-6">
                  <button onClick={() => setStep(3.5)} className="text-xs uppercase tracking-wider text-cac-gold hover:text-cac-gold-light transition-colors">
                    ← Modifier le questionnaire santé
                  </button>
                  <BookingForm
                    service={selectedService}
                    date={selectedDate}
                    time={selectedTime}
                    paymentMode={paymentMode}
                    healthData={healthData}
                    onSuccess={handleBookingSuccess}
                  />
                </div>
              )}

              {/* Étape 5 : Flow Planity — questionnaire puis redirection */}
              {step === 5 && selectedService && (
                <PlanityQuestionnaire
                  service={selectedService}
                  onBack={() => { setPaymentMode(null); setStep(2); }}
                />
              )}

              {/* Étape 7 : Réservation par téléphone */}
              {step === 7 && selectedService && (
                <div className="space-y-6">
                  <button onClick={() => setStep(2)} className="text-xs uppercase tracking-wider text-cac-gold hover:text-cac-gold-light transition-colors">
                    ← Modifier le mode de paiement
                  </button>
                  <div className="flex items-center gap-3 p-4 bg-cac-gold/5 border border-cac-gold/30 rounded-xl">
                    <div className="w-2 h-2 rounded-full bg-cac-gold flex-shrink-0" />
                    <div>
                      <p className="text-xs uppercase tracking-wider text-cac-gold mb-0.5">Soin sélectionné</p>
                      <p className="text-sm text-cac-ivory font-medium">{selectedService.name}</p>
                      <p className="text-xs text-cac-gray">{selectedService.duration_minutes} min — {selectedService.price}€</p>
                    </div>
                  </div>
                  <div className="text-center py-8 space-y-6">
                    <div>
                      <p className="text-sm text-cac-gray mb-6">Contactez-nous pour convenir d'un créneau</p>
                      <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                        <a href="tel:+33650543613" className="btn-gold px-8 py-3.5 rounded-full text-xs uppercase tracking-[0.15em] inline-flex items-center gap-2">
                          <Phone size={16} />
                          06 50 54 36 13
                        </a>
                        <a href="https://wa.me/33650543613" target="_blank" rel="noopener noreferrer"
                          className="bg-green-600/10 border border-green-600/30 text-green-500 hover:bg-green-600/20 px-8 py-3.5 rounded-full text-xs uppercase tracking-[0.15em] inline-flex items-center gap-2 transition-colors">
                          <MessageSquare size={16} />
                          WhatsApp
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              </div>
              </>
              )}



      </div>
    </div>
  );
}