import React from "react";
import { motion } from "framer-motion";
import SectionHeading from "../components/shared/SectionHeading";
import MassageCard from "../components/shared/MassageCard";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { ArrowRight } from "lucide-react";

const allMassages = [
  {
    title: "Massage Harmonie",
    description: "Un soin signature enveloppant, fluide et profond, conçu pour rétablir l'équilibre du corps et apaiser le mental.",
    durations: ["60 min", "90 min"],
    prices: ["70€", "100€"],
    badge: "Signature",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/2f518af7e_massage_harmonie_27.jpg",
    slug: "harmonie"
  },
  {
    title: "Palper-Rouler Manuel",
    description: "Un soin remodelant manuel ciblé, pour lisser, tonifier et redessiner en profondeur.",
    durations: ["60 min"],
    prices: ["80€"],
    cure: "6 séances : 420€",
    image: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=600&q=80",
    slug: "palper-rouler"
  },
  {
    title: "Madérothérapie",
    description: "Une technique sculptante utilisant des instruments en bois pour relancer la circulation et redessiner les contours du corps.",
    durations: ["60 min"],
    prices: ["80€"],
    cure: "6 séances : 350€",
    image: "https://media.base44.com/images/public/698b92bf0ecaed3d486114dc/603443d37_formation_madero_15.jpg",
    slug: "maderotherapie"
  },
  {
    title: "Drainage Lymphatique – Méthode Brésilienne",
    description: "Un soin expert favorisant l'élimination des toxines et apportant une sensation immédiate de légèreté.",
    durations: ["60 min"],
    prices: ["90€"],
    cure: "6 séances : 480€",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/40244d92c_massage_drainage_24.jpg",
    slug: "drainage-lymphatique"
  },
  {
    title: "Modelage des 5 Continents",
    description: "Un voyage énergétique inspiré des meilleures traditions de massage du monde.",
    durations: ["60 min", "90 min"],
    prices: ["95€", "130€"],
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/316e2a325_massage_lomi_26.jpg",
    slug: "5-continents"
  },
  {
    title: "Expanse Therapy",
    description: "Une thérapie corporelle énergétique alliant précision technique et travail subtil.",
    durations: ["60 min"],
    prices: ["90€"],
    cure: "4 séances : 320€",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/380cc2ac3_generated_image.png",
    slug: "expanse-therapy"
  },
  {
    title: "Massage Future Maman – Parenthèse Douceur",
    description: "Un soin enveloppant spécialement conçu pour la grossesse, pour relâcher les tensions et créer un lien apaisant avec votre bébé.",
    durations: ["60 min"],
    prices: ["70€"],
    badge: "À partir du 2ᵉ trimestre",
    image: "https://media.base44.com/images/public/698b92bf0ecaed3d486114dc/d4366a756_generated_image.png",
    slug: "future-maman"
  },
  {
    title: "Rituel Douceur Enfant",
    description: "Un massage tout en douceur spécialement conçu pour les enfants, favorisant le calme et le sentiment de sécurité.",
    durations: ["45 min"],
    prices: ["60€"],
    badge: "Avec parent",
    image: "https://media.base44.com/images/public/698b92bf0ecaed3d486114dc/f8c5cae8b_generated_image.png",
    slug: "enfant-douceur"
  }
];

export default function Massages() {
  return (
    <div className="pt-28 pb-20">
      <div className="px-6 max-w-6xl mx-auto">
        <SectionHeading
          subtitle="Nos soins"
          title="Massages & Modelages"
          description="Chaque massage est une invitation au voyage intérieur. Découvrez notre carte de soins, conçue pour répondre à vos besoins les plus profonds."
        />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {allMassages.map((massage, i) => (
            <MassageCard key={massage.title} {...massage} index={i} />
          ))}
        </div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <Link
            to={createPageUrl("RDV")}
            className="btn-gold px-8 py-3.5 rounded-full text-sm uppercase tracking-[0.15em] inline-flex items-center gap-2"
          >
            Réserver un soin
            <ArrowRight size={16} />
          </Link>
        </motion.div>
      </div>
    </div>
  );
}