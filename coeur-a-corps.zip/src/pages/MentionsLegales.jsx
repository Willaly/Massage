import React from "react";
import { motion } from "framer-motion";
import SectionHeading from "../components/shared/SectionHeading";

const sections = [
  {
    title: "1. Éditeur du site",
    content: `Le présent site est édité par :

**Cœur à Corps**
Salon Mastroianni
342 Prom. Général Charles de Gaulle
83140 Six-Fours-les-Plages
France

Téléphone : 06 50 54 36 13
Email : contact@coeuracorps.fr

Forme juridique : Entreprise individuelle
Numéro SIRET : [À compléter]
Code APE/NAF : [À compléter]`
  },
  {
    title: "2. Hébergement",
    content: `Le site est hébergé par :

**Base44 / Supabase**
Hébergement cloud sécurisé
Services conformes au RGPD`
  },
  {
    title: "3. Propriété intellectuelle",
    content: `L'ensemble du contenu de ce site (textes, images, photographies, vidéos, logos, graphismes) est la propriété exclusive de Cœur à Corps, sauf mention contraire.

Toute reproduction, distribution, modification ou utilisation de ces contenus, sous quelque forme que ce soit, sans l'autorisation expresse et préalable de Cœur à Corps, est strictement interdite et constituerait une contrefaçon sanctionnée par les articles L.335-2 et suivants du Code de la Propriété Intellectuelle.`
  },
  {
    title: "4. Données personnelles",
    content: `Conformément au Règlement Général sur la Protection des Données (RGPD – Règlement UE 2016/679) et à la loi n° 78-17 du 6 janvier 1978 relative à l'informatique, aux fichiers et aux libertés (loi Informatique et Libertés), vous disposez des droits suivants :

• **Droit d'accès** : vous pouvez demander à consulter les données personnelles vous concernant.
• **Droit de rectification** : vous pouvez demander la correction de données inexactes.
• **Droit à l'effacement** : vous pouvez demander la suppression de vos données.
• **Droit d'opposition** : vous pouvez vous opposer au traitement de vos données.
• **Droit à la portabilité** : vous pouvez demander à recevoir vos données dans un format structuré.

**Finalités du traitement des données :**
Les données collectées via les formulaires (réservation, questionnaire santé, contact) sont utilisées uniquement dans le cadre de la relation commerciale et thérapeutique entre le client et Cœur à Corps. Elles ne sont ni vendues, ni cédées à des tiers.

**Durée de conservation :**
Les données sont conservées pendant une durée de 3 ans à compter du dernier contact.

Pour exercer vos droits ou pour toute question relative à la protection de vos données personnelles, vous pouvez contacter : contact@coeuracorps.fr

En cas de litige, vous avez le droit de saisir la Commission Nationale de l'Informatique et des Libertés (CNIL) : www.cnil.fr`
  },
  {
    title: "5. Cookies",
    content: `Ce site utilise des cookies techniques strictement nécessaires à son bon fonctionnement (session utilisateur, panier d'achat). Aucun cookie de traçage publicitaire n'est utilisé.

Conformément à l'article 82 de la loi Informatique et Libertés et aux recommandations de la CNIL, les cookies purement fonctionnels ne nécessitent pas de consentement préalable.`
  },
  {
    title: "6. Responsabilité",
    content: `Cœur à Corps s'efforce d'assurer l'exactitude et la mise à jour des informations diffusées sur ce site. Toutefois, Cœur à Corps ne peut garantir l'exactitude, la précision ou l'exhaustivité des informations disponibles.

Cœur à Corps décline toute responsabilité pour tout dommage direct ou indirect pouvant résulter de l'accès au site ou de l'utilisation des informations qu'il contient.

Les informations présentes sur ce site ont un caractère général et ne constituent pas un avis médical. En cas de doute sur votre état de santé, consultez un professionnel de santé.`
  },
  {
    title: "7. Droit applicable et juridiction",
    content: `Les présentes mentions légales sont régies par le droit français. En cas de litige, et après tentative de résolution amiable, les tribunaux français seront seuls compétents.

Conformément à l'ordonnance n° 2015-1033 du 20 août 2015, tout litige de consommation peut être soumis à un médiateur. Vous pouvez contacter le médiateur de la consommation compétent sur la plateforme européenne de règlement en ligne des litiges : https://ec.europa.eu/consumers/odr`
  },
  {
    title: "8. Conditions générales de vente",
    content: `**Réservations :**
Les réservations effectuées en ligne sont confirmées par email. En cas d'annulation, merci de prévenir au moins 24h à l'avance. Toute séance non annulée dans ce délai pourra être facturée.

**Cartes cadeaux :**
Les cartes cadeaux sont valables 1 an à compter de la date d'achat. Elles ne sont ni remboursables ni échangeables contre de l'argent. Elles sont valables uniquement pour les prestations de Cœur à Corps.

**Boutique :**
Les commandes de produits sont à retirer directement au salon ou expédiées selon les modalités convenues. Les prix sont indiqués toutes taxes comprises (TTC).`
  }
];

export default function MentionsLegales() {
  return (
    <div className="pt-28 pb-20">
      <div className="px-6 max-w-3xl mx-auto">
        <SectionHeading
          subtitle="Informations légales"
          title="Mentions Légales"
          description="Conformément aux dispositions de la loi n° 2004-575 du 21 juin 2004 pour la confiance en l'économie numérique."
        />
        <div className="space-y-8">
          {sections.map((section, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.05 }}
              className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6 md:p-8"
            >
              <h3 className="font-heading text-xl text-cac-gold mb-4">{section.title}</h3>
              <div className="text-sm text-cac-gray leading-relaxed whitespace-pre-line">
                {section.content.split(/\*\*(.*?)\*\*/g).map((part, j) =>
                  j % 2 === 1 ? (
                    <strong key={j} className="text-cac-ivory font-semibold">{part}</strong>
                  ) : (
                    <span key={j}>{part}</span>
                  )
                )}
              </div>
            </motion.div>
          ))}
        </div>
        <p className="text-xs text-cac-gray text-center mt-12">
          Dernière mise à jour : {new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}
        </p>
      </div>
    </div>
  );
}