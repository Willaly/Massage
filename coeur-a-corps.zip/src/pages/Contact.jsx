import React, { useState } from "react";
import { motion } from "framer-motion";
import SectionHeading from "../components/shared/SectionHeading";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { MapPin, Phone, Mail, MessageSquare, CheckCircle2, Navigation } from "lucide-react";

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });

  const handleChange = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  if (submitted) {
    return (
      <div className="pt-28 pb-20 px-6">
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="max-w-lg mx-auto text-center">
          <CheckCircle2 size={48} className="text-cac-gold mx-auto mb-6" />
          <h2 className="font-heading text-3xl text-cac-ivory mb-4">Message envoyé !</h2>
          <p className="text-sm text-cac-gray">Nous vous répondrons dans les plus brefs délais.</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="pt-28 pb-20">
      <div className="px-6 max-w-5xl mx-auto">
        <SectionHeading
          subtitle="Nous contacter"
          title="Prenons contact"
          description="Une question, une envie, un besoin ? N'hésitez pas à nous écrire."
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            {/* Adresse avec liens navigation */}
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-cac-gold/10 flex items-center justify-center flex-shrink-0 mt-1">
                <MapPin size={18} className="text-cac-gold" />
              </div>
              <div className="flex-1">
                <h4 className="font-heading text-lg text-cac-ivory mb-1">Adresse</h4>
                <a
                  href="https://www.google.com/maps/search/?api=1&query=342+Promenade+General+Charles+de+Gaulle+Six-Fours-les-Plages"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-cac-gray hover:text-cac-gold transition-colors underline underline-offset-4 decoration-cac-gold/30"
                >
                  Salon Mastroianni<br />
                  342 Prom. Général Charles de Gaulle<br />
                  83140 Six-Fours-les-Plages
                </a>
                {/* Boutons de navigation */}
                <div className="flex flex-wrap gap-2 mt-3">
                  <a
                    href="https://www.google.com/maps/dir/?api=1&destination=342+Promenade+General+Charles+de+Gaulle+Six-Fours-les-Plages"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-cac-black border border-cac-gray-dark hover:border-cac-gold/50 text-xs text-cac-gray hover:text-cac-gold transition-all"
                  >
                    <Navigation size={12} />
                    Google Maps
                  </a>
                  <a
                    href="https://maps.apple.com/?daddr=342+Promenade+General+Charles+de+Gaulle,+Six-Fours-les-Plages,+France"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-cac-black border border-cac-gray-dark hover:border-cac-gold/50 text-xs text-cac-gray hover:text-cac-gold transition-all"
                  >
                    <Navigation size={12} />
                    Plans (Apple)
                  </a>
                  <a
                    href="https://waze.com/ul?q=342+Promenade+General+Charles+de+Gaulle+Six-Fours-les-Plages&navigate=yes"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-cac-black border border-cac-gray-dark hover:border-cac-gold/50 text-xs text-cac-gray hover:text-cac-gold transition-all"
                  >
                    <Navigation size={12} />
                    Waze
                  </a>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-cac-gold/10 flex items-center justify-center flex-shrink-0 mt-1">
                <Phone size={18} className="text-cac-gold" />
              </div>
              <div>
                <h4 className="font-heading text-lg text-cac-ivory mb-1">Téléphone</h4>
                <a href="tel:+33650543613" className="text-sm text-cac-gray hover:text-cac-gold transition-colors">06 50 54 36 13</a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-cac-gold/10 flex items-center justify-center flex-shrink-0 mt-1">
                <Mail size={18} className="text-cac-gold" />
              </div>
              <div>
                <h4 className="font-heading text-lg text-cac-ivory mb-1">Email</h4>
                <a href="mailto:marineproservices83@gmail.com" className="text-sm text-cac-gray hover:text-cac-gold transition-colors">marineproservices83@gmail.com</a>
              </div>
            </div>

            <a
              href="https://wa.me/33650543613"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 bg-green-600/10 border border-green-600/30 rounded-xl p-4 hover:bg-green-600/20 transition-colors"
            >
              <MessageSquare size={20} className="text-green-500" />
              <div>
                <p className="text-sm font-medium text-cac-ivory">WhatsApp</p>
                <p className="text-xs text-cac-gray">Réponse rapide par message</p>
              </div>
            </a>

            {/* Carte Google Maps intégrée */}
            <div className="rounded-2xl overflow-hidden border border-cac-gray-dark/50 h-52">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2893.5!2d5.8386!3d43.0917!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12c9b0e1e1e1e1e1%3A0x1!2s342+Promenade+G%C3%A9n%C3%A9ral+Charles+de+Gaulle%2C+83140+Six-Fours-les-Plages!5e0!3m2!1sfr!2sfr!4v1"
                width="100%"
                height="100%"
                style={{ border: 0, filter: "invert(90%) hue-rotate(180deg)" }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Localisation Cœur à Corps"
              />
            </div>
          </motion.div>

          <motion.form
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }}
            className="space-y-5 bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6 md:p-8"
          >
            <div className="space-y-2">
              <Label className="text-xs uppercase tracking-wider text-cac-gray">Nom</Label>
              <Input value={form.name} onChange={(e) => handleChange("name", e.target.value)} required
                className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold" />
            </div>
            <div className="space-y-2">
              <Label className="text-xs uppercase tracking-wider text-cac-gray">Email</Label>
              <Input type="email" value={form.email} onChange={(e) => handleChange("email", e.target.value)} required
                className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold" />
            </div>
            <div className="space-y-2">
              <Label className="text-xs uppercase tracking-wider text-cac-gray">Sujet</Label>
              <Input value={form.subject} onChange={(e) => handleChange("subject", e.target.value)}
                className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold" />
            </div>
            <div className="space-y-2">
              <Label className="text-xs uppercase tracking-wider text-cac-gray">Message</Label>
              <Textarea value={form.message} onChange={(e) => handleChange("message", e.target.value)} required
                className="bg-transparent border-cac-gray-dark text-cac-ivory focus:border-cac-gold min-h-[120px]" />
            </div>
            <Button type="submit" className="w-full btn-gold rounded-full py-3 text-sm uppercase tracking-[0.15em]">
              Envoyer
            </Button>
          </motion.form>
        </div>
      </div>
    </div>
  );
}