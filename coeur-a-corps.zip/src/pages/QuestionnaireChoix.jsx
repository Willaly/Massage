import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { base44 } from "@/api/base44Client";

const questions = [
  {
    q: "Comment vous sentez-vous actuellement ?",
    options: [
      { text: "Stressé(e) et tendu(e)", score: { harmonie: 3, deep: 1, stones: 2, prenatal: 1 } },
      { text: "Fatigué(e) physiquement", score: { harmonie: 2, deep: 3, stones: 3, prenatal: 2 } },
      { text: "Dispersé(e) mentalement", score: { harmonie: 3, deep: 1, stones: 2, prenatal: 1 } },
      { text: "Plein(e) d'énergie", score: { harmonie: 1, deep: 2, stones: 1, prenatal: 1 } }
    ]
  },
  {
    q: "Quel type de pression préférez-vous ?",
    options: [
      { text: "Douce et enveloppante", score: { harmonie: 3, deep: 0, stones: 2, prenatal: 3 } },
      { text: "Ferme et profonde", score: { harmonie: 1, deep: 3, stones: 1, prenatal: 0 } },
      { text: "Variable selon les zones", score: { harmonie: 2, deep: 2, stones: 2, prenatal: 1 } },
      { text: "Moyenne", score: { harmonie: 2, deep: 1, stones: 3, prenatal: 2 } }
    ]
  },
  {
    q: "Où se situent principalement vos tensions ?",
    options: [
      { text: "Dos et épaules", score: { harmonie: 2, deep: 3, stones: 2, prenatal: 2 } },
      { text: "Nuque et tête", score: { harmonie: 3, deep: 1, stones: 2, prenatal: 1 } },
      { text: "Jambes et pieds", score: { harmonie: 1, deep: 2, stones: 1, prenatal: 3 } },
      { text: "Partout", score: { harmonie: 2, deep: 2, stones: 3, prenatal: 1 } }
    ]
  },
  {
    q: "Combien de temps souhaitez-vous pour votre massage ?",
    options: [
      { text: "60 minutes", score: { harmonie: 2, deep: 2, stones: 1, prenatal: 3 } },
      { text: "75-90 minutes", score: { harmonie: 3, deep: 2, stones: 3, prenatal: 1 } },
      { text: "Je ne sais pas", score: { harmonie: 2, deep: 1, stones: 2, prenatal: 2 } }
    ]
  },
  {
    q: "Recherchez-vous plutôt...",
    options: [
      { text: "Détente et lâcher-prise", score: { harmonie: 3, deep: 0, stones: 3, prenatal: 2 } },
      { text: "Soulagement de douleurs", score: { harmonie: 1, deep: 3, stones: 2, prenatal: 2 } },
      { text: "Reconnexion émotionnelle", score: { harmonie: 3, deep: 1, stones: 2, prenatal: 1 } },
      { text: "Bien-être global", score: { harmonie: 2, deep: 1, stones: 2, prenatal: 2 } }
    ]
  },
  {
    q: "Êtes-vous sensible à la chaleur ?",
    options: [
      { text: "Oui, j'adore la chaleur", score: { harmonie: 1, deep: 0, stones: 3, prenatal: 1 } },
      { text: "Je suis neutre", score: { harmonie: 2, deep: 2, stones: 1, prenatal: 2 } },
      { text: "Je préfère la fraîcheur", score: { harmonie: 2, deep: 2, stones: 0, prenatal: 2 } }
    ]
  },
  {
    q: "À quel moment de la journée préférez-vous vous relaxer ?",
    options: [
      { text: "Le matin", score: { harmonie: 1, deep: 2, stones: 1, prenatal: 1 } },
      { text: "L'après-midi", score: { harmonie: 2, deep: 2, stones: 2, prenatal: 2 } },
      { text: "Le soir", score: { harmonie: 3, deep: 1, stones: 3, prenatal: 2 } }
    ]
  },
  {
    q: "Comment décririez-vous votre rythme de vie ?",
    options: [
      { text: "Très actif et intense", score: { harmonie: 2, deep: 3, stones: 2, prenatal: 1 } },
      { text: "Équilibré", score: { harmonie: 2, deep: 1, stones: 2, prenatal: 2 } },
      { text: "Calme et posé", score: { harmonie: 2, deep: 1, stones: 2, prenatal: 2 } }
    ]
  },
  {
    q: "Qu'est-ce qui vous attire le plus ?",
    options: [
      { text: "Une expérience sensorielle", score: { harmonie: 3, deep: 1, stones: 3, prenatal: 1 } },
      { text: "Des résultats concrets", score: { harmonie: 1, deep: 3, stones: 2, prenatal: 2 } },
      { text: "Un moment de reconnexion", score: { harmonie: 3, deep: 1, stones: 2, prenatal: 2 } }
    ]
  },
  {
    q: "Êtes-vous actuellement enceinte ?",
    options: [
      { text: "Oui", score: { harmonie: 0, deep: 0, stones: 0, prenatal: 10 } },
      { text: "Non", score: { harmonie: 1, deep: 1, stones: 1, prenatal: 0 } }
    ]
  }
];

// Durée en minutes pour pouvoir filtrer selon la réponse à la question durée
const massages = {
  harmonie: {
    name: "Massage Harmonie",
    description: "Un soin signature enveloppant mêlant lenteur, profondeur et fluidité. Relâche les tensions musculaires, libère les blocages émotionnels.",
    duration: "90 min",
    durationMinutes: 90,
    price: "110€",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/16111fd53_massage_harmonie_27.jpg"
  },
  deep: {
    name: "Massage Deep Tissue",
    description: "Idéal pour libérer les tensions profondes et rééquilibrer la posture. Cible les couches musculaires profondes avec un toucher ferme mais respectueux.",
    duration: "60 min",
    durationMinutes: 60,
    price: "90€",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/b842346a9_massage_drainage_24.jpg"
  },
  stones: {
    name: "Massage aux Pierres Chaudes",
    description: "La chaleur des pierres volcaniques pour une détente totale. Relâchement absolu et sensation de chaleur réconfortante.",
    duration: "75 min",
    durationMinutes: 75,
    price: "120€",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/b8f2d18eb_stones_53.jpg"
  },
  prenatal: {
    name: "Massage Femme Enceinte",
    description: "Un soin cocooning pensé pour accompagner la maternité. Soulage les tensions du dos, des jambes, favorise la circulation.",
    duration: "60 min",
    durationMinutes: 60,
    price: "85€",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/59638731e_tarifs_gifts_28.jpg"
  }
};

// Index de la question durée dans le tableau questions (index 3)
const DURATION_QUESTION_INDEX = 3;
// Mapping réponse durée → filtre
const DURATION_FILTER = {
  "60 minutes": (m) => m.durationMinutes === 60,
  "75-90 minutes": (m) => m.durationMinutes >= 75,
  "Je ne sais pas": () => true
};

export default function QuestionnaireChoix() {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [result, setResult] = useState(null);

  const handleAnswer = async (option) => {
    const newAnswers = [...answers, option];
    setAnswers(newAnswers);

    if (currentStep === questions.length - 1) {
      const scores = { harmonie: 0, deep: 0, stones: 0, prenatal: 0 };
      newAnswers.forEach(ans => {
        Object.entries(ans.score).forEach(([key, value]) => {
          scores[key] += value;
        });
      });

      // Appliquer le filtre de durée si la question a été répondue
      const durationAnswer = newAnswers[DURATION_QUESTION_INDEX]?.text;
      const durationFilter = DURATION_FILTER[durationAnswer] || (() => true);

      // Trier par score et prendre le premier qui passe le filtre de durée
      const sorted = Object.entries(scores).sort(([,a], [,b]) => b - a);
      const recommendedKey = sorted.find(([key]) => durationFilter(massages[key]))?.[0] || sorted[0][0];
      setResult(massages[recommendedKey]);

      // Sauvegarder les réponses
      await base44.entities.QuestionnaireResponse.create({
        type: "massage_choice",
        responses: { questions: newAnswers.map((a, i) => ({ question: questions[i].q, answer: a.text })) },
        recommended_massage: massages[recommendedKey].name
      });
    } else {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
      setAnswers(answers.slice(0, -1));
    }
  };

  if (result) {
    return (
      <div className="pt-28 pb-20 px-6">
        <div className="max-w-2xl mx-auto">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center mb-8"
          >
            <h2 className="font-heading text-3xl md:text-4xl text-cac-ivory mb-4">Votre massage idéal</h2>
            <div className="gold-divider mx-auto" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-cac-black-light border border-cac-gold/30 rounded-2xl overflow-hidden"
          >
            <div className="aspect-[16/9] overflow-hidden">
              <img src={result.image} alt={result.name} className="w-full h-full object-cover" />
            </div>
            <div className="p-8 text-center">
              <h3 className="font-heading text-2xl text-cac-gold mb-3">{result.name}</h3>
              <p className="text-sm text-cac-gray mb-6 leading-relaxed">{result.description}</p>
              <div className="flex items-center justify-center gap-4 mb-8 text-sm text-cac-ivory">
                <span>⏱️ {result.duration}</span>
                <span className="text-cac-gray-dark">•</span>
                <span className="text-cac-gold font-medium">{result.price}</span>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to={`${createPageUrl("RDV")}?massage=${encodeURIComponent(result.name)}`} className="btn-gold px-8 py-3 rounded-full text-xs uppercase tracking-[0.15em] inline-flex items-center justify-center gap-2">
                  Réserver ce massage
                  <ArrowRight size={14} />
                </Link>
                <Link to={createPageUrl("Massages")} className="btn-outline-gold px-8 py-3 rounded-full text-xs uppercase tracking-[0.15em]">
                  Voir tous les massages
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  const question = questions[currentStep];
  const progress = ((currentStep + 1) / questions.length) * 100;

  return (
    <div className="pt-28 pb-20 px-6 min-h-screen">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-12">
          <p className="text-xs uppercase tracking-[0.25em] text-cac-gold mb-4">Questionnaire</p>
          <h1 className="font-heading text-3xl md:text-4xl text-cac-ivory mb-4">Quel massage vous correspond ?</h1>
          <p className="text-sm text-cac-gray">Répondez à 10 questions pour découvrir le soin idéal</p>
        </div>

        {/* Progress */}
        <div className="mb-12">
          <div className="flex justify-between mb-2 text-xs text-cac-gray">
            <span>Question {currentStep + 1}/10</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="h-1 bg-cac-gray-dark/30 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              className="h-full bg-cac-gold"
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
          >
            <h2 className="font-heading text-2xl text-cac-ivory mb-8 text-center">{question.q}</h2>
            <div className="space-y-4">
              {question.options.map((option, i) => (
                <motion.button
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  onClick={() => handleAnswer(option)}
                  className="w-full p-5 bg-cac-black-light border border-cac-gray-dark/50 rounded-xl text-left hover:border-cac-gold/50 hover:bg-cac-gold/5 transition-all group"
                >
                  <span className="text-sm text-cac-ivory group-hover:text-cac-gold transition-colors">{option.text}</span>
                </motion.button>
              ))}
            </div>

            {currentStep > 0 && (
              <button
                onClick={handleBack}
                className="mt-8 text-xs uppercase tracking-wider text-cac-gold hover:text-cac-gold-light transition-colors flex items-center gap-2 mx-auto"
              >
                <ArrowLeft size={14} />
                Question précédente
              </button>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}