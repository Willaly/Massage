import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { ArrowLeft, Clock, Euro, CheckCircle2, ArrowRight } from "lucide-react";
import SectionHeading from "../components/shared/SectionHeading";

const massagesDetails = {
  "harmonie": {
    title: "Massage Harmonie",
    shortDescription: "Un soin signature enveloppant, fluide et profond, conçu pour rétablir l'équilibre du corps et apaiser le mental.",
    longDescription: `Inspiré des traditions californiennes et balinaises, le Massage Harmonie est une invitation à ralentir. Chaque geste est pensé pour créer un lâcher-prise progressif, une respiration plus ample, une détente qui s'installe durablement.

Pressions glissées, bercements subtils et travail intuitif se mêlent pour offrir une expérience sensorielle complète.

En 90 minutes, le voyage devient plus profond, plus immersif, presque méditatif.`,
    idealFor: "Le stress, la charge mentale, les tensions globales, le besoin de recentrage.",
    result: "Un lâcher-prise immédiat et une harmonie durable entre corps et esprit.",
    durations: [
      { duration: "60 min", price: "70€" },
      { duration: "90 min", price: "100€" }
    ],
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/2f518af7e_massage_harmonie_27.jpg",
    badge: "Signature"
  },
  "palper-rouler": {
    title: "Palper-Rouler Manuel",
    shortDescription: "Un soin remodelant manuel ciblé, pour lisser, tonifier et redessiner en profondeur.",
    longDescription: `Entièrement réalisé à la main, ce massage dynamique stimule la circulation, active les tissus et aide à affiner les zones ciblées.

Il s'adresse à celles et ceux qui recherchent un travail précis, structurant et efficace.

En cure, il permet un accompagnement progressif, avec des résultats visibles et durables.`,
    idealFor: "Raffermissement, remodelage ciblé, amélioration de la texture de la peau.",
    result: "Une silhouette affinée, une peau lissée et une sensation de tonicité retrouvée.",
    durations: [
      { duration: "60 min", price: "80€" }
    ],
    cure: "6 séances : 420€",
    image: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=800&q=80"
  },
  "maderotherapie": {
    title: "Madérothérapie",
    shortDescription: "Une technique sculptante utilisant des instruments en bois pour relancer la circulation et redessiner les contours du corps.",
    longDescription: `La Madérothérapie associe précision et profondeur grâce à l'utilisation d'outils en bois spécialement conçus pour stimuler les tissus.

Elle favorise le drainage, améliore la texture de la peau et aide à sculpter la silhouette.

En cure, l'approche est progressive et structurée pour accompagner une transformation durable.`,
    idealFor: "Remodelage corporel, cellulite, rétention d'eau, amélioration de la circulation.",
    result: "Des contours redessinés, une peau raffermie et une silhouette sculptée.",
    durations: [
      { duration: "60 min", price: "80€" }
    ],
    cure: "6 séances : 350€",
    image: "https://media.base44.com/images/public/698b92bf0ecaed3d486114dc/603443d37_formation_madero_15.jpg"
  },
  "drainage-lymphatique": {
    title: "Drainage Lymphatique – Méthode Brésilienne",
    shortDescription: "Un soin expert favorisant l'élimination des toxines et apportant une sensation immédiate de légèreté.",
    longDescription: `Inspiré de la méthode brésilienne, ce drainage dynamique stimule la circulation lymphatique et réduit les sensations de rétention.

Il apporte une légèreté immédiate et une sensation de corps affiné.

En cure, il optimise les effets sur la silhouette et le confort corporel, dans une approche experte et maîtrisée.`,
    idealFor: "Rétention d'eau, jambes lourdes, détoxification, sensation de gonflement.",
    result: "Une légèreté retrouvée, une silhouette affinée et une circulation relancée.",
    durations: [
      { duration: "60 min", price: "90€" }
    ],
    cure: "6 séances : 480€",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/40244d92c_massage_drainage_24.jpg"
  },
  "5-continents": {
    title: "Modelage des 5 Continents",
    shortDescription: "Un voyage énergétique inspiré des meilleures traditions de massage du monde.",
    longDescription: `Ce soin unique combine différentes techniques issues de plusieurs continents pour offrir un rééquilibrage global.

Il agit à la fois sur le plan physique et énergétique, dans une approche profonde et enveloppante.

La version 90 minutes permet une immersion complète et un travail énergétique plus étendu.`,
    idealFor: "Besoin de voyage intérieur, rééquilibrage énergétique, découverte de différentes traditions.",
    result: "Un corps harmonisé, un esprit apaisé et une énergie renouvelée.",
    durations: [
      { duration: "60 min", price: "95€" },
      { duration: "90 min", price: "130€" }
    ],
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/316e2a325_massage_lomi_26.jpg"
  },
  "expanse-therapy": {
    title: "Expanse Therapy",
    shortDescription: "Une thérapie corporelle énergétique alliant précision technique et travail subtil.",
    longDescription: `L'Expanse Therapy concentre différentes approches énergétiques dans un soin structuré et puissant.

  Elle vise à relâcher les blocages, harmoniser les tensions et restaurer la circulation énergétique.

  En cure, elle devient un véritable accompagnement thérapeutique progressif.`,
    idealFor: "Blocages énergétiques, tensions chroniques, besoin d'un accompagnement en profondeur.",
    result: "Des blocages libérés, une énergie harmonisée et un bien-être durable.",
    durations: [
      { duration: "60 min", price: "90€" }
    ],
    cure: "4 séances : 320€",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/380cc2ac3_generated_image.png"
  },
  "future-maman": {
    title: "Massage Future Maman – Parenthèse Douceur",
    shortDescription: "Un soin enveloppant spécialement conçu pour la grossesse, pour relâcher les tensions et créer un lien apaisant avec votre bébé.",
    longDescription: `Offrez-vous un moment hors du temps, entièrement dédié à vous et à votre bébé.

  Ce massage enveloppant, spécialement conçu pour la grossesse, vous invite à relâcher les tensions, apaiser le corps et calmer le mental en douceur.

  Au fil des gestes lents et sécurisants, le corps se détend, les zones de tension se libèrent et un profond sentiment de bien-être s'installe.

  ✨ Une véritable parenthèse de douceur pour vous reconnecter à vos sensations et créer un lien apaisant avec votre bébé.

  Réalisé avec des positions adaptées pour garantir confort et sécurité tout au long du soin.`,
    idealFor: "Femmes enceintes à partir du 2ᵉ trimestre, détente, lien mère-bébé, soulagement des tensions.",
    result: "Détente profonde, apaisement du mental et création d'un lien rassurant avec votre bébé.",
    durations: [
      { duration: "60 min", price: "70€" }
    ],
    badge: "À partir du 2ᵉ trimestre",
    image: "https://media.base44.com/images/public/698b92bf0ecaed3d486114dc/d4366a756_generated_image.png"
  },
  "enfant-douceur": {
    title: "Rituel Douceur Enfant",
    shortDescription: "Un massage tout en douceur spécialement conçu pour les enfants, favorisant le calme et le sentiment de sécurité.",
    longDescription: `Massage tout en douceur spécialement conçu pour les enfants, favorisant le calme, la détente et le sentiment de sécurité.

  Idéal pour les enfants sensibles, stressés ou ayant du mal à gérer leurs émotions, ce soin aide à apaiser le corps et l'esprit en douceur.

  ✨ Un moment rassurant pour relâcher les tensions et retrouver sérénité et apaisement.

  La présence du parent pendant toute la séance crée un environnement sécurisant et renforce le lien de confiance. Un soin pensé pour que l'enfant se sente entendu, protégé et apaisé.`,
    idealFor: "Enfants sensibles, anxieux ou émotionnellement tendus, besoin de détente et de sécurisation.",
    result: "Un enfant apaisé, une meilleure gestion des émotions et un sentiment profond de sécurité.",
    durations: [
      { duration: "45 min", price: "60€" }
    ],
    badge: "Avec parent",
    image: "https://media.base44.com/images/public/698b92bf0ecaed3d486114dc/f8c5cae8b_generated_image.png"
  }
  };

export default function MassageDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const massageId = urlParams.get('id');
  const massage = massagesDetails[massageId];

  if (!massage) {
    return (
      <div className="pt-28 pb-20 px-6 text-center">
        <h1 className="font-heading text-2xl text-cac-ivory mb-4">Massage non trouvé</h1>
        <Link to={createPageUrl("Massages")} className="text-cac-gold hover:text-cac-gold-light">← Retour aux massages</Link>
      </div>
    );
  }

  return (
    <div className="pt-28 pb-20">
      <div className="px-6 max-w-5xl mx-auto">
        <Link 
          to={createPageUrl("Massages")} 
          className="inline-flex items-center gap-2 text-xs uppercase tracking-wider text-cac-gold hover:text-cac-gold-light transition-colors mb-8"
        >
          <ArrowLeft size={14} />
          Retour aux massages
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            className="aspect-[4/3] rounded-2xl overflow-hidden"
          >
            <img src={massage.image} alt={massage.title} className="w-full h-full object-cover" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col justify-center"
          >
            {massage.badge && (
              <span className="inline-block px-3 py-1 bg-cac-gold/10 border border-cac-gold/30 text-cac-gold text-xs uppercase tracking-wider rounded-full w-fit mb-4">
                {massage.badge}
              </span>
            )}
            <h1 className="font-heading text-3xl md:text-5xl text-cac-ivory mb-4">{massage.title}</h1>
            <p className="text-cac-gray leading-relaxed mb-6">{massage.shortDescription}</p>

            <div className="space-y-3 mb-8">
              {massage.durations.map((d, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-cac-black-light border border-cac-gray-dark/50 rounded-xl">
                  <div className="flex items-center gap-3 text-cac-ivory">
                    <Clock size={18} className="text-cac-gold" />
                    <span>{d.duration}</span>
                  </div>
                  <div className="flex items-center gap-2 text-cac-gold font-medium">
                    <Euro size={18} />
                    <span>{d.price}</span>
                  </div>
                </div>
              ))}
              {massage.cure && (
                <p className="text-sm text-cac-gold/80 italic text-center pt-2">{massage.cure}</p>
              )}
            </div>

            <Link
              to={`/RDV?massage=${encodeURIComponent(massage.title)}`}
              className="btn-gold px-8 py-3.5 rounded-full text-sm uppercase tracking-[0.15em] inline-flex items-center gap-2 w-fit"
            >
              Réserver ce soin
              <ArrowRight size={16} />
            </Link>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-12"
        >
          <div>
            <h2 className="font-heading text-2xl text-cac-ivory mb-4">Description</h2>
            <div className="gold-divider mb-6" />
            <p className="text-cac-gray leading-relaxed whitespace-pre-line">{massage.longDescription}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6">
              <div className="flex items-start gap-3 mb-3">
                <CheckCircle2 className="text-cac-gold flex-shrink-0 mt-1" size={20} />
                <div>
                  <h3 className="text-cac-ivory font-medium mb-2">Idéal pour</h3>
                  <p className="text-sm text-cac-gray leading-relaxed">{massage.idealFor}</p>
                </div>
              </div>
            </div>

            <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6">
              <div className="flex items-start gap-3 mb-3">
                <CheckCircle2 className="text-cac-gold flex-shrink-0 mt-1" size={20} />
                <div>
                  <h3 className="text-cac-ivory font-medium mb-2">Résultat</h3>
                  <p className="text-sm text-cac-gray leading-relaxed">{massage.result}</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}