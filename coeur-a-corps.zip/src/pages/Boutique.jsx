import React, { useState } from "react";
import { motion } from "framer-motion";
import SectionHeading from "../components/shared/SectionHeading";
import { useCart } from "../components/boutique/CartContext";
import CartDrawer from "../components/boutique/CartDrawer";
import ProductModal from "../components/boutique/ProductModal";
import { ShoppingBag, Plus } from "lucide-react";

const categories = [
  { id: "serviettes", name: "Serviettes Premium" },
  { id: "huiles_essentielles", name: "Huiles Essentielles" },
  { id: "huiles_massage", name: "Huiles de Massage" },
  { id: "pierres", name: "Pierres Émotionnelles" }
];

const products = [
  {
    id: "serviettes",
    title: "Serviette Premium",
    category: "serviettes",
    description: "Serviettes douces, épaisses et brodées du logo Cœur à Corps.",
    long_description: "Ces serviettes premium en coton biologique sont pensées pour une expérience sensorielle haut de gamme : douceur enveloppante, absorption exceptionnelle et durabilité. Chaque modèle est soigneusement brodé du logo Cœur à Corps, symbole d'harmonie et d'excellence.",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/a69cc726b_towels_52.jpg",
    variants: [
      { name: "Petite (30×50 cm)", price: 19, stock: 10 },
      { name: "Moyenne (50×100 cm)", price: 29, stock: 10 },
      { name: "Grande (70×140 cm)", price: 39, stock: 10 }
    ]
  },
  {
    id: "huiles-essentielles",
    title: "Huiles essentielles – Collection Harmonie",
    category: "huiles_essentielles",
    description: "Un trio d'huiles essentielles naturelles pour apaiser, revitaliser ou rééquilibrer.",
    long_description: "Chaque huile est élaborée à partir d'extraits 100% naturels et sélectionnée pour son impact émotionnel et sensoriel : Relaxante (apaisement et ancrage), Énergisante (vitalité et concentration), Équilibre (recentrage et harmonie).",
    badge: "Bio",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/c3229353b_essential_oils_55.jpg",
    variants: [
      { name: "Relaxante", price: 24, stock: 8 },
      { name: "Énergisante", price: 24, stock: 8 },
      { name: "Équilibre", price: 24, stock: 8 }
    ]
  },
  {
    id: "huiles-massage",
    title: "Huile de massage naturelle",
    category: "huiles_massage",
    description: "Une huile fluide, satinée et 100% naturelle, idéale pour les massages.",
    long_description: "Formulée à partir d'huiles végétales premium, cette huile nourrit la peau en profondeur tout en offrant une glisse optimale lors du massage. Elle respecte l'équilibre de la peau, ne laisse pas de résidu gras et accompagne parfaitement les soins manuels.",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/0bfb9778d_massage_oils_51.jpg",
    variants: [
      { name: "100 ml", price: 19, stock: 15 },
      { name: "250 ml", price: 34, stock: 10 }
    ]
  },
  {
    id: "pierres",
    title: "Pierres émotionnelles",
    category: "pierres",
    description: "Des pierres naturelles sélectionnées pour soutenir vos émotions.",
    long_description: "Chaque pierre est purifiée, énergisée et choisie pour ses vertus : Quartz rose (amour, douceur, réconfort), Améthyste (clarté, intuition, sérénité), Aventurine (équilibre, apaisement, chance). Idéal pour méditation, rituels énergétiques, décoration bien-être.",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/716292f1b_stones_53.jpg",
    variants: [
      { name: "Quartz rose – Amour", price: 14, stock: 6 },
      { name: "Améthyste – Clarté", price: 16, stock: 5 },
      { name: "Aventurine – Harmonie", price: 12, stock: 7 }
    ]
  }
];

export default function Boutique() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [cartOpen, setCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const { addToCart, totalItems } = useCart();
  
  const filteredProducts = selectedCategory === "all" 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  const handleAddToCart = (item) => {
    addToCart(item);
    setCartOpen(true);
  };

  const openProductModal = (product) => {
    setSelectedProduct(product);
  };

  return (
    <>
      <CartDrawer isOpen={cartOpen} onClose={() => setCartOpen(false)} />
      <ProductModal 
        product={selectedProduct} 
        isOpen={!!selectedProduct} 
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
      />
      
      <div className="pt-28 pb-20">
        <div className="px-6 max-w-6xl mx-auto">
          <SectionHeading
            subtitle="Notre sélection"
            title="La Boutique"
            description="Prolongez l'expérience Cœur à Corps chez vous avec notre sélection de produits naturels et artisanaux."
          />

          {/* Cart button floating */}
          {totalItems > 0 && (
            <motion.button
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              onClick={() => setCartOpen(true)}
              className="fixed bottom-24 md:bottom-8 right-6 z-40 bg-cac-gold hover:bg-cac-gold-light text-cac-black w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all hover:scale-110"
            >
              <ShoppingBag size={20} />
              <span className="absolute -top-1 -right-1 bg-cac-black text-cac-gold w-6 h-6 rounded-full text-xs flex items-center justify-center font-bold">
                {totalItems}
              </span>
            </motion.button>
          )}
        
        {/* Category filters */}
        <div className="flex flex-wrap gap-3 justify-center mb-12">
          <button
            onClick={() => setSelectedCategory("all")}
            className={`px-4 py-2 rounded-full text-xs uppercase tracking-[0.15em] transition-all ${
              selectedCategory === "all"
                ? "bg-cac-gold text-cac-black"
                : "bg-cac-black-light border border-cac-gray-dark text-cac-gray hover:text-cac-gold hover:border-cac-gold/30"
            }`}
          >
            Tout voir
          </button>
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-full text-xs uppercase tracking-[0.15em] transition-all ${
                selectedCategory === cat.id
                  ? "bg-cac-gold text-cac-black"
                  : "bg-cac-black-light border border-cac-gray-dark text-cac-gray hover:text-cac-gold hover:border-cac-gold/30"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product, i) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl overflow-hidden group hover:border-cac-gold/20 transition-all cursor-pointer"
              onClick={() => openProductModal(product)}
            >
              <div className="aspect-square overflow-hidden relative">
                {product.badge && (
                  <span className="absolute top-3 right-3 bg-cac-gold text-cac-black text-[10px] uppercase tracking-wider px-2 py-1 rounded-full font-medium z-10">
                    {product.badge}
                  </span>
                )}
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="p-5">
                <h3 className="font-heading text-lg text-cac-ivory mb-1">{product.title}</h3>
                <p className="text-xs text-cac-gray leading-relaxed mb-3 line-clamp-2">{product.description}</p>
                <div className="flex items-center justify-between">
                  <p className="text-sm text-cac-gold">
                    À partir de <span className="font-heading text-xl">{product.variants[0].price}€</span>
                  </p>
                  <button
                    onClick={() => openProductModal(product)}
                    className="bg-cac-gold/10 hover:bg-cac-gold hover:text-cac-black text-cac-gold px-3 py-2 rounded-full transition-all flex items-center gap-1.5 text-xs"
                  >
                    <Plus size={14} />
                    Ajouter
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        </div>
      </div>
    </>
  );
}