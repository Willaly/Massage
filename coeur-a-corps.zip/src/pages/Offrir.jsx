import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import SectionHeading from "../components/shared/SectionHeading";
import GiftCardPreview from "../components/gift/GiftCardPreview";
import GiftCardForm from "../components/gift/GiftCardForm";
import { Gift, Heart, CheckCircle2, Download } from "lucide-react";
import { base44 } from "@/api/base44Client";

const massageOptions = [
  { id: "harmonie", name: "Massage Harmonie" },
  { id: "palper-rouler", name: "Palper-Rouler Manuel" },
  { id: "maderotherapie", name: "Madérothérapie" },
  { id: "drainage-lymphatique", name: "Drainage Lymphatique – Méthode Brésilienne" },
  { id: "5-continents", name: "Modelage des 5 Continents" },
  { id: "expanse-therapy", name: "Expanse Therapy" },
  { id: "libre", name: "Montant libre" },
];

export default function Offrir() {
  const [step, setStep] = useState(1); // 1: form, 2: payment, 3: success
  const [formData, setFormData] = useState({
    massageType: "",
    amount: 0,
    recipientName: "",
    message: "",
    senderName: "",
    style: "romantique",
    buyerEmail: "",
    buyerPhone: "",
  });
  const [loading, setLoading] = useState(false);
  const [giftCard, setGiftCard] = useState(null);

  const handleFormSubmit = async (data) => {
    setLoading(true);
    try {
      // Create gift card order
      const order = await base44.entities.GiftCard.create({
        massage_type: data.massageType,
        amount: data.amount,
        recipient_name: data.recipientName,
        message: data.message,
        sender_name: data.senderName,
        style: data.style,
        buyer_email: data.buyerEmail,
        unique_code: `GC-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
        status: "pending"
      });

      setGiftCard(order);
      setStep(2);
    } catch (error) {
      console.error('Erreur création carte cadeau:', error);
      alert("Une erreur est survenue. Veuillez réessayer.");
    } finally {
      setLoading(false);
    }
  };

  const handlePaymentSuccess = async () => {
    setLoading(true);
    try {
      // Update gift card status to paid
      await base44.entities.GiftCard.update(giftCard.id, { status: "paid" });
      setStep(3);
    } catch (error) {
      console.error('Erreur mise à jour carte:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pt-28 pb-20">
      <div className="px-6 max-w-6xl mx-auto">
        <SectionHeading
          subtitle="Offrir du bien-être"
          title="Cartes Cadeaux"
          description="Offrez une parenthèse de douceur à ceux que vous aimez. Personnalisez votre carte cadeau et recevez-la instantanément par email."
        />

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex items-center justify-center gap-3 mb-12 text-cac-gold"
        >
          <Heart size={18} className="fill-cac-gold" />
          <span className="text-sm tracking-wide">Valable 1 an • Échangeable sur tous nos soins • PDF instantané</span>
          <Heart size={18} className="fill-cac-gold" />
        </motion.div>

        <AnimatePresence mode="wait">
          {step === 1 ? (
            <motion.div
              key="form"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              {/* Form */}
              <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-6 md:p-8">
                <GiftCardForm 
                  formData={formData}
                  setFormData={setFormData}
                  onSubmit={handleFormSubmit} 
                  loading={loading} 
                />
              </div>

              {/* Preview */}
              <div className="max-w-2xl mx-auto">
                <p className="text-xs uppercase tracking-[0.2em] text-cac-gold mb-4 text-center">Aperçu en temps réel</p>
                <GiftCardPreview data={formData} style={formData.style} />
                <p className="text-xs text-cac-gray text-center mt-4">
                  La carte sera générée au format PDF haute qualité
                </p>
              </div>
            </motion.div>
          ) : step === 2 ? (
            <motion.div
              key="payment"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-2xl mx-auto"
            >
              <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-8">
                <h2 className="font-heading text-2xl text-cac-ivory mb-6 text-center">Récapitulatif et paiement</h2>
                
                <div className="mb-8">
                  <GiftCardPreview data={formData} style={formData.style} orderNumber={giftCard?.unique_code} />
                </div>

                <div className="space-y-4 mb-8">
                  <div className="flex justify-between items-center py-3 border-b border-cac-gray-dark/30">
                    <span className="text-sm text-cac-gray">Carte cadeau</span>
                    <span className="text-cac-ivory">{formData.massageType === "libre" ? "Montant libre" : massageOptions.find(m => m.id === formData.massageType)?.name}</span>
                  </div>
                  <div className="flex justify-between items-center py-3 border-b border-cac-gray-dark/30">
                    <span className="text-sm text-cac-gray">Destinataire</span>
                    <span className="text-cac-ivory">{formData.recipientName}</span>
                  </div>
                  <div className="flex justify-between items-center py-3 border-b border-cac-gray-dark/30">
                    <span className="text-sm text-cac-gray">Code unique</span>
                    <span className="text-cac-gold font-mono text-sm">{giftCard?.unique_code}</span>
                  </div>
                  <div className="flex justify-between items-center py-4">
                    <span className="text-base font-medium text-cac-ivory">Total à payer</span>
                    <span className="font-heading text-3xl text-cac-gold">{formData.amount}€</span>
                  </div>
                </div>

                <button
                  onClick={handlePaymentSuccess}
                  disabled={loading}
                  className="w-full btn-gold rounded-full py-4 text-sm uppercase tracking-[0.15em] mb-4"
                >
                  {loading ? "Traitement..." : "Simuler paiement (Dev)"}
                </button>
                <p className="text-xs text-cac-gray text-center">
                  En conditions réelles, intégration Stripe ici
                </p>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-3xl mx-auto"
            >
              <div className="text-center mb-8">
                <CheckCircle2 size={64} className="text-cac-gold mx-auto mb-6" />
                <h2 className="font-heading text-3xl text-cac-ivory mb-4">Paiement confirmé !</h2>
                <p className="text-sm text-cac-gray max-w-lg mx-auto">
                  Votre carte cadeau est prête. Vous pouvez la télécharger et l'imprimer.
                  Un email de confirmation avec le bon de commande vous a été envoyé.
                </p>
              </div>

              <div className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl p-8 mb-8">
                <div className="max-w-2xl mx-auto mb-6">
                  <GiftCardPreview data={formData} style={formData.style} orderNumber={giftCard?.unique_code} />
                </div>

                <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
                  <button className="btn-gold px-8 py-3 rounded-full text-sm uppercase tracking-[0.15em] inline-flex items-center gap-2 justify-center">
                    <Download size={16} />
                    Télécharger (PDF)
                  </button>
                  <button className="btn-outline-gold px-8 py-3 rounded-full text-sm uppercase tracking-[0.15em] inline-flex items-center gap-2 justify-center">
                    <Gift size={16} />
                    Envoyer par email
                  </button>
                </div>

                <div className="bg-cac-gold/5 border border-cac-gold/20 rounded-xl p-6">
                  <h3 className="text-sm uppercase tracking-wider text-cac-gold mb-4">Comment utiliser cette carte ?</h3>
                  <div className="space-y-3 text-sm text-cac-gray">
                    <p>✓ La carte est valable 1 an à partir d'aujourd'hui</p>
                    <p>✓ Pour prendre rendez-vous, contactez-nous par :</p>
                    <div className="ml-4 space-y-2">
                      <p>• Email : <span className="text-cac-ivory">contact@coeuracorps.fr</span></p>
                      <p>• Téléphone : <span className="text-cac-ivory">06 XX XX XX XX</span></p>
                      <p>• WhatsApp : <a href="https://wa.me/33600000000" className="text-cac-gold hover:text-cac-gold-light">Cliquez ici</a></p>
                    </div>
                    <p className="pt-2">✓ Mentionnez le code : <span className="text-cac-gold font-mono">{giftCard?.unique_code}</span></p>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <button
                  onClick={() => {
                    setStep(1);
                    setFormData({
                      massageType: "",
                      amount: 0,
                      recipientName: "",
                      message: "",
                      senderName: "",
                      style: "romantique",
                      buyerEmail: "",
                      buyerPhone: "",
                    });
                    setGiftCard(null);
                  }}
                  className="btn-outline-gold px-8 py-3 rounded-full text-xs uppercase tracking-[0.15em] inline-flex items-center gap-2"
                >
                  Créer une nouvelle carte
                  <Gift size={14} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}