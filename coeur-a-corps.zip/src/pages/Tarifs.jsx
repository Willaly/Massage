import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import SectionHeading from "../components/shared/SectionHeading";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { ArrowRight } from "lucide-react";

const tarifs = [
  { 
    category: "Massages", 
    id: "massages",
    icon: "✨",
    items: [
      { name: "Massage Harmonie", duration: "60 min", price: "70€", description: "Soin signature enveloppant", badge: "Signature" },
      { name: "Massage Harmonie", duration: "90 min", price: "100€", description: "Soin signature enveloppant", badge: "Signature" },
      { name: "Palper-Rouler Manuel", duration: "60 min", price: "80€", description: "Soin remodelant manuel ciblé", cure: "6 séances : 420€" },
      { name: "Madérothérapie", duration: "60 min", price: "80€", description: "Technique sculptante avec instruments en bois", cure: "6 séances : 350€" },
      { name: "Drainage Lymphatique – Méthode Brésilienne", duration: "60 min", price: "90€", description: "Méthode brésilienne", cure: "6 séances : 480€" },
      { name: "Modelage des 5 Continents", duration: "60 min", price: "95€", description: "Voyage énergétique mondial" },
      { name: "Modelage des 5 Continents", duration: "90 min", price: "130€", description: "Voyage énergétique mondial" },
      { name: "Expanse Therapy", duration: "60 min", price: "90€", description: "Thérapie corporelle énergétique", cure: "4 séances : 320€" },
    ]
  },
  { 
    category: "Formations", 
    id: "formations",
    icon: "🎓",
    items: [
      { name: "Formation Massage Harmonie", duration: "2 jours", price: "450€", description: "Toucher enveloppant, fluide et relaxant" },
      { name: "Formation Drainage Lymphatique – Méthode Brésilienne", duration: "2 jours", price: "490€", description: "Stimulation lymphatique et effet détox" },
      { name: "Formation Madérothérapie", duration: "2 jours", price: "490€", description: "Remodelage corporel avec instruments en bois" },
      { name: "Formation Modelage des 5 Continents", duration: "2 jours", price: "500€", description: "Techniques énergétiques du monde entier" },
    ]
  },
  { 
    category: "Cartes Cadeaux", 
    id: "cadeaux",
    icon: "🎁",
    items: [
      { name: "Massage Harmonie", duration: "60 min", price: "70€", description: "Soin signature enveloppant" },
      { name: "Massage Harmonie", duration: "90 min", price: "100€", description: "Soin signature enveloppant" },
      { name: "Palper-Rouler Manuel", duration: "60 min", price: "80€", description: "Soin remodelant ciblé" },
      { name: "Madérothérapie", duration: "60 min", price: "80€", description: "Technique sculptante en bois" },
      { name: "Drainage Lymphatique – Méthode Brésilienne", duration: "60 min", price: "90€", description: "Méthode brésilienne" },
      { name: "Modelage des 5 Continents", duration: "60 min", price: "95€", description: "Voyage énergétique mondial" },
      { name: "Expanse Therapy", duration: "60 min", price: "90€", description: "Thérapie corporelle énergétique" },
    ]
  },
  { 
    category: "Boutique", 
    id: "boutique",
    icon: "🛍️",
    items: [
      { name: "Serviette Premium – Petite", duration: "", price: "19€", description: "Serviette douce brodée du logo Cœur à Corps" },
      { name: "Serviette Premium – Moyenne", duration: "", price: "29€", description: "Serviette douce brodée du logo Cœur à Corps" },
      { name: "Serviette Premium – Grande", duration: "", price: "39€", description: "Serviette douce brodée du logo Cœur à Corps" },
      { name: "Huile essentielle Relaxante", duration: "", price: "24€", description: "Collection Harmonie – 100% naturelle" },
      { name: "Huile essentielle Énergisante", duration: "", price: "24€", description: "Collection Harmonie – 100% naturelle" },
      { name: "Huile essentielle Équilibre", duration: "", price: "24€", description: "Collection Harmonie – 100% naturelle" },
      { name: "Huile de massage Naturelle – 100 ml", duration: "", price: "19€", description: "Formulée à partir d'huiles végétales premium" },
      { name: "Huile de massage Naturelle – 250 ml", duration: "", price: "34€", description: "Formulée à partir d'huiles végétales premium" },
      { name: "Quartz rose – Amour", duration: "", price: "14€", description: "Pierre naturelle pour soutenir vos émotions" },
      { name: "Améthyste – Clarté", duration: "", price: "16€", description: "Pierre naturelle pour soutenir vos émotions" },
      { name: "Aventurine – Harmonie", duration: "", price: "12€", description: "Pierre naturelle pour soutenir vos émotions" },
    ]
  }
];

const filters = [
  { id: "all", label: "Tous les tarifs" },
  { id: "massages", label: "✨ Massages" },
  { id: "formations", label: "🎓 Formations" },
  { id: "cadeaux", label: "🎁 Cartes Cadeaux" },
  { id: "boutique", label: "🛍️ Boutique" },
];

export default function Tarifs() {
  const [activeFilter, setActiveFilter] = useState("all");

  const visibleTarifs = activeFilter === "all"
    ? tarifs
    : tarifs.filter(t => t.id === activeFilter);

  const ctaConfig = {
    all: { label: "Réserver un massage", page: "RDV" },
    massages: { label: "Réserver un massage", page: "RDV" },
    formations: { label: "S'inscrire à une formation", page: "Formations" },
    cadeaux: { label: "Offrir une carte cadeau", page: "Offrir" },
    boutique: { label: "Visiter la boutique", page: "Boutique" },
  };

  return (
    <div className="pt-28 pb-20">
      <div className="px-6 max-w-4xl mx-auto">
        <SectionHeading
          subtitle="Nos prix"
          title="Tarifs"
          description="Des soins accessibles pour un bien-être au quotidien. Découvrez nos forfaits avantageux pour les habitués."
        />

        {/* Filtres */}
        <div className="flex flex-wrap gap-3 justify-center mb-10">
          {filters.map(f => (
            <button
              key={f.id}
              onClick={() => setActiveFilter(f.id)}
              className={`px-5 py-2.5 rounded-full text-xs uppercase tracking-[0.15em] transition-all ${
                activeFilter === f.id
                  ? "bg-cac-gold text-cac-black font-medium"
                  : "bg-cac-black-light border border-cac-gray-dark text-cac-gray hover:text-cac-gold hover:border-cac-gold/30"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Tableau */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeFilter}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="space-y-8"
          >
            {visibleTarifs.map((section) => (
              <div
                key={section.id}
                className="bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl overflow-hidden"
              >
                <div className="px-6 md:px-8 py-5 border-b border-cac-gray-dark/50">
                  <h3 className="font-heading text-xl text-cac-gold flex items-center gap-2">
                    <span>{section.icon}</span>
                    {section.category}
                  </h3>
                </div>
                <div className="divide-y divide-cac-gray-dark/30">
                  {section.items.map((item, idx) => (
                    <div key={`${item.name}-${idx}`} className="px-6 md:px-8 py-4 flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="text-sm text-cac-ivory font-medium">{item.name}</p>
                          {item.badge && (
                            <span className="text-[9px] uppercase tracking-wider bg-cac-gold/20 text-cac-gold px-2 py-0.5 rounded-full">
                              {item.badge}
                            </span>
                          )}
                        </div>
                        {item.duration && <p className="text-xs text-cac-gray mb-1">{item.duration}</p>}
                        {item.description && <p className="text-xs text-cac-gray leading-relaxed mb-1">{item.description}</p>}
                        {item.cure && <p className="text-[11px] text-cac-gold/80 italic">{item.cure}</p>}
                      </div>
                      <p className="font-heading text-lg text-cac-gold whitespace-nowrap">{item.price}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </motion.div>
        </AnimatePresence>

        <div className="text-center mt-12">
          <Link
            to={createPageUrl(ctaConfig[activeFilter].page)}
            className="btn-gold px-8 py-3.5 rounded-full text-sm uppercase tracking-[0.15em] inline-flex items-center gap-2"
          >
            {ctaConfig[activeFilter].label}
            <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </div>
  );
}