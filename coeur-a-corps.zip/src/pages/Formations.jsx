import React from "react";
import { motion } from "framer-motion";
import SectionHeading from "../components/shared/SectionHeading";
import { Link } from "react-router-dom";
import { createPageUrl } from "../utils";
import { Calendar, Users, Award, ArrowRight } from "lucide-react";

const formations = [
  {
    title: "Formation Massage Harmonie",
    emoji: "🌿",
    description: "Un massage inspiré du californien, alliant douceur et profondeur. Cette formation vous permet d'apprendre un toucher enveloppant, fluide et relaxant, favorisant un lâcher-prise total.",
    duration: "2 jours",
    price: "450€",
    ideal: "Idéal pour procurer une relaxation intense et un bien-être global.",
    program: ["Techniques de massage relaxant", "Gestes profonds et harmonieux", "Détente musculaire et émotionnelle", "Création d'un enchaînement fluide et intuitif"],
    image: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=600&q=80"
  },
  {
    title: "Formation Drainage Lymphatique – Méthode Brésilienne",
    emoji: "💧",
    description: "Une technique dynamique et efficace qui stimule la circulation lymphatique et favorise l'élimination des toxines.",
    duration: "2 jours",
    price: "490€",
    ideal: "Une méthode très demandée pour ses résultats visibles et rapides.",
    program: ["Gestes rythmés et précis", "Effet détox et jambes légères", "Réduction de la rétention d'eau", "Silhouette affinée et tonifiée"],
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/698b92bf0ecaed3d486114dc/40244d92c_massage_drainage_24.jpg"
  },
  {
    title: "Formation Maderothérapie",
    emoji: "🌳",
    description: "Technique naturelle utilisant des outils en bois pour remodeler le corps et stimuler les tissus en profondeur.",
    duration: "2 jours",
    price: "490€",
    ideal: "Idéal pour sculpter et raffermir la silhouette.",
    program: ["Utilisation des instruments en bois", "Travail ciblé sur la cellulite", "Activation de la circulation", "Effet drainant et tonifiant"],
    image: "https://media.base44.com/images/public/698b92bf0ecaed3d486114dc/603443d37_formation_madero_15.jpg"
  },
  {
    title: "Formation Massage des 5 Continents",
    emoji: "🌍",
    description: "Un massage énergétique puissant combinant plusieurs techniques du monde et l'utilisation d'huiles essentielles.",
    duration: "2 jours",
    price: "500€",
    ideal: "Un soin complet qui agit sur le corps et l'esprit.",
    program: ["Techniques issues de différentes cultures", "Travail énergétique et émotionnel", "Détoxification du corps", "Relaxation profonde et revitalisation"],
    image: "https://images.unsplash.com/photo-1507652313519-d4e9174996dd?w=600&q=80"
  }
];

export default function Formations() {
  return (
    <div className="pt-28 pb-20">
      <div className="px-6 max-w-6xl mx-auto">
        <SectionHeading
          subtitle="Se former"
          title="Nos Formations"
          description="Transmettez l'art du bien-être. Nos formations allient théorie, pratique et développement personnel pour vous accompagner dans votre parcours."
        />
        <div className="space-y-8">
          {formations.map((formation, i) => (
            <motion.div
              key={formation.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="flex flex-col md:flex-row gap-6 bg-cac-black-light border border-cac-gray-dark/50 rounded-2xl overflow-hidden group hover:border-cac-gold/20 transition-all"
            >
              <div className="md:w-1/3 aspect-video md:aspect-auto overflow-hidden">
                <img
                  src={formation.image}
                  alt={formation.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="flex-1 p-6 md:p-8 flex flex-col justify-center">
                <div className="flex flex-wrap gap-3 mb-4">
                  <span className="inline-flex items-center gap-1.5 text-xs text-cac-gold bg-cac-gold/10 px-3 py-1 rounded-full">
                    <Calendar size={12} /> {formation.duration}
                  </span>
                </div>
                <h3 className="font-heading text-2xl text-cac-ivory mb-3">
                  <span className="mr-2">{formation.emoji}</span>{formation.title}
                </h3>
                <p className="text-sm text-cac-gray leading-relaxed mb-4">{formation.description}</p>
                <div className="mb-4">
                  <p className="text-xs uppercase tracking-wider text-cac-gold mb-2">Au programme :</p>
                  <ul className="text-xs text-cac-gray space-y-1">
                    {formation.program.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-cac-gold mt-0.5">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <p className="text-xs text-cac-ivory/70 italic mb-2">👉 {formation.ideal}</p>
                <div className="flex items-center justify-between gap-4 mt-auto pt-4">
                  <p className="font-heading text-xl text-cac-gold">{formation.price}</p>
                  <Link
                    to={createPageUrl("Contact")}
                    className="btn-outline-gold px-6 py-2.5 rounded-full text-xs uppercase tracking-[0.15em] inline-flex items-center gap-2"
                  >
                    Inscription
                    <ArrowRight size={14} />
                  </Link>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}