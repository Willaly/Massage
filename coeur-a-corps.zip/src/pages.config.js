/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import APropos from './pages/APropos';
import Admin from './pages/Admin';
import Blog from './pages/Blog';
import BlogArticle from './pages/BlogArticle';
import Boutique from './pages/Boutique';
import Contact from './pages/Contact';
import Formations from './pages/Formations';
import Home from './pages/Home';
import MassageDetail from './pages/MassageDetail';
import Massages from './pages/Massages';
import Offrir from './pages/Offrir';
import Questionnaire from './pages/Questionnaire';
import QuestionnaireChoix from './pages/QuestionnaireChoix';
import RDV from './pages/RDV';
import Tarifs from './pages/Tarifs';
import Temoignages from './pages/Temoignages';
import __Layout from './Layout.jsx';


export const PAGES = {
    "APropos": APropos,
    "Admin": Admin,
    "Blog": Blog,
    "BlogArticle": BlogArticle,
    "Boutique": Boutique,
    "Contact": Contact,
    "Formations": Formations,
    "Home": Home,
    "MassageDetail": MassageDetail,
    "Massages": Massages,
    "Offrir": Offrir,
    "Questionnaire": Questionnaire,
    "QuestionnaireChoix": QuestionnaireChoix,
    "RDV": RDV,
    "Tarifs": Tarifs,
    "Temoignages": Temoignages,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};