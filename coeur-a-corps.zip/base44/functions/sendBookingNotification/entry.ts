import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

function toBase64url(str) {
  const bytes = new TextEncoder().encode(str);
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function makeEmail({ to, subject, body }) {
  const mime = [
    `To: ${to}`,
    `Subject: =?UTF-8?B?${toBase64url(subject)}?=`,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    toBase64url(body)
  ].join('\r\n');
  return toBase64url(mime);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { event, data } = await req.json();

    if (event.type !== 'create') {
      return Response.json({ success: true, message: 'Ignored non-create event' });
    }

    const settings = await base44.asServiceRole.entities.Settings.filter({ key: 'admin_email' });
    const adminEmail = settings[0]?.value || 'marineproservices83@gmail.com';

    const { accessToken } = await base44.asServiceRole.connectors.getConnection('gmail');

    const emailBody = `Nouvelle réservation reçue :

Service : ${data.service_name}
Client : ${data.client_name}
Email : ${data.client_email}
Téléphone : ${data.client_phone || 'Non fourni'}
Date : ${data.booking_date}
Heure : ${data.booking_time}
Durée : ${data.duration_minutes} minutes
Notes : ${data.notes || 'Aucune'}

Statut : ${data.status}
ID réservation : ${data.id}`;

    const raw = makeEmail({
      to: adminEmail,
      subject: `[RÉSERVATION] ${data.service_name} - ${data.client_name}`,
      body: emailBody
    });

    const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ raw })
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Gmail API error: ${err}`);
    }

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});