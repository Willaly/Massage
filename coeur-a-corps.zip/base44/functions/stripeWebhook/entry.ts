import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Stripe from 'npm:stripe@14.21.0';

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY"));
const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");

function toBase64(str) {
  const bytes = new TextEncoder().encode(str);
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function toBase64Url(str) {
  return toBase64(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function buildMimeEmailHtml({ to, from, subject, bodyHtml, bodyText }) {
  const boundary = `boundary_cac_${Date.now()}`;
  const subjectEncoded = `=?UTF-8?B?${toBase64(subject)}?=`;
  const lines = [
    `From: ${from}`,
    `To: ${to}`,
    `Subject: ${subjectEncoded}`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    '',
    `--${boundary}`,
    'Content-Type: text/plain; charset="UTF-8"',
    'Content-Transfer-Encoding: base64',
    '',
    toBase64(bodyText),
    '',
    `--${boundary}`,
    'Content-Type: text/html; charset="UTF-8"',
    'Content-Transfer-Encoding: base64',
    '',
    toBase64(bodyHtml),
    '',
    `--${boundary}--`
  ].join('\r\n');
  return toBase64Url(lines);
}

function buildMimeEmail({ to, from, subject, bodyText }) {
  const subjectEncoded = `=?UTF-8?B?${toBase64(subject)}?=`;
  const lines = [
    `From: ${from}`,
    `To: ${to}`,
    `Subject: ${subjectEncoded}`,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset="UTF-8"',
    'Content-Transfer-Encoding: base64',
    '',
    toBase64(bodyText)
  ].join('\r\n');
  return toBase64Url(lines);
}

Deno.serve(async (req) => {
  const body = await req.text();
  const signature = req.headers.get('stripe-signature');

  let event;
  try {
    event = await stripe.webhooks.constructEventAsync(body, signature, webhookSecret);
  } catch (err) {
    console.error('Webhook signature invalide:', err.message);
    return new Response(`Webhook Error: ${err.message}`, { status: 400 });
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const bookingId = session.metadata?.booking_id;

    if (!bookingId) {
      console.log('Pas de booking_id dans les metadata, ignore');
      return Response.json({ received: true });
    }

    try {
      const base44 = createClientFromRequest(req);

      // Confirmer la réservation
      await base44.asServiceRole.entities.Booking.update(bookingId, {
        status: 'confirmed',
        notes: `Paiement Stripe confirme - Session: ${session.id}`
      });

      console.log(`Booking ${bookingId} confirme via Stripe`);

      // Récupérer les détails de la réservation
      const booking = await base44.asServiceRole.entities.Booking.get(bookingId);

      const clientEmail = session.customer_email;
      const clientName = session.metadata?.client_name || booking?.client_name || 'Client';
      const serviceName = session.metadata?.service_name || booking?.service_name || 'Massage';
      const amountPaid = (session.amount_total / 100).toFixed(2);
      const bookingCode = bookingId.slice(-8).toUpperCase();

      // Formater la date
      const dateFormatted = booking?.booking_date
        ? new Date(booking.booking_date + 'T12:00:00').toLocaleDateString('fr-FR', {
            weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
          })
        : '';

      const addressLine = '342 Promenade General Charles de Gaulle, 83140 Six-Fours-les-Plages';
      const addressEncoded = encodeURIComponent('Salon Mastroianni, ' + addressLine);
      const mapsUrl = `https://maps.google.com/?q=${addressEncoded}`;

      // Récupérer le questionnaire santé depuis les metadata Stripe
      let health = {};
      try {
        if (session.metadata?.health_data) {
          health = JSON.parse(session.metadata.health_data);
        }
      } catch (e) {
        console.log('Pas de health_data dans metadata');
      }
      const hasHealthData = Object.keys(health).length > 0;

      const healthSection = hasHealthData ? `
        <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:24px;">
          <tr><td style="padding:16px 24px;border-bottom:1px solid #252525;">
            <p style="margin:0;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#C9A96E;">Questionnaire sante</p>
          </td></tr>
          <tr><td style="padding:16px 24px;">
            <table width="100%" cellpadding="0" cellspacing="0">
              ${health.pregnant ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Grossesse</span><br><span style="font-size:13px;color:#FFFBF0;">${health.pregnant}</span></td></tr>` : ''}
              ${health.allergies ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Allergies</span><br><span style="font-size:13px;color:#FFFBF0;">${health.allergies}</span></td></tr>` : ''}
              ${health.conditions ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Conditions medicales</span><br><span style="font-size:13px;color:#FFFBF0;">${health.conditions}</span></td></tr>` : ''}
              ${health.areas ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Zones sensibles</span><br><span style="font-size:13px;color:#FFFBF0;">${health.areas}</span></td></tr>` : ''}
              ${health.expectations ? `<tr><td style="padding:8px 0;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Attentes</span><br><span style="font-size:13px;color:#FFFBF0;">${health.expectations}</span></td></tr>` : ''}
            </table>
          </td></tr>
        </table>` : '';

      // Email HTML client
      const clientEmailHtml = `<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Reservation confirmee</title></head>
<body style="margin:0;padding:0;background-color:#0A0A0A;font-family:Arial,Helvetica,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#0A0A0A;padding:40px 20px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">

        <tr><td style="background:#141414;border:1px solid #C9A96E;border-radius:12px 12px 0 0;padding:40px;text-align:center;">
          <p style="margin:0 0 4px;font-size:11px;letter-spacing:4px;text-transform:uppercase;color:#C9A96E;">Massages et Bien-etre</p>
          <h1 style="margin:0;font-size:30px;color:#FFFBF0;font-weight:300;letter-spacing:2px;">Coeur a Corps</h1>
          <div style="width:60px;height:1px;background:#C9A96E;margin:16px auto;"></div>
          <p style="margin:0;font-size:13px;color:#C9A96E;letter-spacing:2px;text-transform:uppercase;">Paiement recu - Reservation confirmee</p>
        </td></tr>

        <tr><td style="background-color:#141414;border-left:1px solid #C9A96E;border-right:1px solid #C9A96E;padding:40px;">

          <p style="color:#FFFBF0;font-size:16px;margin:0 0 12px;">Bonjour <strong style="color:#C9A96E;">${clientName}</strong>,</p>
          <p style="color:#aaaaaa;font-size:14px;line-height:1.7;margin:0 0 32px;">Votre paiement de <strong style="color:#C9A96E;">${amountPaid} EUR</strong> a bien ete recu. Votre reservation est confirmee !</p>

          <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:24px;">
            <tr><td style="padding:16px 24px;border-bottom:1px solid #252525;">
              <p style="margin:0;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#C9A96E;">Recapitulatif</p>
            </td></tr>
            <tr><td style="padding:0 24px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr><td style="padding:14px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Date</span><br>
                  <span style="font-size:15px;color:#FFFBF0;font-weight:500;">${dateFormatted}</span>
                </td></tr>
                <tr><td style="padding:14px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Heure</span><br>
                  <span style="font-size:15px;color:#FFFBF0;font-weight:500;">${booking?.booking_time || ''}</span>
                </td></tr>
                <tr><td style="padding:14px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Soin</span><br>
                  <span style="font-size:15px;color:#FFFBF0;font-weight:500;">${serviceName}</span><br>
                  <span style="font-size:12px;color:#888;">Duree : ${booking?.duration_minutes || ''} minutes</span>
                </td></tr>
                <tr><td style="padding:14px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Paiement</span><br>
                  <span style="font-size:14px;color:#C9A96E;font-weight:600;">${amountPaid} EUR - Paiement en ligne confirme</span>
                </td></tr>
                <tr><td style="padding:14px 0;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Code de reservation</span><br>
                  <span style="font-size:20px;color:#C9A96E;font-weight:700;letter-spacing:4px;">${bookingCode}</span>
                </td></tr>
              </table>
            </td></tr>
          </table>

          <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:24px;">
            <tr><td style="padding:16px 24px;">
              <p style="margin:0 0 8px;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#C9A96E;">Adresse</p>
              <p style="margin:0 0 4px;font-size:14px;color:#FFFBF0;">Salon Mastroianni</p>
              <p style="margin:0 0 16px;font-size:13px;color:#aaa;">${addressLine}</p>
              <a href="${mapsUrl}" style="display:inline-block;background:#C9A96E;color:#0A0A0A;text-decoration:none;font-size:11px;font-weight:600;letter-spacing:1px;text-transform:uppercase;padding:9px 18px;border-radius:20px;">Voir sur Google Maps</a>
            </td></tr>
          </table>

          ${healthSection}

          <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:32px;">
            <tr><td style="padding:16px 24px;">
              <p style="margin:0 0 12px;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#C9A96E;">Infos pratiques</p>
              <p style="margin:0 0 8px;font-size:13px;color:#aaa;line-height:1.6;">Nous vous recommandons d'arriver 5 minutes avant l'heure prevue.</p>
              <p style="margin:0 0 8px;font-size:13px;color:#aaa;line-height:1.6;">En cas d'annulation, merci de nous prevenir au moins <strong style="color:#FFFBF0;">24h a l'avance</strong>.</p>
              <p style="margin:0;font-size:13px;color:#aaa;line-height:1.6;">Portez des vetements confortables, nous nous occupons du reste.</p>
            </td></tr>
          </table>

          <p style="font-size:13px;color:#888;margin:0 0 8px;">Une question ? Contactez-nous :</p>
          <p style="margin:0 0 6px;"><a href="tel:+33650543613" style="color:#C9A96E;text-decoration:none;font-size:14px;">06 50 54 36 13</a></p>
          <p style="margin:0;"><a href="https://wa.me/33650543613" style="color:#C9A96E;text-decoration:none;font-size:14px;">WhatsApp</a></p>

        </td></tr>

        <tr><td style="background:#0A0A0A;border:1px solid #C9A96E;border-top:none;border-radius:0 0 12px 12px;padding:24px 40px;text-align:center;">
          <p style="margin:0 0 4px;font-size:11px;color:#C9A96E;letter-spacing:2px;text-transform:uppercase;">Coeur a Corps</p>
          <p style="margin:0;font-size:11px;color:#555;">Massages et Bien-etre - Six-Fours-les-Plages</p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`;

      const clientEmailText = `Bonjour ${clientName},\n\nVotre paiement de ${amountPaid} EUR a bien ete recu.\n\nDate : ${dateFormatted}\nHeure : ${booking?.booking_time || ''}\nSoin : ${serviceName} (${booking?.duration_minutes || ''} min)\nCode : ${bookingCode}\n\nAdresse : Salon Mastroianni, ${addressLine}\n\nNous joindre : 06 50 54 36 13\n\nA bientot,\nCoeur a Corps`;

      // Envoyer via Gmail
      const { accessToken: gmailToken } = await base44.asServiceRole.connectors.getConnection('gmail');

      const clientRaw = buildMimeEmailHtml({
        to: clientEmail,
        from: 'Coeur a Corps <marineproservices83@gmail.com>',
        subject: `Reservation confirmee - ${serviceName}`,
        bodyHtml: clientEmailHtml,
        bodyText: clientEmailText
      });

      await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${gmailToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ raw: clientRaw })
      });

      // Email admin HTML
      const adminHealthSection = hasHealthData ? `
        <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:24px;">
          <tr><td style="padding:16px 24px;border-bottom:1px solid #252525;">
            <p style="margin:0;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#C9A96E;">Questionnaire sante</p>
          </td></tr>
          <tr><td style="padding:16px 24px;">
            <table width="100%" cellpadding="0" cellspacing="0">
              ${health.pregnant ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Grossesse</span><br><span style="font-size:13px;color:#FFFBF0;">${health.pregnant}</span></td></tr>` : ''}
              ${health.allergies ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Allergies</span><br><span style="font-size:13px;color:#FFFBF0;">${health.allergies}</span></td></tr>` : ''}
              ${health.conditions ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Conditions medicales</span><br><span style="font-size:13px;color:#FFFBF0;">${health.conditions}</span></td></tr>` : ''}
              ${health.areas ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Zones sensibles</span><br><span style="font-size:13px;color:#FFFBF0;">${health.areas}</span></td></tr>` : ''}
              ${health.expectations ? `<tr><td style="padding:8px 0;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Attentes</span><br><span style="font-size:13px;color:#FFFBF0;">${health.expectations}</span></td></tr>` : ''}
            </table>
          </td></tr>
        </table>` : `
        <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:24px;">
          <tr><td style="padding:16px 24px;">
            <p style="margin:0;font-size:11px;color:#666;font-style:italic;">Questionnaire sante non rempli.</p>
          </td></tr>
        </table>`;

      const adminEmailHtml = `<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Reservation payee</title></head>
<body style="margin:0;padding:0;background-color:#0A0A0A;font-family:Arial,Helvetica,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#0A0A0A;padding:40px 20px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">

        <tr><td style="background:#141414;border:1px solid #C9A96E;border-radius:12px 12px 0 0;padding:40px;text-align:center;">
          <p style="margin:0 0 4px;font-size:11px;letter-spacing:4px;text-transform:uppercase;color:#C9A96E;">Coeur a Corps</p>
          <h1 style="margin:0;font-size:26px;color:#FFFBF0;font-weight:300;letter-spacing:2px;">Nouvelle reservation</h1>
          <div style="width:60px;height:1px;background:#C9A96E;margin:16px auto;"></div>
          <p style="margin:0;font-size:13px;color:#C9A96E;letter-spacing:2px;text-transform:uppercase;">Paiement en ligne confirme — ${amountPaid} EUR</p>
        </td></tr>

        <tr><td style="background-color:#141414;border-left:1px solid #C9A96E;border-right:1px solid #C9A96E;padding:40px;">

          <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:24px;">
            <tr><td style="padding:16px 24px;border-bottom:1px solid #252525;">
              <p style="margin:0;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#C9A96E;">Client</p>
            </td></tr>
            <tr><td style="padding:0 24px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr><td style="padding:12px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Nom</span><br>
                  <span style="font-size:15px;color:#FFFBF0;font-weight:500;">${clientName}</span>
                </td></tr>
                <tr><td style="padding:12px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Email</span><br>
                  <a href="mailto:${clientEmail}" style="font-size:14px;color:#C9A96E;">${clientEmail}</a>
                </td></tr>
                <tr><td style="padding:12px 0;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Telephone</span><br>
                  <span style="font-size:14px;color:#FFFBF0;">${booking?.client_phone || 'Non renseigne'}</span>
                </td></tr>
              </table>
            </td></tr>
          </table>

          <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:24px;">
            <tr><td style="padding:16px 24px;border-bottom:1px solid #252525;">
              <p style="margin:0;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#C9A96E;">Soin</p>
            </td></tr>
            <tr><td style="padding:0 24px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr><td style="padding:12px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Date</span><br>
                  <span style="font-size:15px;color:#FFFBF0;font-weight:500;">${dateFormatted}</span>
                </td></tr>
                <tr><td style="padding:12px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Heure</span><br>
                  <span style="font-size:15px;color:#FFFBF0;font-weight:500;">${booking?.booking_time || ''}</span>
                </td></tr>
                <tr><td style="padding:12px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Soin</span><br>
                  <span style="font-size:15px;color:#FFFBF0;font-weight:500;">${serviceName}</span><br>
                  <span style="font-size:12px;color:#888;">Duree : ${booking?.duration_minutes || ''} minutes</span>
                </td></tr>
                <tr><td style="padding:12px 0;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Paiement</span><br>
                  <span style="font-size:14px;color:#C9A96E;font-weight:600;">${amountPaid} EUR — en ligne confirme</span>
                </td></tr>
              </table>
            </td></tr>
          </table>

          ${adminHealthSection}

          <p style="font-size:12px;color:#555;margin:0 0 4px;">ID reservation : ${bookingId}</p>
          <p style="font-size:12px;color:#555;margin:0;">Session Stripe : ${session.id}</p>

        </td></tr>

        <tr><td style="background:#0A0A0A;border:1px solid #C9A96E;border-top:none;border-radius:0 0 12px 12px;padding:24px 40px;text-align:center;">
          <p style="margin:0;font-size:11px;color:#555;">Coeur a Corps — Massages et Bien-etre - Six-Fours-les-Plages</p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`;

      const adminEmailText = `Reservation PAYEE - ${serviceName}\nClient : ${clientName} (${clientEmail})\nDate : ${dateFormatted} a ${booking?.booking_time || ''}\nDuree : ${booking?.duration_minutes || ''} min\nMontant : ${amountPaid} EUR`;

      const adminRaw = buildMimeEmailHtml({
        to: 'marineproservices83@gmail.com',
        from: 'Reservations Coeur a Corps <marineproservices83@gmail.com>',
        subject: `[PAYE] ${serviceName} - ${clientName}`,
        bodyHtml: adminEmailHtml,
        bodyText: adminEmailText
      });

      await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${gmailToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ raw: adminRaw })
      });

      console.log(`Emails envoyes apres paiement Stripe pour booking ${bookingId}`);

    } catch (err) {
      console.error('Erreur confirmation booking:', err.message);
      return Response.json({ error: err.message }, { status: 500 });
    }
  }

  if (event.type === 'checkout.session.expired') {
    const session = event.data.object;
    const bookingId = session.metadata?.booking_id;
    if (bookingId) {
      try {
        const base44 = createClientFromRequest(req);
        await base44.asServiceRole.entities.Booking.update(bookingId, { status: 'cancelled' });
        console.log(`Booking ${bookingId} annule (session Stripe expiree)`);
      } catch (err) {
        console.error('Erreur annulation booking:', err.message);
      }
    }
  }

  return Response.json({ received: true });
});