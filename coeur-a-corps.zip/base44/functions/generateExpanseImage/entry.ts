import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        
        const user = await base44.auth.me();
        if (!user || user.role !== 'admin') {
            return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
        }

        const result = await base44.asServiceRole.integrations.Core.GenerateImage({
            prompt: "Professional spa massage therapy session showing energy healing bodywork, therapist's hands performing gentle touch therapy on client in serene wellness environment, warm candlelight ambiance, soft golden lighting, luxury spa setting with white towels, peaceful and calming atmosphere, professional photography, high quality, warm color palette"
        });

        return Response.json({ 
            success: true,
            image_url: result.url 
        });
    } catch (error) {
        return Response.json({ 
            error: error.message 
        }, { status: 500 });
    }
});