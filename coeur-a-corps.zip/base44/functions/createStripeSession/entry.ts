import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import Stripe from 'npm:stripe@14.21.0';

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY"));

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const body = await req.json();
    const { service, date, time, paymentMode, clientInfo, healthData, bookingId } = body;

    // Prix avec réduction 5% si paiement en ligne
    const priceInCents = Math.round(service.price * 0.95 * 100);

    const appUrl = req.headers.get('origin') || 'https://app.base44.com';

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      locale: 'fr',
      line_items: [
        {
          price_data: {
            currency: 'eur',
            product_data: {
              name: `${service.name} (${service.duration_minutes} min)`,
              description: `Rendez-vous le ${date} à ${time} — Paiement en ligne (-5%)`,
              images: service.image_url ? [service.image_url] : ['https://images.unsplash.com/photo-1600334089648-b0d9d3028eb2?w=400&h=300&fit=crop'],
            },
            unit_amount: priceInCents,
          },
          quantity: 1,
        },
      ],
      mode: 'payment',
      success_url: `${appUrl}/RDV?payment=success&booking_id=${bookingId}`,
      cancel_url: `${appUrl}/RDV?payment=cancelled`,
      customer_email: clientInfo.client_email,
      allow_promotion_codes: true,
      consent_collection: {
        terms_of_service: 'required',
      },
      custom_text: {
        terms_of_service_acceptance: {
          message: 'En confirmant votre paiement, vous acceptez notre [politique d\'annulation](https://coeuracorps.fr/MentionsLegales) : tout rendez-vous annulé moins de 24h avant la séance sera dû en totalité.',
        },
      },
      metadata: {
        booking_id: bookingId,
        service_name: service.name,
        client_name: clientInfo.client_name,
        payment_mode: 'online',
        health_data: healthData ? JSON.stringify(healthData).slice(0, 500) : '',
      },
    });

    return Response.json({ success: true, url: session.url, session_id: session.id });
  } catch (error) {
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
});