import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Register the current user as admin
    await base44.users.inviteUser(user.email, 'admin');

    return Response.json({ 
      success: true, 
      message: `${user.email} registered as admin` 
    });
  } catch (error) {
    // If user already exists, it's fine
    if (error.message?.includes('already')) {
      return Response.json({ 
        success: true, 
        message: 'User already registered' 
      });
    }
    return Response.json({ error: error.message }, { status: 500 });
  }
});