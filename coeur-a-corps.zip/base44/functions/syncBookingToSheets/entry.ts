import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Helper: appel API Sheets
async function sheetsApi(token, path, method = 'GET', body = null) {
  const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets${path}`, {
    method,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: body ? JSON.stringify(body) : null
  });
  return res.json();
}

// Helper: créer un spreadsheet
async function createSpreadsheet(token, title, sheets) {
  const res = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      properties: { title },
      sheets: sheets.map(s => ({ properties: { title: s } }))
    })
  });
  return res.json();
}

// Helper: récupérer ou créer les spreadsheet IDs depuis Settings
async function getOrCreateSheets(base44, token) {
  const settings = await base44.asServiceRole.entities.Settings.filter({});
  const clientsSetting = settings.find(s => s.key === 'sheets_clients_id');
  const mensuelSetting = settings.find(s => s.key === 'sheets_mensuel_id');

  let clientsSheetId = clientsSetting?.value;
  let mensuelSheetId = mensuelSetting?.value;

  // Créer le spreadsheet Clients si inexistant
  if (!clientsSheetId) {
    const created = await createSpreadsheet(token, 'Cœur à Corps — Clients', ['Clients']);
    clientsSheetId = created.spreadsheetId;
    // Ajouter les headers
    await sheetsApi(token, `/${clientsSheetId}/values/Clients!A1:F1?valueInputOption=RAW`, 'PUT', {
      values: [['Nom', 'Email', 'Téléphone', 'Première réservation', 'Dernière réservation', 'Total dépenses (€)']]
    });
    await base44.asServiceRole.entities.Settings.create({
      key: 'sheets_clients_id',
      value: clientsSheetId,
      description: 'ID du Google Sheet Clients'
    });
    console.log('Spreadsheet Clients créé :', clientsSheetId);
  }

  // Créer le spreadsheet Résumé mensuel si inexistant
  if (!mensuelSheetId) {
    const created = await createSpreadsheet(token, 'Cœur à Corps — Résumé mensuel', ['Résumé mensuel']);
    mensuelSheetId = created.spreadsheetId;
    // Ajouter les headers
    await sheetsApi(token, `/${mensuelSheetId}/values/Résumé mensuel!A1:E1?valueInputOption=RAW`, 'PUT', {
      values: [['Mois', 'Prestation', 'Nombre de RDV', 'Revenu total (€)', 'Durée totale (min)']]
    });
    await base44.asServiceRole.entities.Settings.create({
      key: 'sheets_mensuel_id',
      value: mensuelSheetId,
      description: 'ID du Google Sheet Résumé mensuel'
    });
    console.log('Spreadsheet Mensuel créé :', mensuelSheetId);
  }

  return { clientsSheetId, mensuelSheetId };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const bookingData = await req.json();

    const { accessToken } = await base44.asServiceRole.connectors.getConnection('googlesheets');
    const { clientsSheetId, mensuelSheetId } = await getOrCreateSheets(base44, accessToken);

    // ===== 1. MISE À JOUR FICHE CLIENT =====
    const clientsData = await sheetsApi(accessToken, `/${clientsSheetId}/values/Clients!A2:F?majorDimension=ROWS`);
    const rows = clientsData.values || [];

    // Chercher client existant par email (colonne B = index 1)
    const existingRowIndex = rows.findIndex(row => row[1] === bookingData.client_email);
    const bookingAmount = bookingData.price || 0;
    const today = bookingData.booking_date;

    if (existingRowIndex >= 0) {
      // Client existant : mettre à jour dernière visite + total dépenses
      const sheetRow = existingRowIndex + 2; // +2 car données démarrent à ligne 2
      const existingRow = rows[existingRowIndex];
      const currentTotal = parseFloat(existingRow[5]) || 0;
      const newTotal = currentTotal + bookingAmount;

      await sheetsApi(accessToken, `/${clientsSheetId}/values/Clients!E${sheetRow}:F${sheetRow}?valueInputOption=RAW`, 'PUT', {
        values: [[today, newTotal]]
      });
      console.log(`Client existant mis à jour (ligne ${sheetRow}), nouveau total : ${newTotal}€`);
    } else {
      // Nouveau client : ajouter une ligne
      await sheetsApi(accessToken, `/${clientsSheetId}/values/Clients!A:F:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`, 'POST', {
        values: [[
          bookingData.client_name,
          bookingData.client_email,
          bookingData.client_phone || '',
          today,
          today,
          bookingAmount
        ]]
      });
      console.log('Nouveau client ajouté :', bookingData.client_email);
    }

    // ===== 2. RÉSUMÉ MENSUEL =====
    const mois = bookingData.booking_date.substring(0, 7); // format YYYY-MM
    const prestation = bookingData.service_name;
    const duree = bookingData.duration_minutes || 0;

    const mensuelData = await sheetsApi(accessToken, `/${mensuelSheetId}/values/Résumé mensuel!A2:E?majorDimension=ROWS`);
    const mensuelRows = mensuelData.values || [];

    // Chercher ligne mois + prestation existante
    const mensuelIndex = mensuelRows.findIndex(row => row[0] === mois && row[1] === prestation);

    if (mensuelIndex >= 0) {
      // Mettre à jour la ligne existante
      const sheetRow = mensuelIndex + 2;
      const existing = mensuelRows[mensuelIndex];
      const newCount = (parseInt(existing[2]) || 0) + 1;
      const newRevenu = (parseFloat(existing[3]) || 0) + bookingAmount;
      const newDuree = (parseInt(existing[4]) || 0) + duree;

      await sheetsApi(accessToken, `/${mensuelSheetId}/values/Résumé mensuel!C${sheetRow}:E${sheetRow}?valueInputOption=RAW`, 'PUT', {
        values: [[newCount, newRevenu, newDuree]]
      });
    } else {
      // Nouvelle ligne mois + prestation
      await sheetsApi(accessToken, `/${mensuelSheetId}/values/Résumé mensuel!A:E:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`, 'POST', {
        values: [[mois, prestation, 1, bookingAmount, duree]]
      });
    }

    console.log(`Résumé mensuel mis à jour : ${mois} / ${prestation}`);

    return Response.json({ success: true });
  } catch (error) {
    console.error('Erreur syncBookingToSheets :', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});