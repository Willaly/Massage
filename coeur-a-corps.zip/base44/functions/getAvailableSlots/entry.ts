import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

function timeToMinutes(time) {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

function minutesToTime(minutes) {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { date, duration_minutes } = await req.json();

    if (!date || !duration_minutes) {
      return Response.json({ error: 'Date et durée requis' }, { status: 400 });
    }

    // Vérifier que le jour est ouvert — depuis la BDD
    const dayOfWeek = new Date(date + 'T12:00:00').getDay();
    const openingHoursList = await base44.asServiceRole.entities.OpeningHours.filter({ day_of_week: dayOfWeek });
    const hours = openingHoursList[0];

    if (!hours || !hours.open || !hours.start_time || !hours.end_time) {
      return Response.json({ slots: [] }); // Fermé ce jour
    }

    // Générer tous les créneaux de 30 min dans la plage d'ouverture
    const openStart = timeToMinutes(hours.start_time);
    const openEnd = timeToMinutes(hours.end_time);
    const allSlots = [];

    for (let t = openStart; t + duration_minutes <= openEnd; t += 30) {
      allSlots.push({
        start_time: minutesToTime(t),
        end_time: minutesToTime(t + duration_minutes)
      });
    }

    // Récupérer les réservations base44 pour cette date (hors annulées et pending_payment)
    const bookings = await base44.asServiceRole.entities.Booking.filter({
      booking_date: date,
      status: { $nin: ['cancelled', 'pending'] }
    });

    // Récupérer les événements Google Calendar (créneaux bloqués)
    const calendarBusySlots = [];
    try {
      const { accessToken } = await base44.asServiceRole.connectors.getConnection('googlecalendar');
      // Europe/Paris : UTC+1 en hiver, UTC+2 en été (DST du dernier dimanche de mars au dernier dimanche d'octobre)
      const dateObj = new Date(date + 'T12:00:00Z');
      const month = dateObj.getUTCMonth() + 1; // 1-12
      const isEuropeanSummer = month >= 4 && month <= 10; // approximation DST France
      const utcOffset = isEuropeanSummer ? '+02:00' : '+01:00';
      const dayStart = `${date}T00:00:00${utcOffset}`;
      const dayEnd = `${date}T23:59:59${utcOffset}`;

      const calRes = await fetch(
        `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${encodeURIComponent(dayStart)}&timeMax=${encodeURIComponent(dayEnd)}&singleEvents=true&orderBy=startTime`,
        { headers: { 'Authorization': `Bearer ${accessToken}` } }
      );

      if (calRes.ok) {
        const calData = await calRes.json();
        for (const event of calData.items || []) {
          // Événement sur une journée entière (all-day) — ignorer
          if (event.start?.date && !event.start?.dateTime) continue;

          if (event.start?.dateTime && event.end?.dateTime) {
            // Convertir en UTC puis en heure locale France
            const startUtc = new Date(event.start.dateTime);
            const endUtc = new Date(event.end.dateTime);
            const offsetMinutes = isEuropeanSummer ? 120 : 60;
            const startLocal = startUtc.getUTCHours() * 60 + startUtc.getUTCMinutes() + offsetMinutes;
            const endLocal = endUtc.getUTCHours() * 60 + endUtc.getUTCMinutes() + offsetMinutes;
            calendarBusySlots.push({ startMinutes: startLocal, endMinutes: endLocal });
          }
        }
      }
    } catch (calError) {
      console.log('Erreur Google Calendar (non bloquant) :', calError.message);
    }

    // Retourner tous les créneaux avec leur disponibilité
    const slots = allSlots.map(slot => {
      const slotStart = timeToMinutes(slot.start_time);
      const slotEnd = slotStart + duration_minutes;

      const hasBookingConflict = bookings.some(booking => {
        const bStart = timeToMinutes(booking.booking_time);
        const bEnd = bStart + booking.duration_minutes;
        return slotStart < bEnd && slotEnd > bStart;
      });

      const hasCalendarConflict = calendarBusySlots.some(busy => {
        return slotStart < busy.endMinutes && slotEnd > busy.startMinutes;
      });

      return { ...slot, available: !hasBookingConflict && !hasCalendarConflict };
    });

    return Response.json({ slots });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});