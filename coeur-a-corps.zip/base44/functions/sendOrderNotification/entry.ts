import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

function toBase64url(str) {
  const bytes = new TextEncoder().encode(str);
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function makeEmail({ to, subject, body }) {
  const mime = [
    `To: ${to}`,
    `Subject: =?UTF-8?B?${toBase64url(subject)}?=`,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    toBase64url(body)
  ].join('\r\n');
  return toBase64url(mime);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { event, data } = await req.json();

    if (event.type !== 'create') {
      return Response.json({ success: true, message: 'Ignored non-create event' });
    }

    const settings = await base44.asServiceRole.entities.Settings.filter({ key: 'admin_email' });
    const adminEmail = settings[0]?.value || 'marineproservices83@gmail.com';

    const { accessToken } = await base44.asServiceRole.connectors.getConnection('gmail');

    const itemsList = data.items?.map(item =>
      `- ${item.product_name}${item.variant ? ` (${item.variant})` : ''} x${item.quantity} — ${item.price}€`
    ).join('\n') || '';

    const emailBody = `Nouvelle commande ${data.order_type === 'gift_card' ? 'CARTE CADEAU' : 'BOUTIQUE'} reçue :

Client : ${data.client_name || 'Non fourni'}
Email : ${data.client_email}
Téléphone : ${data.client_phone || 'Non fourni'}

Articles :
${itemsList}

Montant total : ${data.total_amount}€
Statut : ${data.status}
ID commande : ${data.unique_id || data.id}`;

    const raw = makeEmail({
      to: adminEmail,
      subject: `[COMMANDE ${data.order_type === 'gift_card' ? 'CARTE CADEAU' : 'BOUTIQUE'}] ${data.total_amount}€ - ${data.client_email}`,
      body: emailBody
    });

    const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ raw })
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Gmail API error: ${err}`);
    }

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});