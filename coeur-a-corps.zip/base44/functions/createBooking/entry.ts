import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Encode string to base64 using TextEncoder (full UTF-8 support)
function toBase64(str) {
  const bytes = new TextEncoder().encode(str);
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

// base64url (for MIME envelope only)
function toBase64Url(str) {
  return toBase64(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function buildMimeEmailHtml({ to, from, subject, bodyHtml, bodyText }) {
  const boundary = `boundary_cac_${Date.now()}`;
  // Subject encoded as base64
  const subjectEncoded = `=?UTF-8?B?${toBase64(subject)}?=`;
  const lines = [
    `From: ${from}`,
    `To: ${to}`,
    `Subject: ${subjectEncoded}`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    '',
    `--${boundary}`,
    'Content-Type: text/plain; charset="UTF-8"',
    'Content-Transfer-Encoding: base64',
    '',
    toBase64(bodyText),
    '',
    `--${boundary}`,
    'Content-Type: text/html; charset="UTF-8"',
    'Content-Transfer-Encoding: base64',
    '',
    toBase64(bodyHtml),
    '',
    `--${boundary}--`
  ].join('\r\n');
  return toBase64Url(lines);
}

function buildMimeEmail({ to, from, subject, bodyText }) {
  const subjectEncoded = `=?UTF-8?B?${toBase64(subject)}?=`;
  const lines = [
    `From: ${from}`,
    `To: ${to}`,
    `Subject: ${subjectEncoded}`,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset="UTF-8"',
    'Content-Transfer-Encoding: base64',
    '',
    toBase64(bodyText)
  ].join('\r\n');
  return toBase64Url(lines);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const bookingData = await req.json();

    // Validation
    if (!bookingData.service_id || !bookingData.client_name || !bookingData.client_email ||
        !bookingData.booking_date || !bookingData.booking_time) {
      return Response.json({ error: 'Données incomplètes' }, { status: 400 });
    }

    // Vérifier la disponibilité
    const existingBookings = await base44.asServiceRole.entities.Booking.filter({
      booking_date: bookingData.booking_date,
      booking_time: bookingData.booking_time,
      status: { $ne: 'cancelled' }
    });

    if (existingBookings.length > 0) {
      return Response.json({ error: "Ce créneau n'est plus disponible" }, { status: 409 });
    }

    // Créer la réservation
    const booking = await base44.asServiceRole.entities.Booking.create({
      service_id: bookingData.service_id,
      service_name: bookingData.service_name,
      client_name: bookingData.client_name,
      client_email: bookingData.client_email,
      client_phone: bookingData.client_phone || '',
      booking_date: bookingData.booking_date,
      booking_time: bookingData.booking_time,
      duration_minutes: bookingData.duration_minutes,
      notes: bookingData.notes || '',
      status: bookingData.paymentMode === 'online' ? 'pending' : 'confirmed'
    });

    const dateFormatted = new Date(bookingData.booking_date + 'T12:00:00').toLocaleDateString('fr-FR', {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
    });

    // Questionnaire santé
    const health = bookingData.healthData || {};
    const hasHealthData = Object.keys(health).length > 0;

    // --- Google Calendar ---
    try {
      const { accessToken: calToken } = await base44.asServiceRole.connectors.getConnection('googlecalendar');

      const eventStart = `${bookingData.booking_date}T${bookingData.booking_time}:00`;
      const startDate = new Date(eventStart);
      const endDate = new Date(startDate.getTime() + bookingData.duration_minutes * 60000);

      const healthSection = hasHealthData
        ? `\n\n--- QUESTIONNAIRE SANTE ---\nGrosse : ${health.pregnant || 'Non'}\nAllergies : ${health.allergies || 'Aucune'}\nConditions medicales : ${health.conditions || 'Non'}\nZones sensibles : ${health.areas || 'Non precisee'}\nAttentes : ${health.expectations || 'Non precisees'}`
        : '';

      const paymentNote = bookingData.paymentMode === 'online'
        ? 'Mode de paiement : En ligne (-5%)'
        : bookingData.paymentMode === 'onsite'
          ? 'Mode de paiement : Sur place'
          : '';

      const calendarEvent = {
        summary: `${bookingData.service_name} — ${bookingData.client_name}`,
        description: `Client : ${bookingData.client_name}\nEmail : ${bookingData.client_email}\nTel : ${bookingData.client_phone || 'N/A'}\n\nNotes : ${bookingData.notes || 'Aucune'}\n${paymentNote}${healthSection}`,
        start: { dateTime: startDate.toISOString(), timeZone: 'Europe/Paris' },
        end: { dateTime: endDate.toISOString(), timeZone: 'Europe/Paris' },
        attendees: [{ email: bookingData.client_email }],
        reminders: {
          useDefault: false,
          overrides: [
            { method: 'email', minutes: 24 * 60 },
            { method: 'popup', minutes: 60 }
          ]
        }
      };

      const calRes = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${calToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(calendarEvent)
      });

      if (calRes.ok) {
        const calData = await calRes.json();
        await base44.asServiceRole.entities.Booking.update(booking.id, { google_event_id: calData.id });
        console.log('Evenement Google Calendar cree :', calData.id);
      } else {
        console.log('Erreur Google Calendar :', await calRes.text());
      }
    } catch (calError) {
      console.log('Erreur Google Calendar (non bloquant) :', calError.message);
    }

    // --- Emails : uniquement si paiement sur place (online → géré par webhook Stripe) ---
    if (bookingData.paymentMode !== 'online') {
      try {
        const { accessToken: gmailToken } = await base44.asServiceRole.connectors.getConnection('gmail');

        const addressLine = '342 Promenade General Charles de Gaulle, 83140 Six-Fours-les-Plages';
        const addressEncoded = encodeURIComponent('Salon Mastroianni, ' + addressLine);
        const mapsUrl = `https://maps.google.com/?q=${addressEncoded}`;
        const bookingCode = booking.id.slice(-8).toUpperCase();

        // HTML questionnaire santé pour email client
        const healthSection = hasHealthData ? `
          <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:24px;">
            <tr><td style="padding:20px 24px;border-bottom:1px solid #252525;">
              <p style="margin:0;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#C9A96E;">Questionnaire sante</p>
            </td></tr>
            <tr><td style="padding:16px 24px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                ${health.pregnant ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Grossesse</span><br><span style="font-size:13px;color:#FFFBF0;">${health.pregnant}</span></td></tr>` : ''}
                ${health.allergies ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Allergies</span><br><span style="font-size:13px;color:#FFFBF0;">${health.allergies}</span></td></tr>` : ''}
                ${health.conditions ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Conditions medicales</span><br><span style="font-size:13px;color:#FFFBF0;">${health.conditions}</span></td></tr>` : ''}
                ${health.areas ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Zones sensibles</span><br><span style="font-size:13px;color:#FFFBF0;">${health.areas}</span></td></tr>` : ''}
                ${health.expectations ? `<tr><td style="padding:8px 0;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Attentes</span><br><span style="font-size:13px;color:#FFFBF0;">${health.expectations}</span></td></tr>` : ''}
              </table>
            </td></tr>
          </table>` : '';

        const clientEmailHtml = `<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Confirmation RDV</title></head>
<body style="margin:0;padding:0;background-color:#0A0A0A;font-family:Arial,Helvetica,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#0A0A0A;padding:40px 20px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">

        <tr><td style="background:#141414;border:1px solid #C9A96E;border-radius:12px 12px 0 0;padding:40px;text-align:center;">
          <p style="margin:0 0 4px;font-size:11px;letter-spacing:4px;text-transform:uppercase;color:#C9A96E;">Massages et Bien-etre</p>
          <h1 style="margin:0;font-size:30px;color:#FFFBF0;font-weight:300;letter-spacing:2px;">Coeur a Corps</h1>
          <div style="width:60px;height:1px;background:#C9A96E;margin:16px auto;"></div>
          <p style="margin:0;font-size:13px;color:#C9A96E;letter-spacing:2px;text-transform:uppercase;">Reservation confirmee</p>
        </td></tr>

        <tr><td style="background-color:#141414;border-left:1px solid #C9A96E;border-right:1px solid #C9A96E;padding:40px;">

          <p style="color:#FFFBF0;font-size:16px;margin:0 0 12px;">Bonjour <strong style="color:#C9A96E;">${bookingData.client_name}</strong>,</p>
          <p style="color:#aaaaaa;font-size:14px;line-height:1.7;margin:0 0 32px;">Votre rendez-vous est confirme. Nous avons hate de vous accueillir pour un moment de detente et de bien-etre.</p>

          <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:24px;">
            <tr><td style="padding:16px 24px;border-bottom:1px solid #252525;">
              <p style="margin:0;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#C9A96E;">Recapitulatif</p>
            </td></tr>
            <tr><td style="padding:0 24px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr><td style="padding:14px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Date</span><br>
                  <span style="font-size:15px;color:#FFFBF0;font-weight:500;">${dateFormatted}</span>
                </td></tr>
                <tr><td style="padding:14px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Heure</span><br>
                  <span style="font-size:15px;color:#FFFBF0;font-weight:500;">${bookingData.booking_time}</span>
                </td></tr>
                <tr><td style="padding:14px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Soin</span><br>
                  <span style="font-size:15px;color:#FFFBF0;font-weight:500;">${bookingData.service_name}</span><br>
                  <span style="font-size:12px;color:#888;">Duree : ${bookingData.duration_minutes} minutes</span>
                </td></tr>
                <tr><td style="padding:14px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Paiement</span><br>
                  <span style="font-size:14px;color:#FFFBF0;">Reglement sur place le jour du soin</span>
                </td></tr>
                <tr><td style="padding:14px 0;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Code de reservation</span><br>
                  <span style="font-size:20px;color:#C9A96E;font-weight:700;letter-spacing:4px;">${bookingCode}</span>
                </td></tr>
              </table>
            </td></tr>
          </table>

          <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:24px;">
            <tr><td style="padding:16px 24px;">
              <p style="margin:0 0 8px;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#C9A96E;">Adresse</p>
              <p style="margin:0 0 4px;font-size:14px;color:#FFFBF0;">Salon Mastroianni</p>
              <p style="margin:0 0 16px;font-size:13px;color:#aaa;">${addressLine}</p>
              <a href="${mapsUrl}" style="display:inline-block;background:#C9A96E;color:#0A0A0A;text-decoration:none;font-size:11px;font-weight:600;letter-spacing:1px;text-transform:uppercase;padding:9px 18px;border-radius:20px;">Voir sur Google Maps</a>
            </td></tr>
          </table>

          ${healthSection}

          <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:32px;">
            <tr><td style="padding:16px 24px;">
              <p style="margin:0 0 12px;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#C9A96E;">Infos pratiques</p>
              <p style="margin:0 0 8px;font-size:13px;color:#aaa;line-height:1.6;">Nous vous recommandons d'arriver 5 minutes avant l'heure prevue.</p>
              <p style="margin:0 0 8px;font-size:13px;color:#aaa;line-height:1.6;">En cas d'annulation, merci de nous prevenir au moins <strong style="color:#FFFBF0;">24h a l'avance</strong>.</p>
              <p style="margin:0;font-size:13px;color:#aaa;line-height:1.6;">Portez des vetements confortables, nous nous occupons du reste.</p>
            </td></tr>
          </table>

          <p style="font-size:13px;color:#888;margin:0 0 8px;">Une question ? Contactez-nous :</p>
          <p style="margin:0 0 6px;"><a href="tel:+33650543613" style="color:#C9A96E;text-decoration:none;font-size:14px;">06 50 54 36 13</a></p>
          <p style="margin:0;"><a href="https://wa.me/33650543613" style="color:#C9A96E;text-decoration:none;font-size:14px;">WhatsApp</a></p>

        </td></tr>

        <tr><td style="background:#0A0A0A;border:1px solid #C9A96E;border-top:none;border-radius:0 0 12px 12px;padding:24px 40px;text-align:center;">
          <p style="margin:0 0 4px;font-size:11px;color:#C9A96E;letter-spacing:2px;text-transform:uppercase;">Coeur a Corps</p>
          <p style="margin:0;font-size:11px;color:#555;">Massages et Bien-etre - Six-Fours-les-Plages</p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`;

        const clientEmailText = `Bonjour ${bookingData.client_name},\n\nVotre rendez-vous est confirme !\n\nDate : ${dateFormatted}\nHeure : ${bookingData.booking_time}\nSoin : ${bookingData.service_name} (${bookingData.duration_minutes} min)\nPaiement : sur place\nCode : ${bookingCode}\n\nAdresse : Salon Mastroianni, ${addressLine}\n\nNous joindre : 06 50 54 36 13\n\nA bientot,\nCoeur a Corps`;

        const clientRaw = buildMimeEmailHtml({
          to: bookingData.client_email,
          from: 'Coeur a Corps <marineproservices83@gmail.com>',
          subject: `Confirmation RDV - ${bookingData.service_name}`,
          bodyHtml: clientEmailHtml,
          bodyText: clientEmailText
        });

        await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${gmailToken}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ raw: clientRaw })
        });

        // Email admin HTML (aussi beau que le client)
        const adminHealthSection = hasHealthData ? `
          <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:24px;">
            <tr><td style="padding:16px 24px;border-bottom:1px solid #252525;">
              <p style="margin:0;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#C9A96E;">Questionnaire sante</p>
            </td></tr>
            <tr><td style="padding:16px 24px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                ${health.pregnant ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Grossesse</span><br><span style="font-size:13px;color:#FFFBF0;">${health.pregnant}</span></td></tr>` : ''}
                ${health.allergies ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Allergies</span><br><span style="font-size:13px;color:#FFFBF0;">${health.allergies}</span></td></tr>` : ''}
                ${health.conditions ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Conditions medicales</span><br><span style="font-size:13px;color:#FFFBF0;">${health.conditions}</span></td></tr>` : ''}
                ${health.areas ? `<tr><td style="padding:8px 0;border-bottom:1px solid #252525;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Zones sensibles</span><br><span style="font-size:13px;color:#FFFBF0;">${health.areas}</span></td></tr>` : ''}
                ${health.expectations ? `<tr><td style="padding:8px 0;"><span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Attentes</span><br><span style="font-size:13px;color:#FFFBF0;">${health.expectations}</span></td></tr>` : ''}
              </table>
            </td></tr>
          </table>` : `
          <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:24px;">
            <tr><td style="padding:16px 24px;">
              <p style="margin:0;font-size:11px;color:#666;font-style:italic;">Questionnaire sante non rempli.</p>
            </td></tr>
          </table>`;

        const adminEmailHtml = `<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Nouvelle reservation</title></head>
<body style="margin:0;padding:0;background-color:#0A0A0A;font-family:Arial,Helvetica,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#0A0A0A;padding:40px 20px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">

        <tr><td style="background:#141414;border:1px solid #C9A96E;border-radius:12px 12px 0 0;padding:40px;text-align:center;">
          <p style="margin:0 0 4px;font-size:11px;letter-spacing:4px;text-transform:uppercase;color:#C9A96E;">Coeur a Corps</p>
          <h1 style="margin:0;font-size:26px;color:#FFFBF0;font-weight:300;letter-spacing:2px;">Nouvelle reservation</h1>
          <div style="width:60px;height:1px;background:#C9A96E;margin:16px auto;"></div>
          <p style="margin:0;font-size:13px;color:#C9A96E;letter-spacing:2px;text-transform:uppercase;">Paiement sur place</p>
        </td></tr>

        <tr><td style="background-color:#141414;border-left:1px solid #C9A96E;border-right:1px solid #C9A96E;padding:40px;">

          <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:24px;">
            <tr><td style="padding:16px 24px;border-bottom:1px solid #252525;">
              <p style="margin:0;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#C9A96E;">Client</p>
            </td></tr>
            <tr><td style="padding:0 24px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr><td style="padding:12px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Nom</span><br>
                  <span style="font-size:15px;color:#FFFBF0;font-weight:500;">${bookingData.client_name}</span>
                </td></tr>
                <tr><td style="padding:12px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Email</span><br>
                  <a href="mailto:${bookingData.client_email}" style="font-size:14px;color:#C9A96E;">${bookingData.client_email}</a>
                </td></tr>
                <tr><td style="padding:12px 0;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Telephone</span><br>
                  <span style="font-size:14px;color:#FFFBF0;">${bookingData.client_phone || 'Non renseigne'}</span>
                </td></tr>
              </table>
            </td></tr>
          </table>

          <table width="100%" cellpadding="0" cellspacing="0" style="background:#1a1a1a;border:1px solid #333;border-radius:8px;margin-bottom:24px;">
            <tr><td style="padding:16px 24px;border-bottom:1px solid #252525;">
              <p style="margin:0;font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#C9A96E;">Soin</p>
            </td></tr>
            <tr><td style="padding:0 24px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr><td style="padding:12px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Date</span><br>
                  <span style="font-size:15px;color:#FFFBF0;font-weight:500;">${dateFormatted}</span>
                </td></tr>
                <tr><td style="padding:12px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Heure</span><br>
                  <span style="font-size:15px;color:#FFFBF0;font-weight:500;">${bookingData.booking_time}</span>
                </td></tr>
                <tr><td style="padding:12px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Soin</span><br>
                  <span style="font-size:15px;color:#FFFBF0;font-weight:500;">${bookingData.service_name}</span><br>
                  <span style="font-size:12px;color:#888;">Duree : ${bookingData.duration_minutes} minutes</span>
                </td></tr>
                <tr><td style="padding:12px 0;border-bottom:1px solid #252525;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Paiement</span><br>
                  <span style="font-size:14px;color:#FFFBF0;">Sur place le jour du soin</span>
                </td></tr>
                ${bookingData.notes ? `<tr><td style="padding:12px 0;">
                  <span style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:1px;">Notes client</span><br>
                  <span style="font-size:14px;color:#FFFBF0;">${bookingData.notes}</span>
                </td></tr>` : ''}
              </table>
            </td></tr>
          </table>

          ${adminHealthSection}

          <p style="font-size:12px;color:#555;margin:0;">ID reservation : ${booking.id}</p>

        </td></tr>

        <tr><td style="background:#0A0A0A;border:1px solid #C9A96E;border-top:none;border-radius:0 0 12px 12px;padding:24px 40px;text-align:center;">
          <p style="margin:0;font-size:11px;color:#555;">Coeur a Corps — Massages et Bien-etre - Six-Fours-les-Plages</p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`;

        const adminEmailText = `Nouvelle reservation - ${bookingData.service_name}\nClient : ${bookingData.client_name} (${bookingData.client_email})\nDate : ${dateFormatted} a ${bookingData.booking_time}\nDuree : ${bookingData.duration_minutes} min\nPaiement : sur place`;

        const adminRaw = buildMimeEmailHtml({
          to: 'marineproservices83@gmail.com',
          from: 'Reservations Coeur a Corps <marineproservices83@gmail.com>',
          subject: `[RESERVATION] ${bookingData.service_name} - ${bookingData.client_name}`,
          bodyHtml: adminEmailHtml,
          bodyText: adminEmailText
        });

        await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${gmailToken}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ raw: adminRaw })
        });

        console.log('Emails envoyes (paiement sur place)');
      } catch (gmailError) {
        console.log('Erreur Gmail (non bloquant) :', gmailError.message);
      }
    } else {
      console.log('Paiement en ligne : emails en attente de confirmation Stripe');
    }

    // --- Google Sheets ---
    try {
      await base44.functions.invoke('syncBookingToSheets', {
        ...bookingData,
        price: bookingData.price || 0
      });
    } catch (sheetsError) {
      console.log('Erreur Google Sheets (non bloquant) :', sheetsError.message);
    }

    return Response.json({ success: true, booking, message: 'Reservation creee avec succes' });

  } catch (error) {
    console.error('Erreur creation reservation :', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});